@extends('layouts.admin')

@section('title', db_trans('access_control_center'))


@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/access-control.css') }}">
	  <link rel="stylesheet" href="{{ asset('admin/css/accessdasboard.css') }}">
@endpush
@section('content')
    <div class="access-shell">
        <div class="access-hero">
            <span class="access-hero-badge">
                <i class="fas fa-user-lock"></i>
                {{ db_trans('system') }}
            </span>

            <h2 class="access-hero-title">{{ $page['title'] }}</h2>
            <p class="access-hero-subtitle">{{ $page['subtitle'] }}</p>

            <div>
                <span class="access-meta-pill">
                    <i class="fas fa-clock"></i>
                    {{ db_trans('last_updated') }}: {{ optional($page['updated_at'])->format('d M Y, h:i A') }}
                </span>

                <span class="access-meta-pill">
                    <i class="fas fa-user-shield"></i>
                    {{ db_trans('logged_in_as') }}: {{ auth()->user()->name }}
                </span>
            </div>
        </div>

        <div class="row g-4">
            @foreach($kpis as $card)
                <div class="col-xxl-2 col-xl-4 col-md-6">
                    <div class="card access-kpi-card">
                        <div class="card-body">
                            <div class="access-kpi-top">
                                <span class="access-kpi-icon {{ $card['tone'] ? 'tone-'.$card['tone'] : 'tone-primary' }}">
                                    <i class="{{ $card['icon'] }}"></i>
                                </span>
                                <span class="access-kpi-chip">{{ db_trans('overview') }}</span>
                            </div>

                            <div class="access-kpi-title">{{ $card['title'] }}</div>
                            <div class="access-kpi-value">{{ number_format((int) $card['value']) }}</div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="row g-4">
            <div class="col-xl-6">
                <div class="card access-panel">
                    <div class="card-body">
                        <div class="access-panel-head">
                            <div>
                                <h4 class="access-panel-title">{{ db_trans('recent_admin_users') }}</h4>
                                <p class="access-panel-subtitle">{{ db_trans('latest_created_or_updated_admin_accounts') }}</p>
                            </div>
                            <span class="access-badge">{{ db_trans('admin_users') }}</span>
                        </div>

                        <div class="access-mini-list">
                            @forelse($recentUsers as $user)
                                <div class="access-mini-item">
                                    <div class="access-mini-title">{{ $user->name }}</div>
                                    <div class="access-mini-meta">{{ $user->email }}</div>
                                    <div class="access-mini-meta">
                                        {{ $user->display_scope }}
                                        @if($user->member)
                                            • {{ $user->member->member_code ?? db_trans('member') }}
                                        @endif
                                    </div>
                                    <div class="mt-2">
                                        @foreach($user->roles as $role)
                                            <span class="access-chip">{{ $role->name }}</span>
                                        @endforeach
                                    </div>
                                </div>
                            @empty
                                <div class="text-muted">{{ db_trans('no_admin_users_found') }}</div>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3">
                <div class="card access-panel">
                    <div class="card-body">
                        <div class="access-panel-head">
                            <div>
                                <h4 class="access-panel-title">{{ db_trans('recent_roles') }}</h4>
                                <p class="access-panel-subtitle">{{ db_trans('roles_and_their_current_assignments') }}</p>
                            </div>
                            <span class="access-badge">{{ db_trans('roles') }}</span>
                        </div>

                        <div class="access-mini-list">
                            @forelse($recentRoles as $role)
                                <div class="access-mini-item">
                                    <div class="access-mini-title">{{ $role->name }}</div>
                                    <div class="access-mini-meta">
                                        {{ $role->permissions_count }} {{ db_trans('permissions') }}
                                        • {{ $role->users_count }} {{ db_trans('users') }}
                                    </div>
                                </div>
                            @empty
                                <div class="text-muted">{{ db_trans('no_roles_found') }}</div>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-3">
                <div class="card access-panel">
                    <div class="card-body">
                        <div class="access-panel-head">
                            <div>
                                <h4 class="access-panel-title">{{ db_trans('permission_modules') }}</h4>
                                <p class="access-panel-subtitle">{{ db_trans('permission_distribution_by_module') }}</p>
                            </div>
                            <span class="access-badge">{{ db_trans('permissions') }}</span>
                        </div>

                        <div class="access-mini-list">
                            @forelse($permissionModules as $module)
                                <div class="access-mini-item">
                                    <div class="access-mini-title">{{ ucfirst($module->module ?: 'general') }}</div>
                                    <div class="access-mini-meta">{{ $module->total }} {{ db_trans('permissions') }}</div>
                                </div>
                            @empty
                                <div class="text-muted">{{ db_trans('no_permissions_found') }}</div>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex flex-wrap gap-3">
            @can('access.users.create')
                <a href="{{ route('system-access.users.create') }}" class="btn btn-primary px-4">
                    <i class="fas fa-user-plus me-2"></i>{{ db_trans('create_admin_user') }}
                </a>
            @endcan

            @can('access.roles.create')
                <a href="{{ route('system-access.roles.create') }}" class="btn btn-outline-dark px-4">
                    <i class="fas fa-id-badge me-2"></i>{{ db_trans('create_role') }}
                </a>
            @endcan

            @can('access.permissions.create')
                <a href="{{ route('system-access.permissions.create') }}" class="btn btn-outline-secondary px-4">
                    <i class="fas fa-key me-2"></i>{{ db_trans('create_permission') }}
                </a>
            @endcan
        </div>
    </div>
@endsection