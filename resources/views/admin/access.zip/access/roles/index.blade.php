@extends('layouts.admin')

@section('title', db_trans('roles'))
@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/access-control.css') }}">
@endpush
@section('content')
    <div class="access-page-shell d-flex flex-column gap-4">
        <div class="access-page-hero p-4 rounded-4 text-white" style="background:linear-gradient(135deg,#111827 0%,#1f2937 35%,#4338ca 100%);">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div>
                    <h2 class="mb-2">{{ db_trans('roles') }}</h2>
                    <p class="mb-0 text-white-50">{{ db_trans('create_edit_delete_and_manage_role_permissions') }}</p>
                </div>
                @can('access.roles.create')
                    <a href="{{ route('system-access.roles.create') }}" class="btn btn-light">
                        <i class="fas fa-plus me-2"></i>{{ db_trans('create_role') }}
                    </a>
                @endcan
            </div>
        </div>

        <div class="card border-0 rounded-4 shadow-sm">
            <div class="card-body p-4">
                <form method="GET" action="{{ route('system-access.roles.index') }}" class="row g-3">
                    <div class="col-lg-4">
                        <label class="form-label">{{ db_trans('search') }}</label>
                        <input type="text" name="search" value="{{ $filters['search'] ?? '' }}" class="form-control" placeholder="{{ db_trans('role_name') }}">
                    </div>
                    <div class="col-lg-2">
                        <label class="form-label">{{ db_trans('per_page') }}</label>
                        <select name="per_page" class="form-select">
                            @foreach([20,30,50,100] as $size)
                                <option value="{{ $size }}" @selected((int)($filters['per_page'] ?? 20) === $size)>{{ $size }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="col-lg-6 d-flex align-items-end gap-2">
                        <button class="btn btn-primary" type="submit">{{ db_trans('apply_filters') }}</button>
                        <a class="btn btn-outline-secondary" href="{{ route('system-access.roles.index') }}">{{ db_trans('reset') }}</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card border-0 rounded-4 shadow-sm">
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>{{ db_trans('role') }}</th>
                                <th>{{ db_trans('guard') }}</th>
                                <th>{{ db_trans('permissions') }}</th>
                                <th>{{ db_trans('users') }}</th>
                                <th>{{ db_trans('actions') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($roles as $role)
                                <tr>
                                    <td class="fw-semibold">{{ $role->name }}</td>
                                    <td>{{ $role->guard_name }}</td>
                                    <td>{{ $role->permissions_count }}</td>
                                    <td>{{ $role->users_count }}</td>
                                    <td>
                                        <div class="d-flex flex-wrap gap-2">
                                            @can('access.roles.update')
                                                <a href="{{ route('system-access.roles.edit', $role->id) }}" class="btn btn-sm btn-outline-dark">{{ db_trans('edit') }}</a>
                                            @endcan
                                            @can('access.roles.delete')
                                                <form method="POST" action="{{ route('system-access.roles.destroy', $role->id) }}" onsubmit="return confirm('{{ db_trans('are_you_sure') }}');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-sm btn-outline-danger" type="submit">{{ db_trans('delete') }}</button>
                                                </form>
                                            @endcan
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr><td colspan="5" class="text-center text-muted py-4">{{ db_trans('no_roles_found') }}</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                @if($roles->hasPages())
                    <div class="mt-4">{{ $roles->links() }}</div>
                @endif
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script src="{{ asset('admin/js/access-control.js') }}"></script>
@endpush