@extends('layouts.admin')

@section('title', db_trans('admin_users'))



@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/access-control.css') }}">
	  <link rel="stylesheet" href="{{ asset('admin/css/userindexx.css') }}">
@endpush

@section('content')
    <div class="access-page-shell">
        <div class="access-page-hero">
            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">
                <div>
                    <h2 class="access-page-hero-title">{{ db_trans('admin_users') }}</h2>
                    <p class="access-page-hero-subtitle">{{ db_trans('manage_system_admin_users_created_from_members') }}</p>
                </div>

                <div class="d-flex gap-2 flex-wrap">
                    <a href="{{ route('system-access.dashboard') }}" class="btn btn-light">
                        <i class="fas fa-chart-line me-2"></i>{{ db_trans('access_control_center') }}
                    </a>
                    @can('access.users.create')
                        <a href="{{ route('system-access.users.create') }}" class="btn btn-outline-light">
                            <i class="fas fa-user-plus me-2"></i>{{ db_trans('create_admin_user') }}
                        </a>
                    @endcan
                </div>
            </div>
        </div>

        <div class="card access-filter-card">
            <div class="card-body">
                <form method="GET" action="{{ route('system-access.users.index') }}">
                    <div class="row g-3">
                        <div class="col-xl-3 col-md-6">
                            <label class="access-filter-label">{{ db_trans('search') }}</label>
                            <input type="text" name="search" value="{{ $filters['search'] ?? '' }}" class="form-control"
                                   placeholder="{{ db_trans('name_email_phone_member') }}">
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="access-filter-label">{{ db_trans('role') }}</label>
                            <select name="role_id" class="form-select">
                                <option value="">{{ db_trans('all') }}</option>
                                @foreach($roles as $role)
                                    <option value="{{ $role->id }}" @selected((string)($filters['role_id'] ?? '') === (string)$role->id)>{{ $role->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="access-filter-label">{{ db_trans('status') }}</label>
                            <select name="is_active" class="form-select">
                                <option value="">{{ db_trans('all') }}</option>
                                <option value="1" @selected((string)($filters['is_active'] ?? '') === '1')>{{ db_trans('active') }}</option>
                                <option value="0" @selected((string)($filters['is_active'] ?? '') === '0')>{{ db_trans('inactive') }}</option>
                            </select>
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="access-filter-label">{{ db_trans('kanda') }}</label>
                            <select name="kanda_id" class="form-select">
                                <option value="">{{ db_trans('all') }}</option>
                                @foreach($kandas as $kanda)
                                    <option value="{{ $kanda->id }}" @selected((string)($filters['kanda_id'] ?? '') === (string)$kanda->id)>{{ $kanda->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="access-filter-label">{{ db_trans('jumuiya') }}</label>
                            <select name="jumuiya_id" class="form-select">
                                <option value="">{{ db_trans('all') }}</option>
                                @foreach($jumuiyas as $jumuiya)
                                    <option value="{{ $jumuiya->id }}" @selected((string)($filters['jumuiya_id'] ?? '') === (string)$jumuiya->id)>{{ $jumuiya->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-xl-1 col-md-6">
                            <label class="access-filter-label">{{ db_trans('per_page') }}</label>
                            <select name="per_page" class="form-select">
                                @foreach([20,30,50,100] as $size)
                                    <option value="{{ $size }}" @selected((int)($filters['per_page'] ?? 20) === $size)>{{ $size }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-12 d-flex align-items-end gap-2">
                            <button class="btn btn-primary px-4" type="submit">
                                <i class="fas fa-filter me-2"></i>{{ db_trans('apply_filters') }}
                            </button>
                            <a href="{{ route('system-access.users.index') }}" class="btn btn-outline-secondary px-4">
                                <i class="fas fa-rotate-left me-2"></i>{{ db_trans('reset') }}
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card access-table-card">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center gap-2 mb-3">
                    <div>
                        <h4 class="mb-1">{{ db_trans('admin_users') }}</h4>
                        <div class="text-muted">
                            {{ db_trans('showing') }} {{ $users->firstItem() ?? 0 }} {{ db_trans('to') }} {{ $users->lastItem() ?? 0 }}
                            {{ db_trans('of') }} {{ $users->total() }} {{ db_trans('users') }}
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table access-table align-middle">
                        <thead>
                            <tr>
                                <th>{{ db_trans('user') }}</th>
                                <th>{{ db_trans('member') }}</th>
                                <th>{{ db_trans('roles') }}</th>
                                <th>{{ db_trans('scope') }}</th>
                                <th>{{ db_trans('status') }}</th>
                                <th>{{ db_trans('last_login') }}</th>
                                <th>{{ db_trans('actions') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($users as $user)
                                <tr>
                                    <td style="min-width: 220px;">
                                        <div class="access-cell-title">{{ $user->name }}</div>
                                        <div class="access-cell-meta">{{ $user->email }}</div>
                                        <div class="access-cell-meta">{{ $user->phone ?: db_trans('not_available') }}</div>
                                    </td>

                                    <td style="min-width: 180px;">
                                        <div class="access-cell-title">
                                            {{ $user->member?->member_code ?: db_trans('not_available') }}
                                        </div>
                                        <div class="access-cell-meta">
                                            {{ $user->member ? trim(collect([$user->member->first_name, $user->member->middle_name, $user->member->last_name])->filter()->implode(' ')) : db_trans('not_available') }}
                                        </div>
                                    </td>

                                    <td style="min-width: 200px;">
                                        @forelse($user->roles as $role)
                                            <span class="access-role-chip">{{ $role->name }}</span>
                                        @empty
                                            <span class="text-muted">{{ db_trans('no_roles_assigned') }}</span>
                                        @endforelse
                                    </td>

                                    <td style="min-width: 180px;">
                                        <div class="access-cell-title">{{ $user->kanda?->name ?: db_trans('not_available') }}</div>
                                        <div class="access-cell-meta">{{ $user->jumuiya?->name ?: db_trans('not_available') }}</div>
                                    </td>

                                    <td>
                                        <span class="access-status-badge {{ $user->is_active ? 'status-active' : 'status-inactive' }}">
                                            {{ $user->is_active ? db_trans('active') : db_trans('inactive') }}
                                        </span>
                                    </td>

                                    <td style="min-width: 150px;">
                                        <div class="access-cell-title">
                                            {{ $user->last_login_at ? $user->last_login_at->format('d M Y, h:i A') : db_trans('never') }}
                                        </div>
                                        <div class="access-cell-meta">
                                            {{ $user->last_login_at ? $user->last_login_at->diffForHumans() : '-' }}
                                        </div>
                                    </td>

                                    <td style="min-width: 260px;">
                                        <div class="d-flex flex-wrap gap-2">
                                            @can('access.users.profile.view')
                                                <a href="{{ route('system-access.users.show', $user->id) }}" class="btn btn-sm btn-outline-primary">
                                                    <i class="fas fa-eye me-1"></i>{{ db_trans('view') }}
                                                </a>
                                            @endcan

                                            @can('access.users.update')
                                                <a href="{{ route('system-access.users.edit', $user->id) }}" class="btn btn-sm btn-outline-dark">
                                                    <i class="fas fa-pen me-1"></i>{{ db_trans('edit') }}
                                                </a>
                                            @endcan

                                            @if($user->is_active)
                                                @can('access.users.deactivate')
                                                    <form method="POST" action="{{ route('system-access.users.deactivate', $user->id) }}">
                                                        @csrf
                                                        @method('PATCH')
                                                        <button class="btn btn-sm btn-outline-warning" type="submit">
                                                            <i class="fas fa-user-slash me-1"></i>{{ db_trans('deactivate') }}
                                                        </button>
                                                    </form>
                                                @endcan
                                            @else
                                                @can('access.users.activate')
                                                    <form method="POST" action="{{ route('system-access.users.activate', $user->id) }}">
                                                        @csrf
                                                        @method('PATCH')
                                                        <button class="btn btn-sm btn-outline-success" type="submit">
                                                            <i class="fas fa-user-check me-1"></i>{{ db_trans('activate') }}
                                                        </button>
                                                    </form>
                                                @endcan
                                            @endif

                                            @can('access.users.delete')
                                                <form method="POST" action="{{ route('system-access.users.destroy', $user->id) }}" onsubmit="return confirm('{{ db_trans('are_you_sure') }}');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-sm btn-outline-danger" type="submit">
                                                        <i class="fas fa-trash me-1"></i>{{ db_trans('delete') }}
                                                    </button>
                                                </form>
                                            @endcan
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7" class="text-center text-muted py-4">{{ db_trans('no_admin_users_found') }}</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                @if($users->hasPages())
                    <div class="mt-4">{{ $users->links() }}</div>
                @endif
            </div>
        </div>
    </div>
@endsection