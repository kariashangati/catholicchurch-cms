@extends('layouts.admin')

@section('title', db_trans('permissions'))
@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/access-control.css') }}">
@endpush
@section('content')
    <div class="d-flex flex-column gap-4">
        <div class="p-4 rounded-4 text-white" style="background:linear-gradient(135deg,#0f172a 0%,#1d4ed8 45%,#0ea5e9 100%);">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div>
                    <h2 class="mb-2">{{ db_trans('permissions') }}</h2>
                    <p class="mb-0 text-white-50">{{ db_trans('manage_permissions_and_toggle_enable_disable') }}</p>
                </div>
                @can('access.permissions.create')
                    <a href="{{ route('system-access.permissions.create') }}" class="btn btn-light">
                        <i class="fas fa-plus me-2"></i>{{ db_trans('create_permission') }}
                    </a>
                @endcan
            </div>
        </div>

        <div class="card border-0 rounded-4 shadow-sm">
            <div class="card-body p-4">
                <form method="GET" action="{{ route('system-access.permissions.index') }}" class="row g-3">
                    <div class="col-lg-4">
                        <label class="form-label">{{ db_trans('search') }}</label>
                        <input type="text" name="search" value="{{ $filters['search'] ?? '' }}" class="form-control" placeholder="{{ db_trans('permission_name_or_description') }}">
                    </div>

                    <div class="col-lg-3">
                        <label class="form-label">{{ db_trans('module') }}</label>
                        <select name="module" class="form-select">
                            <option value="">{{ db_trans('all') }}</option>
                            @foreach($modules as $module)
                                <option value="{{ $module }}" @selected(($filters['module'] ?? '') === $module)>{{ ucfirst($module) }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-lg-2">
                        <label class="form-label">{{ db_trans('status') }}</label>
                        <select name="is_active" class="form-select">
                            <option value="">{{ db_trans('all') }}</option>
                            <option value="1" @selected((string)($filters['is_active'] ?? '') === '1')>{{ db_trans('active') }}</option>
                            <option value="0" @selected((string)($filters['is_active'] ?? '') === '0')>{{ db_trans('inactive') }}</option>
                        </select>
                    </div>

                    <div class="col-lg-1">
                        <label class="form-label">{{ db_trans('per_page') }}</label>
                        <select name="per_page" class="form-select">
                            @foreach([20,30,50,100] as $size)
                                <option value="{{ $size }}" @selected((int)($filters['per_page'] ?? 20) === $size)>{{ $size }}</option>
                            @endforeach
                        </select>
                    </div>

                    <div class="col-lg-2 d-flex align-items-end gap-2">
                        <button class="btn btn-primary" type="submit">{{ db_trans('apply_filters') }}</button>
                        <a class="btn btn-outline-secondary" href="{{ route('system-access.permissions.index') }}">{{ db_trans('reset') }}</a>
                    </div>
                </form>
            </div>
        </div>

        <div class="card border-0 rounded-4 shadow-sm">
            <div class="card-body p-4">
                <div class="table-responsive">
                    <table class="table align-middle">
                        <thead>
                            <tr>
                                <th>{{ db_trans('permission') }}</th>
                                <th>{{ db_trans('module') }}</th>
                                <th>{{ db_trans('guard') }}</th>
                                <th>{{ db_trans('roles') }}</th>
                                <th>{{ db_trans('status') }}</th>
                                <th>{{ db_trans('actions') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($permissions as $permission)
                                <tr>
                                    <td>
                                        <div class="fw-semibold">{{ $permission->name }}</div>
                                        <div class="small text-muted">{{ $permission->description ?: '-' }}</div>
                                    </td>
                                    <td>{{ ucfirst($permission->module ?: 'general') }}</td>
                                    <td>{{ $permission->guard_name }}</td>
                                    <td>{{ $permission->roles_count }}</td>
                                    <td>
                                        <span class="badge {{ $permission->is_active ? 'bg-success-subtle text-success' : 'bg-warning-subtle text-warning' }}">
                                            {{ $permission->is_active ? db_trans('active') : db_trans('inactive') }}
                                        </span>
                                    </td>
                                    <td>
                                        <div class="d-flex flex-wrap gap-2">
                                            @can('access.permissions.update')
                                                <a href="{{ route('system-access.permissions.edit', $permission->id) }}" class="btn btn-sm btn-outline-dark">{{ db_trans('edit') }}</a>
                                            @endcan

                                            @can('access.permissions.toggle')
                                                <form method="POST" action="{{ route('system-access.permissions.toggle', $permission->id) }}">
                                                    @csrf
                                                    @method('PATCH')
                                                    <button class="btn btn-sm btn-outline-{{ $permission->is_active ? 'warning' : 'success' }}" type="submit">
                                                        {{ $permission->is_active ? db_trans('disable') : db_trans('enable') }}
                                                    </button>
                                                </form>
                                            @endcan

                                            @can('access.permissions.delete')
                                                <form method="POST" action="{{ route('system-access.permissions.destroy', $permission->id) }}" onsubmit="return confirm('{{ db_trans('are_you_sure') }}');">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button class="btn btn-sm btn-outline-danger" type="submit">{{ db_trans('delete') }}</button>
                                                </form>
                                            @endcan
                                        </div>
                                    </td>
                                </tr>
                            @empty
                                <tr><td colspan="6" class="text-center text-muted py-4">{{ db_trans('no_permissions_found') }}</td></tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                @if($permissions->hasPages())
                    <div class="mt-4">{{ $permissions->links() }}</div>
                @endif
            </div>
        </div>
    </div>
@endsection
@push('scripts')
    <script src="{{ asset('admin/js/access-control.js') }}"></script>
@endpush