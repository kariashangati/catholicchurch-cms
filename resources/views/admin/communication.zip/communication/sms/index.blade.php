@extends('layouts.admin')

@section('title', db_trans('send_sms'))

@push('styles')
<link rel="stylesheet" href="{{ asset('assets/admin/css/communication-center-sms.css') }}">
@endpush

@section('content')
@php
    $totalCampaigns = $campaigns->total();
    $scheduledCount = $campaigns->where('status', 'scheduled')->count();
    $processingCount = $campaigns->where('status', 'processing')->count();
    $completedCount = $campaigns->where('status', 'completed')->count();

    $statusClass = function ($status) {
        return match ($status) {
            'draft' => 'cc-pill--draft',
            'scheduled' => 'cc-pill--scheduled',
            'approved' => 'cc-pill--approved',
            'processing' => 'cc-pill--processing',
            'completed' => 'cc-pill--completed',
            'failed', 'partially_failed' => 'cc-pill--failed',
            'cancelled' => 'cc-pill--cancelled',
            default => 'cc-pill--default',
        };
    };
@endphp

<div class="container-fluid cc-page">
    <div class="cc-hero">
        <div class="cc-hero__content">
            <div>
                <h1 class="cc-hero__title"><i class="fas fa-paper-plane me-2"></i>{{ db_trans('send_sms') }}</h1>
                <p class="cc-hero__subtitle">{{ db_trans('communication_sms_center_description') ?: 'Create, review, and track manual SMS campaigns from the Communication Center.' }}</p>
            </div>
            <div class="cc-hero__actions">
                <a href="{{ route('admin.communication.sms.create') }}" class="cc-primary-btn">
                    <i class="fas fa-plus-circle"></i>
                    <span>{{ db_trans('send_new_sms') ?: 'Send New SMS' }}</span>
                </a>
                @if (Route::has('admin.communication.dashboard'))
                    <a href="{{ route('admin.communication.dashboard') }}" class="cc-btn-light">
                        <i class="fas fa-chart-pie"></i>
                        <span>{{ db_trans('communication_center') }}</span>
                    </a>
                @endif
            </div>
        </div>
    </div>

    <div class="cc-kpis">
        <div class="cc-kpi"><div class="cc-kpi__row"><div><p class="cc-kpi__label">{{ db_trans('total_campaigns') ?: 'Total Campaigns' }}</p><h3 class="cc-kpi__value">{{ number_format($totalCampaigns) }}</h3></div><span class="cc-kpi__icon cc-kpi__icon--blue"><i class="fas fa-bullhorn"></i></span></div></div>
        <div class="cc-kpi"><div class="cc-kpi__row"><div><p class="cc-kpi__label">{{ db_trans('scheduled') }}</p><h3 class="cc-kpi__value">{{ number_format($scheduledCount) }}</h3></div><span class="cc-kpi__icon cc-kpi__icon--amber"><i class="fas fa-clock"></i></span></div></div>
        <div class="cc-kpi"><div class="cc-kpi__row"><div><p class="cc-kpi__label">{{ db_trans('processing') ?: 'Processing' }}</p><h3 class="cc-kpi__value">{{ number_format($processingCount) }}</h3></div><span class="cc-kpi__icon cc-kpi__icon--violet"><i class="fas fa-spinner"></i></span></div></div>
        <div class="cc-kpi"><div class="cc-kpi__row"><div><p class="cc-kpi__label">{{ db_trans('completed') ?: 'Completed' }}</p><h3 class="cc-kpi__value">{{ number_format($completedCount) }}</h3></div><span class="cc-kpi__icon cc-kpi__icon--green"><i class="fas fa-check-circle"></i></span></div></div>
    </div>

    <div class="cc-grid">
        <div class="cc-card">
            <div class="cc-card__header">
                <div>
                    <h2 class="cc-card__title"><i class="fas fa-list-ul text-primary"></i>{{ db_trans('sms_campaigns') ?: 'SMS Campaigns' }}</h2>
                    <p class="cc-card__subtitle">{{ db_trans('recent_sms_campaigns_and_status') ?: 'Recent manual SMS campaigns and their current status.' }}</p>
                </div>
                <a href="{{ route('admin.communication.sms.create') }}" class="cc-action-btn"><i class="fas fa-paper-plane"></i><span>{{ db_trans('new_sms') ?: 'New SMS' }}</span></a>
            </div>
            <div class="cc-card__body">
                @if (session('success'))
                    <div class="alert alert-success rounded-4 mb-3">{{ session('success') }}</div>
                @endif
                @if (session('error'))
                    <div class="alert alert-danger rounded-4 mb-3">{{ session('error') }}</div>
                @endif

                @if ($campaigns->count())
                    <div class="cc-table-wrap">
                        <table class="cc-table">
                            <thead>
                                <tr>
                                    <th>{{ db_trans('title') ?: 'Title' }}</th>
                                    <th>{{ db_trans('type') ?: 'Type' }}</th>
                                    <th>{{ db_trans('recipients') ?: 'Recipients' }}</th>
                                    <th>{{ db_trans('segments') ?: 'Segments' }}</th>
                                    <th>{{ db_trans('status') }}</th>
                                    <th>{{ db_trans('created') ?: 'Created' }}</th>
                                    <th>{{ db_trans('actions') ?: 'Actions' }}</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach ($campaigns as $campaign)
                                    <tr>
                                        <td><div class="fw-bold">{{ $campaign->title ?: (db_trans('untitled_campaign') ?: 'Untitled Campaign') }}</div><div class="cc-muted">{{ $campaign->channel ?? 'sms' }}</div></td>
                                        <td><span class="cc-muted">{{ str_replace('_', ' ', $campaign->type ?? '-') }}</span></td>
                                        <td>{{ number_format((int) ($campaign->total_recipients ?? 0)) }}</td>
                                        <td>{{ number_format((int) ($campaign->total_segments ?? 0)) }}</td>
                                        <td><span class="cc-pill {{ $statusClass($campaign->status) }}"><i class="fas fa-circle" style="font-size:.45rem;"></i>{{ str_replace('_', ' ', $campaign->status ?? 'unknown') }}</span></td>
                                        <td><div>{{ optional($campaign->created_at)->format('d M Y') }}</div><div class="cc-muted">{{ optional($campaign->created_at)->format('H:i') }}</div></td>
                                        <td>
                                            <div class="d-flex flex-wrap gap-2">
                                                @if (Route::has('admin.communication.schedules.index'))
                                                    <a href="{{ route('admin.communication.schedules.index') }}" class="cc-action-btn"><i class="fas fa-calendar-alt"></i><span>{{ db_trans('schedule') ?: 'Schedule' }}</span></a>
                                                @endif
                                                @if (Route::has('admin.communication.logs.index'))
                                                    <a href="{{ route('admin.communication.logs.index') }}" class="cc-action-btn"><i class="fas fa-file-alt"></i><span>{{ db_trans('logs') ?: 'Logs' }}</span></a>
                                                @endif
                                            </div>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    <div class="mt-3">{{ $campaigns->links() }}</div>
                @else
                    <div class="cc-empty">
                        <i class="fas fa-inbox d-block"></i>
                        <div class="fw-bold mb-1">{{ db_trans('no_sms_campaigns_found') ?: 'No SMS campaigns found.' }}</div>
                        <div>{{ db_trans('start_by_creating_your_first_sms_campaign') ?: 'Start by creating your first SMS campaign.' }}</div>
                        <div class="mt-3">
                            <a href="{{ route('admin.communication.sms.create') }}" class="cc-primary-btn"><i class="fas fa-plus-circle"></i><span>{{ db_trans('send_new_sms') ?: 'Send New SMS' }}</span></a>
                        </div>
                    </div>
                @endif
            </div>
        </div>

        <div class="cc-card">
            <div class="cc-card__header">
                <div>
                    <h2 class="cc-card__title"><i class="fas fa-bolt text-warning"></i>{{ db_trans('quick_actions') ?: 'Quick Actions' }}</h2>
                    <p class="cc-card__subtitle">{{ db_trans('common_communication_tasks') ?: 'Common communication tasks from the center.' }}</p>
                </div>
            </div>
            <div class="cc-card__body">
                <div class="cc-mini-list">
                    <a href="{{ route('admin.communication.sms.create') }}" class="text-decoration-none">
                        <div class="cc-mini-item"><div class="cc-mini-item__icon"><i class="fas fa-paper-plane"></i></div><div><p class="cc-mini-item__title">{{ db_trans('send_single_or_bulk_sms') ?: 'Send single or bulk SMS' }}</p><p class="cc-mini-item__text">{{ db_trans('create_manual_sms_campaign_for_selected_recipients') ?: 'Create a manual SMS campaign for selected recipients.' }}</p></div></div>
                    </a>
                    @if (Route::has('admin.communication.templates.index'))
                        <a href="{{ route('admin.communication.templates.index') }}" class="text-decoration-none">
                            <div class="cc-mini-item"><div class="cc-mini-item__icon" style="background:linear-gradient(135deg,#7c3aed,#6d28d9);"><i class="fas fa-file-alt"></i></div><div><p class="cc-mini-item__title">{{ db_trans('manage_templates') ?: 'Manage templates' }}</p><p class="cc-mini-item__text">{{ db_trans('edit_and_reuse_sms_templates') ?: 'Edit and reuse SMS templates.' }}</p></div></div>
                        </a>
                    @endif
                    @if (Route::has('admin.communication.automations.index'))
                        <a href="{{ route('admin.communication.automations.index') }}" class="text-decoration-none">
                            <div class="cc-mini-item"><div class="cc-mini-item__icon" style="background:linear-gradient(135deg,#16a34a,#15803d);"><i class="fas fa-robot"></i></div><div><p class="cc-mini-item__title">{{ db_trans('automation_rules') ?: 'Automation rules' }}</p><p class="cc-mini-item__text">{{ db_trans('configure_auto_messages_for_events') ?: 'Configure automatic messages for system events.' }}</p></div></div>
                        </a>
                    @endif
                    @if (Route::has('admin.communication.balance.index'))
                        <a href="{{ route('admin.communication.balance.index') }}" class="text-decoration-none">
                            <div class="cc-mini-item"><div class="cc-mini-item__icon" style="background:linear-gradient(135deg,#f59e0b,#d97706);"><i class="fas fa-wallet"></i></div><div><p class="cc-mini-item__title">{{ db_trans('check_sms_balance') ?: 'Check SMS balance' }}</p><p class="cc-mini-item__text">{{ db_trans('review_balance_usage_and_recent_activity') ?: 'Review balance, usage, and recent activity.' }}</p></div></div>
                        </a>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
