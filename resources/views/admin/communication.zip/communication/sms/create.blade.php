@extends('layouts.admin')

@section('title', db_trans('send_sms'))

@push('styles')
<link rel="stylesheet" href="{{ asset('assets/admin/css/communication-center-sms.css') }}">
@endpush

@section('content')
<div class="container-fluid cc-page">
    <div class="cc-hero">
        <div class="cc-hero__content">
            <div>
                <h1 class="cc-hero__title"><i class="fas fa-paper-plane me-2"></i>{{ db_trans('send_new_sms') ?: 'Send New SMS' }}</h1>
                <p class="cc-hero__subtitle">{{ db_trans('communication_compose_sms_description') ?: 'Create a manual SMS campaign, preview recipients and message segments, then send now or schedule for later.' }}</p>
            </div>
            <div class="cc-hero__actions">
                <a href="{{ route('admin.communication.sms.index') }}" class="cc-btn-light"><i class="fas fa-arrow-left"></i><span>{{ db_trans('back_to_campaigns') ?: 'Back to Campaigns' }}</span></a>
            </div>
        </div>
    </div>

    <form method="POST" action="{{ route('admin.communication.sms.store') }}" id="communicationSmsForm">
        @csrf
        <div class="cc-form-grid">
            <div class="cc-card">
                <div class="cc-card__header">
                    <div>
                        <h2 class="cc-card__title"><i class="fas fa-edit text-primary"></i>{{ db_trans('compose_message') ?: 'Compose Message' }}</h2>
                        <p class="cc-card__subtitle">{{ db_trans('write_sms_and_choose_audience') ?: 'Write your SMS and choose the audience to receive it.' }}</p>
                    </div>
                </div>
                <div class="cc-card__body">
                    @if ($errors->any())
                        <div class="alert alert-danger rounded-4 mb-3">
                            <ul class="mb-0 ps-3">
                                @foreach ($errors->all() as $error)
                                    <li>{{ $error }}</li>
                                @endforeach
                            </ul>
                        </div>
                    @endif
                    @if (session('error'))
                        <div class="alert alert-danger rounded-4 mb-3">{{ session('error') }}</div>
                    @endif

                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">{{ db_trans('title') ?: 'Title' }}</label>
                            <input type="text" name="title" value="{{ old('title') }}" class="form-control form-control-lg rounded-4" placeholder="{{ db_trans('optional_campaign_title') ?: 'Optional campaign title' }}">
                        </div>
                        <div class="col-md-6">
                            <label class="form-label fw-semibold">{{ db_trans('audience') ?: 'Audience' }}</label>
                            <select name="audience_type" id="audienceType" class="form-select form-select-lg rounded-4" required>
                                <option value="all_members" {{ old('audience_type') === 'all_members' ? 'selected' : '' }}>{{ db_trans('all_members') ?: 'All Members' }}</option>
                                <option value="all_active_members" {{ old('audience_type') === 'all_active_members' ? 'selected' : '' }}>{{ db_trans('all_active_members') ?: 'All Active Members' }}</option>
                                <option value="member" {{ old('audience_type') === 'member' ? 'selected' : '' }}>{{ db_trans('single_member') ?: 'Single Member' }}</option>
                                <option value="familia" {{ old('audience_type') === 'familia' ? 'selected' : '' }}>{{ db_trans('single_familia') ?: 'Single Familia' }}</option>
                                <option value="jumuiya" {{ old('audience_type') === 'jumuiya' ? 'selected' : '' }}>{{ db_trans('single_jumuiya') ?: 'Single Jumuiya' }}</option>
                                <option value="kanda" {{ old('audience_type') === 'kanda' ? 'selected' : '' }}>{{ db_trans('single_kanda') ?: 'Single Kanda' }}</option>
                                <option value="filtered_members" {{ old('audience_type') === 'filtered_members' ? 'selected' : '' }}>{{ db_trans('filtered_members') ?: 'Filtered Members' }}</option>
                            </select>
                        </div>

                        <div class="col-md-6 cc-target-field" data-audience="member">
                            <label class="form-label fw-semibold">{{ db_trans('member_id') ?: 'Member ID' }}</label>
                            <input type="number" name="member_id" value="{{ old('member_id') }}" class="form-control rounded-4" placeholder="e.g. 1">
                        </div>
                        <div class="col-md-6 cc-target-field" data-audience="familia">
                            <label class="form-label fw-semibold">{{ db_trans('familia_id') ?: 'Familia ID' }}</label>
                            <input type="number" name="familia_id" value="{{ old('familia_id') }}" class="form-control rounded-4" placeholder="e.g. 1">
                        </div>
                        <div class="col-md-6 cc-target-field" data-audience="jumuiya">
                            <label class="form-label fw-semibold">{{ db_trans('jumuiya_id') ?: 'Jumuiya ID' }}</label>
                            <input type="number" name="jumuiya_id" value="{{ old('jumuiya_id') }}" class="form-control rounded-4" placeholder="e.g. 1">
                        </div>
                        <div class="col-md-6 cc-target-field" data-audience="kanda">
                            <label class="form-label fw-semibold">{{ db_trans('kanda_id') ?: 'Kanda ID' }}</label>
                            <input type="number" name="kanda_id" value="{{ old('kanda_id') }}" class="form-control rounded-4" placeholder="e.g. 1">
                        </div>

                        <div class="col-12 cc-target-field" data-audience="filtered_members">
                            <div class="cc-filter-grid">
                                <div>
                                    <label class="form-label fw-semibold">{{ db_trans('gender') ?: 'Gender' }}</label>
                                    <select name="filters[gender]" class="form-select rounded-4">
                                        <option value="">{{ db_trans('all') ?: 'All' }}</option>
                                        <option value="male" {{ old('filters.gender') === 'male' ? 'selected' : '' }}>{{ db_trans('male') ?: 'Male' }}</option>
                                        <option value="female" {{ old('filters.gender') === 'female' ? 'selected' : '' }}>{{ db_trans('female') ?: 'Female' }}</option>
                                    </select>
                                </div>
                                <div>
                                    <label class="form-label fw-semibold">{{ db_trans('age_group_id') ?: 'Age Group ID' }}</label>
                                    <input type="number" name="filters[age_group_id]" value="{{ old('filters.age_group_id') }}" class="form-control rounded-4" placeholder="e.g. 1">
                                </div>
                                <div>
                                    <label class="form-label fw-semibold">{{ db_trans('kanda_id') ?: 'Kanda ID' }}</label>
                                    <input type="number" name="filters[kanda_id]" value="{{ old('filters.kanda_id') }}" class="form-control rounded-4">
                                </div>
                                <div>
                                    <label class="form-label fw-semibold">{{ db_trans('jumuiya_id') ?: 'Jumuiya ID' }}</label>
                                    <input type="number" name="filters[jumuiya_id]" value="{{ old('filters.jumuiya_id') }}" class="form-control rounded-4">
                                </div>
                                <div>
                                    <label class="form-label fw-semibold">{{ db_trans('familia_id') ?: 'Familia ID' }}</label>
                                    <input type="number" name="filters[familia_id]" value="{{ old('filters.familia_id') }}" class="form-control rounded-4">
                                </div>
                                <div>
                                    <label class="form-label fw-semibold">{{ db_trans('active_status') ?: 'Active Status' }}</label>
                                    <select name="filters[is_active]" class="form-select rounded-4">
                                        <option value="">{{ db_trans('all') ?: 'All' }}</option>
                                        <option value="1" {{ old('filters.is_active') === '1' ? 'selected' : '' }}>{{ db_trans('active') ?: 'Active' }}</option>
                                        <option value="0" {{ old('filters.is_active') === '0' ? 'selected' : '' }}>{{ db_trans('inactive') ?: 'Inactive' }}</option>
                                    </select>
                                </div>
                            </div>
                        </div>

                        <div class="col-12">
                            <label class="form-label fw-semibold">{{ db_trans('message') ?: 'Message' }}</label>
                            <textarea name="message" id="messageBody" rows="8" class="form-control rounded-4 cc-message-box" placeholder="{{ db_trans('type_your_sms_here') ?: 'Type your SMS here...' }}" required>{{ old('message') }}</textarea>
                            <div class="cc-muted mt-2">{{ db_trans('sms_character_notice') ?: 'SMS segments are calculated automatically for GSM-7 and Unicode messages.' }}</div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="cc-side-stack">
                <div class="cc-card">
                    <div class="cc-card__header">
                        <div>
                            <h2 class="cc-card__title"><i class="fas fa-chart-bar text-success"></i>{{ db_trans('delivery_preview') ?: 'Delivery Preview' }}</h2>
                            <p class="cc-card__subtitle">{{ db_trans('review_recipient_count_and_sms_segments') ?: 'Review recipient count and estimated SMS segments.' }}</p>
                        </div>
                    </div>
                    <div class="cc-card__body">
                        <div class="cc-preview-grid">
                            <div class="cc-preview-box"><span class="cc-preview-box__label">{{ db_trans('recipients') ?: 'Recipients' }}</span><strong id="previewRecipients">0</strong></div>
                            <div class="cc-preview-box"><span class="cc-preview-box__label">{{ db_trans('segments') ?: 'Segments' }}</span><strong id="previewSegments">0</strong></div>
                            <div class="cc-preview-box"><span class="cc-preview-box__label">{{ db_trans('total_segments') ?: 'Total Segments' }}</span><strong id="previewTotalSegments">0</strong></div>
                            <div class="cc-preview-box"><span class="cc-preview-box__label">{{ db_trans('encoding') ?: 'Encoding' }}</span><strong id="previewEncoding">-</strong></div>
                        </div>
                        <button type="button" id="previewBtn" class="cc-primary-btn w-100 mt-3"><i class="fas fa-search"></i><span>{{ db_trans('preview') ?: 'Preview' }}</span></button>
                    </div>
                </div>

                <div class="cc-card">
                    <div class="cc-card__header">
                        <div>
                            <h2 class="cc-card__title"><i class="fas fa-calendar-alt text-warning"></i>{{ db_trans('send_options') ?: 'Send Options' }}</h2>
                            <p class="cc-card__subtitle">{{ db_trans('choose_when_to_send_this_campaign') ?: 'Choose whether to send now or schedule later.' }}</p>
                        </div>
                    </div>
                    <div class="cc-card__body">
                        <div class="mb-3">
                            <label class="form-label fw-semibold">{{ db_trans('send_mode') ?: 'Send Mode' }}</label>
                            <select name="send_mode" id="sendMode" class="form-select rounded-4">
                                <option value="now" {{ old('send_mode', 'now') === 'now' ? 'selected' : '' }}>{{ db_trans('send_now') ?: 'Send Now' }}</option>
                                <option value="later" {{ old('send_mode') === 'later' ? 'selected' : '' }}>{{ db_trans('schedule_for_later') ?: 'Schedule for Later' }}</option>
                            </select>
                        </div>

                        <div id="scheduledAtWrap" class="{{ old('send_mode') === 'later' ? '' : 'd-none' }}">
                            <label class="form-label fw-semibold">{{ db_trans('scheduled_at') ?: 'Scheduled At' }}</label>
                            <input type="datetime-local" name="scheduled_at" value="{{ old('scheduled_at') }}" class="form-control rounded-4">
                        </div>

                        <button type="submit" class="cc-primary-btn w-100 mt-4"><i class="fas fa-paper-plane"></i><span>{{ db_trans('save_and_continue') ?: 'Save and Continue' }}</span></button>
                    </div>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection

@push('scripts')
<script src="{{ asset('assets/admin/js/communication-sms.js') }}"></script>
<script>
window.communicationSmsConfig = {
    previewUrl: @json(route('admin.communication.sms.preview')),
    csrfToken: @json(csrf_token()),
};
</script>
@endpush
