@extends('layouts.admin')

@section('title', db_trans('communication.dashboard_title'))


@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/communication-center.css') }}">
@endpush

@section('content')
<div class="container-fluid communication-center-page">
    <div class="cc-hero cc-hero--dashboard mb-4">
        <div class="cc-hero__content">
            <span class="cc-kicker">{{ db_trans('communication.kicker') }}</span>
            <h1 class="cc-hero__title">{{ db_trans('communication.dashboard_title') }}</h1>
            <p class="cc-hero__text">{{ db_trans('communication.dashboard_subtitle') }}</p>

            <div class="cc-chip-row">
                <span class="cc-chip"><i class="bi bi-chat-dots"></i> {{ db_trans('communication.channel_sms') }}</span>
                <span class="cc-chip"><i class="bi bi-clock-history"></i> {{ db_trans('communication.queue_ready') }}</span>
                <span class="cc-chip"><i class="bi bi-translate"></i> {{ app()->getLocale() }}</span>
            </div>
        </div>

        <div class="cc-hero__actions">
            <a href="{{ route('admin.communication.sms.create') }}" class="cc-action-card">
                <i class="bi bi-send-plus"></i>
                <span>{{ db_trans('communication.send_sms') }}</span>
            </a>
            <a href="{{ route('admin.communication.templates.index') }}" class="cc-action-card">
                <i class="bi bi-layout-text-window"></i>
                <span>{{ db_trans('communication.templates') }}</span>
            </a>
            <a href="{{ route('admin.communication.logs.index') }}" class="cc-action-card">
                <i class="bi bi-journal-text"></i>
                <span>{{ db_trans('communication.logs') }}</span>
            </a>
            <a href="{{ route('admin.communication.balance.index') }}" class="cc-action-card">
                <i class="bi bi-wallet2"></i>
                <span>{{ db_trans('communication.balance') }}</span>
            </a>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-xl-3 col-md-6">
            <div class="cc-kpi-card cc-kpi-card--violet">
                <div class="cc-kpi-card__icon"><i class="bi bi-chat-square-text"></i></div>
                <div class="cc-kpi-card__body">
                    <span class="cc-kpi-card__label">{{ db_trans('communication.messages_today') }}</span>
                    <h3>{{ number_format($kpis['messages_today']) }}</h3>
                    <small>{{ db_trans('communication.live_snapshot') }}</small>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="cc-kpi-card cc-kpi-card--blue">
                <div class="cc-kpi-card__icon"><i class="bi bi-check2-circle"></i></div>
                <div class="cc-kpi-card__body">
                    <span class="cc-kpi-card__label">{{ db_trans('communication.sent_today') }}</span>
                    <h3>{{ number_format($kpis['sent_today']) }}</h3>
                    <small>{{ db_trans('communication.successful_sends') }}</small>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="cc-kpi-card cc-kpi-card--amber">
                <div class="cc-kpi-card__icon"><i class="bi bi-calendar2-week"></i></div>
                <div class="cc-kpi-card__body">
                    <span class="cc-kpi-card__label">{{ db_trans('communication.scheduled_campaigns') }}</span>
                    <h3>{{ number_format($kpis['scheduled_count']) }}</h3>
                    <small>{{ db_trans('communication.awaiting_dispatch') }}</small>
                </div>
            </div>
        </div>
        <div class="col-xl-3 col-md-6">
            <div class="cc-kpi-card cc-kpi-card--emerald">
                <div class="cc-kpi-card__icon"><i class="bi bi-wallet"></i></div>
                <div class="cc-kpi-card__body">
                    <span class="cc-kpi-card__label">{{ db_trans('communication.current_balance') }}</span>
                    <h3>{{ number_format((float) optional($latest_balance)->balance_units, 0) }}</h3>
                    <small>{{ optional($latest_balance)->fetched_at ? optional($latest_balance)->fetched_at->diffForHumans() : db_trans('communication.no_balance_snapshot') }}</small>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3 mb-4">
        <div class="col-xl-8">
            <div class="cc-panel h-100">
                <div class="cc-panel__header">
                    <div>
                        <h5>{{ db_trans('communication.recent_campaigns') }}</h5>
                        <p>{{ db_trans('communication.recent_campaigns_desc') }}</p>
                    </div>
                    <a href="{{ route('admin.communication.logs.index') }}" class="cc-link">{{ db_trans('communication.view_all') }}</a>
                </div>

                <div class="table-responsive">
                    <table class="table cc-table align-middle mb-0">
                        <thead>
                            <tr>
                                <th>{{ db_trans('communication.title') }}</th>
                                <th>{{ db_trans('communication.status') }}</th>
                                <th>{{ db_trans('communication.recipients') }}</th>
                                <th>{{ db_trans('communication.created') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($recent_campaigns as $campaign)
                                <tr>
                                    <td>
                                        <strong>{{ $campaign->title }}</strong>
                                        <div class="text-muted small">{{ $campaign->type }}</div>
                                    </td>
                                    <td><span class="cc-status cc-status--{{ str_replace('_', '-', $campaign->status) }}">{{ ucfirst(str_replace('_', ' ', $campaign->status)) }}</span></td>
                                    <td>{{ number_format($campaign->total_recipients ?? 0) }}</td>
                                    <td>{{ optional($campaign->created_at)->format('d M Y, H:i') }}</td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center py-4 text-muted">{{ db_trans('communication.no_campaigns_found') }}</td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="col-xl-4">
            <div class="cc-panel h-100">
                <div class="cc-panel__header">
                    <div>
                        <h5>{{ db_trans('communication.delivery_overview') }}</h5>
                        <p>{{ db_trans('communication.delivery_overview_desc') }}</p>
                    </div>
                </div>

                <div class="cc-stat-stack">
                    @forelse($status_breakdown as $status => $total)
                        <div class="cc-stat-row">
                            <span class="cc-status cc-status--{{ str_replace('_', '-', $status) }}">{{ ucfirst(str_replace('_', ' ', $status)) }}</span>
                            <strong>{{ number_format($total) }}</strong>
                        </div>
                    @empty
                        <p class="text-muted mb-0">{{ db_trans('communication.no_delivery_data') }}</p>
                    @endforelse
                </div>
            </div>
        </div>
    </div>

    <div class="row g-3">
        <div class="col-xl-7">
            <div class="cc-panel h-100">
                <div class="cc-panel__header">
                    <div>
                        <h5>{{ db_trans('communication.recent_failures') }}</h5>
                        <p>{{ db_trans('communication.recent_failures_desc') }}</p>
                    </div>
                </div>

                <div class="cc-list">
                    @forelse($recent_failures as $failure)
                        <div class="cc-list-item">
                            <div>
                                <strong>{{ $failure->recipient_name ?: $failure->recipient_phone }}</strong>
                                <div class="small text-muted">{{ $failure->recipient_phone_normalized ?: $failure->recipient_phone }}</div>
                            </div>
                            <div class="text-end">
                                <div class="small text-danger">{{ $failure->error_message ?: db_trans('communication.unknown_failure') }}</div>
                                <div class="small text-muted">{{ optional($failure->failed_at ?? $failure->created_at)->diffForHumans() }}</div>
                            </div>
                        </div>
                    @empty
                        <p class="text-muted mb-0">{{ db_trans('communication.no_recent_failures') }}</p>
                    @endforelse
                </div>
            </div>
        </div>

        <div class="col-xl-5">
            <div class="cc-panel h-100">
                <div class="cc-panel__header">
                    <div>
                        <h5>{{ db_trans('communication.campaign_health') }}</h5>
                        <p>{{ db_trans('communication.campaign_health_desc') }}</p>
                    </div>
                </div>

                <div class="row g-3">
                    <div class="col-6">
                        <div class="cc-mini-kpi">
                            <span>{{ db_trans('communication.total_campaigns') }}</span>
                            <h4>{{ number_format($completion['total_campaigns']) }}</h4>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="cc-mini-kpi">
                            <span>{{ db_trans('communication.completed') }}</span>
                            <h4>{{ number_format($completion['completed_campaigns']) }}</h4>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="cc-mini-kpi">
                            <span>{{ db_trans('communication.partial_failures') }}</span>
                            <h4>{{ number_format($completion['partial_campaigns']) }}</h4>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="cc-mini-kpi">
                            <span>{{ db_trans('communication.failed_campaigns') }}</span>
                            <h4>{{ number_format($completion['failed_campaigns']) }}</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
