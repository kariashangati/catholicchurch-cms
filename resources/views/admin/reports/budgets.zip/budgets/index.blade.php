@extends('layouts.admin')

@section('title', db_trans('budget_reports'))
@section('disable_default_alerts')@endsection

@push('styles')
<link rel="stylesheet" href="{{ asset('admin/css/reports-v4-polish.css') }}">
@endpush

@section('content')
<div class="admin-ui-v4 reports-v4-page">
    <div class="ui-page-hero">
        <div class="ui-hero-pattern"></div>
        <div class="row g-4 align-items-center position-relative">
            <div class="col-xl-8">
                <span class="ui-page-badge"><i class="fas fa-scale-balanced"></i>{{ db_trans('budget_reports') }}</span>
                <h1 class="ui-page-title mt-3">{{ $pageTitle }}</h1>
                <p class="ui-page-subtitle">{{ db_trans('budget_vs_actual') }}</p>
            </div>
            <div class="col-xl-4">
                <form method="GET" class="d-flex gap-2">
                    <input type="number" class="form-control" name="year" value="{{ $year }}">
                    <button class="btn ui-btn-primary">{{ db_trans('load') }}</button>
                </form>
            </div>
        </div>
    </div>

    <div class="row g-4 mb-4 ui-kpi-grid">
        <div class="col-lg-3 col-md-6"><div class="card ui-stat-card ui-tone-primary border-0 h-100"><div class="card-body"><div class="ui-stat-top"><div class="ui-stat-icon"><i class="fas fa-arrow-up"></i></div><span class="ui-chip">{{ db_trans('budget') }}</span></div><div class="ui-stat-label">{{ db_trans('income_budget_total') }}</div><div class="ui-stat-value">{{ number_format($incomeBudgetTotal, 2) }}</div><div class="ui-stat-meta">{{ db_trans('income_budget_estimates') }}</div></div></div></div>
        <div class="col-lg-3 col-md-6"><div class="card ui-stat-card ui-tone-success border-0 h-100"><div class="card-body"><div class="ui-stat-top"><div class="ui-stat-icon"><i class="fas fa-sack-dollar"></i></div><span class="ui-chip">{{ db_trans('actual') }}</span></div><div class="ui-stat-label">{{ db_trans('income_actual_total') }}</div><div class="ui-stat-value">{{ number_format($incomeActualTotal, 2) }}</div><div class="ui-stat-meta">{{ db_trans('income') }}</div></div></div></div>
        <div class="col-lg-3 col-md-6"><div class="card ui-stat-card ui-tone-warning border-0 h-100"><div class="card-body"><div class="ui-stat-top"><div class="ui-stat-icon"><i class="fas fa-arrow-down"></i></div><span class="ui-chip">{{ db_trans('budget') }}</span></div><div class="ui-stat-label">{{ db_trans('expense_budget_total') }}</div><div class="ui-stat-value">{{ number_format($expenseBudgetTotal, 2) }}</div><div class="ui-stat-meta">{{ db_trans('expense_budget_estimates') }}</div></div></div></div>
        <div class="col-lg-3 col-md-6"><div class="card ui-stat-card ui-tone-danger border-0 h-100"><div class="card-body"><div class="ui-stat-top"><div class="ui-stat-icon"><i class="fas fa-receipt"></i></div><span class="ui-chip">{{ db_trans('actual') }}</span></div><div class="ui-stat-label">{{ db_trans('expense_actual_total') }}</div><div class="ui-stat-value">{{ number_format($expenseActualTotal, 2) }}</div><div class="ui-stat-meta">{{ db_trans('expense') }}</div></div></div></div>
    </div>

    @can('reports.budgets.create')
    <div class="row g-4 mb-4">
        <div class="col-lg-6">
            <div class="card ui-panel border-0 h-100">
                <div class="card-header">{{ db_trans('add_income_budget_line') }}</div>
                <div class="card-body">
                    <form method="POST" action="{{ route('reports.budgets.income.store') }}" class="row g-3">
                        @csrf
                        <div class="col-md-4"><input class="form-control" name="category_code" placeholder="Code e.g. offerings"></div>
                        <div class="col-md-4"><input class="form-control" name="category_name" placeholder="{{ db_trans('category') }}" required></div>
                        <div class="col-md-4"><input class="form-control" name="group_name" placeholder="Group" required></div>
                        <div class="col-md-4"><input class="form-control" type="number" step="0.01" min="0" name="amount" placeholder="{{ db_trans('amount') }}" required></div>
                        <div class="col-md-4"><input class="form-control" type="number" name="budget_year" value="{{ $year }}" required></div>
                        <div class="col-md-4"><button class="btn ui-btn-primary w-100">{{ db_trans('save') }}</button></div>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card ui-panel border-0 h-100">
                <div class="card-header">{{ db_trans('add_expense_budget_line') }}</div>
                <div class="card-body">
                    <form method="POST" action="{{ route('reports.budgets.expense.store') }}" class="row g-3">
                        @csrf
                        <div class="col-md-4"><input class="form-control" name="category_code" placeholder="Code e.g. project_expenses"></div>
                        <div class="col-md-4"><input class="form-control" name="category_name" placeholder="{{ db_trans('category') }}" required></div>
                        <div class="col-md-4"><input class="form-control" name="group_name" placeholder="Group" required></div>
                        <div class="col-md-4"><input class="form-control" type="number" step="0.01" min="0" name="amount" placeholder="{{ db_trans('amount') }}" required></div>
                        <div class="col-md-4"><input class="form-control" type="number" name="budget_year" value="{{ $year }}" required></div>
                        <div class="col-md-4"><button class="btn ui-btn-primary w-100">{{ db_trans('save') }}</button></div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    @endcan

    <div class="row g-4 mb-4">
        <div class="col-xl-7"><div class="card ui-panel border-0 h-100"><div class="card-body"><div class="ui-panel-head"><div><h5 class="ui-panel-title">{{ db_trans('budget_vs_actual') }}</h5><p class="ui-panel-subtitle mb-0">{{ db_trans('budget_overview') }}</p></div><div class="ui-panel-icon"><i class="fas fa-chart-column"></i></div></div><div class="ui-chart-shell ui-chart-shell-lg"><canvas id="budgetOverviewChart"></canvas></div></div></div></div>
        <div class="col-xl-5"><div class="card ui-panel border-0 h-100"><div class="card-body"><div class="ui-panel-head"><div><h5 class="ui-panel-title">{{ db_trans('budget_overview') }}</h5><p class="ui-panel-subtitle mb-0">{{ db_trans('variance') }}</p></div><div class="ui-panel-icon"><i class="fas fa-scale-balanced"></i></div></div><div class="ui-inline-stat-row"><span>{{ db_trans('income_budget_total') }}</span><strong>{{ number_format($incomeBudgetTotal, 2) }}</strong></div><div class="ui-inline-stat-row"><span>{{ db_trans('income_actual_total') }}</span><strong>{{ number_format($incomeActualTotal, 2) }}</strong></div><div class="ui-inline-stat-row"><span>{{ db_trans('expense_budget_total') }}</span><strong>{{ number_format($expenseBudgetTotal, 2) }}</strong></div><div class="ui-inline-stat-row"><span>{{ db_trans('expense_actual_total') }}</span><strong>{{ number_format($expenseActualTotal, 2) }}</strong></div></div></div></div>
    </div>

    <div class="row g-4">
        <div class="col-lg-6">
            <div class="card ui-table-card border-0 h-100">
                <div class="card-header"><h5 class="ui-panel-title mb-1">{{ db_trans('income_budget_lines') }}</h5></div>
                <div class="card-body p-0 table-responsive">
                    <table class="table align-middle mb-0">
                        <thead><tr><th>{{ db_trans('category') }}</th><th class="text-end">{{ db_trans('budget') }}</th><th class="text-end">{{ db_trans('actual') }}</th><th class="text-end">{{ db_trans('variance') }}</th><th></th></tr></thead>
                        <tbody>
                        @foreach($incomeRows as $row)
                            <tr>
                                <td><div class="fw-semibold">{{ $row['category_name'] }}</div><div class="text-muted small">{{ $row['category_code'] }}</div></td>
                                <td class="text-end">{{ number_format($row['budget_amount'],2) }}</td>
                                <td class="text-end">{{ number_format($row['actual_amount'],2) }}</td>
                                <td class="text-end fw-semibold">{{ number_format($row['variance'],2) }}</td>
                                <td class="text-end">
                                    @can('reports.budgets.delete')
                                    <form method="POST" action="{{ route('reports.budgets.income.destroy', $row['id']) }}" class="budget-delete-form" data-confirm="Delete this income budget line?">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-sm btn-outline-danger">{{ db_trans('delete') }}</button>
                                    </form>
                                    @endcan
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="col-lg-6">
            <div class="card ui-table-card border-0 h-100">
                <div class="card-header"><h5 class="ui-panel-title mb-1">{{ db_trans('expense_budget_lines') }}</h5></div>
                <div class="card-body p-0 table-responsive">
                    <table class="table align-middle mb-0">
                        <thead><tr><th>{{ db_trans('category') }}</th><th class="text-end">{{ db_trans('budget') }}</th><th class="text-end">{{ db_trans('actual') }}</th><th class="text-end">{{ db_trans('variance') }}</th><th></th></tr></thead>
                        <tbody>
                        @foreach($expenseRows as $row)
                            <tr>
                                <td><div class="fw-semibold">{{ $row['category_name'] }}</div><div class="text-muted small">{{ $row['category_code'] }}</div></td>
                                <td class="text-end">{{ number_format($row['budget_amount'],2) }}</td>
                                <td class="text-end">{{ number_format($row['actual_amount'],2) }}</td>
                                <td class="text-end fw-semibold">{{ number_format($row['variance'],2) }}</td>
                                <td class="text-end">
                                    @can('reports.budgets.delete')
                                    <form method="POST" action="{{ route('reports.budgets.expense.destroy', $row['id']) }}" class="budget-delete-form" data-confirm="Delete this expense budget line?">
                                        @csrf @method('DELETE')
                                        <button class="btn btn-sm btn-outline-danger">{{ db_trans('delete') }}</button>
                                    </form>
                                    @endcan
                                </td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@push('scripts')
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.budget-delete-form').forEach(function(form){
        form.addEventListener('submit', function(e){
            if (typeof Swal === 'undefined') return;
            e.preventDefault();
            Swal.fire({icon:'warning', title:@json(db_trans('are_you_sure')), text: form.dataset.confirm || 'Confirm action', showCancelButton:true, confirmButtonColor:'#7c3aed'}).then(function(result){ if(result.isConfirmed){ form.submit(); } });
        });
    });
    if (!window.Chart) return;
    const ctx = document.getElementById('budgetOverviewChart');
    if (!ctx) return;
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: [@json(db_trans('income')), @json(db_trans('expense'))],
            datasets: [
                { label: @json(db_trans('budget')), data: [{{ (float)$incomeBudgetTotal }}, {{ (float)$expenseBudgetTotal }}], borderWidth: 0 },
                { label: @json(db_trans('actual')), data: [{{ (float)$incomeActualTotal }}, {{ (float)$expenseActualTotal }}], borderWidth: 0 }
            ]
        },
        options: { maintainAspectRatio: false, responsive: true }
    });
});
</script>
@endpush
