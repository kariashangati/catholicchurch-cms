@extends('layouts.admin')

@section('title', db_trans('finance_reports'))
@section('disable_default_alerts')@endsection

@push('styles')
<link rel="stylesheet" href="{{ asset('admin/css/reports-v4-polish.css') }}">
@endpush

@section('content')
<div class="admin-ui-v4 reports-v4-page">
    <div class="ui-page-hero">
        <div class="ui-hero-pattern"></div>
        <div class="row g-4 align-items-center position-relative">
            <div class="col-xl-8">
                <span class="ui-page-badge"><i class="fas fa-chart-line"></i>{{ db_trans('finance_reports') }}</span>
                <h1 class="ui-page-title mt-3">{{ db_trans('finance_reports') }}</h1>
                <p class="ui-page-subtitle">{{ db_trans('finance_reports_dashboard_help') }}</p>
            </div>
            <div class="col-xl-4">
                <div class="ui-actions-grid">
                    <a href="" class="ui-hero-action"><span class="ui-hero-action-icon"><i class="fas fa-file-invoice-dollar"></i></span><span class="ui-hero-action-text">{{ db_trans('financial_summary') }}<small>{{ db_trans('open_report') }}</small></span></a>
                    <a href="{{ route('reports.finance.compliance') }}" class="ui-hero-action"><span class="ui-hero-action-icon"><i class="fas fa-shield-halved"></i></span><span class="ui-hero-action-text">{{ db_trans('contribution_compliance_report') }}<small>{{ db_trans('open_report') }}</small></span></a>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <div class="col-md-6"><div class="card ui-panel border-0 h-100"><div class="card-body"><div class="ui-panel-head"><div><div class="ui-data-label">{{ db_trans('financial_reports') }}</div><h4 class="ui-panel-title mb-2">{{ db_trans('financial_summary') }}</h4><p class="ui-panel-subtitle mb-0">{{ db_trans('income_vs_expense_and_budget_view') }}</p></div><div class="ui-panel-icon"><i class="fas fa-file-invoice-dollar"></i></div></div><a href="" class="btn ui-btn-primary btn-sm mt-3">{{ db_trans('open_report') }}</a></div></div></div>
        <div class="col-md-6"><div class="card ui-panel border-0 h-100"><div class="card-body"><div class="ui-panel-head"><div><div class="ui-data-label">{{ db_trans('financial_reports') }}</div><h4 class="ui-panel-title mb-2">{{ db_trans('contribution_compliance_report') }}</h4><p class="ui-panel-subtitle mb-0">{{ db_trans('track_who_paid_and_who_did_not_pay_by_period_and_type') }}</p></div><div class="ui-panel-icon"><i class="fas fa-shield-halved"></i></div></div><a href="{{ route('reports.finance.compliance') }}" class="btn ui-btn-primary btn-sm mt-3">{{ db_trans('open_report') }}</a></div></div></div>
    </div>
</div>
@endsection
