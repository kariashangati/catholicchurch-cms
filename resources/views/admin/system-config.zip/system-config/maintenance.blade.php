@extends('layouts.admin')

@section('title', db_trans('maintenance_access_control'))

@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/system-config.css') }}">
@endpush

@section('content')
    <div class="syscfg-shell">
        <div class="syscfg-hero syscfg-hero-maintenance">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div>
                    <h2 class="syscfg-hero-title">{{ db_trans('maintenance_access_control') }}</h2>
                    <p class="syscfg-hero-subtitle">{{ db_trans('control_global_and_page_level_maintenance_experiences') }}</p>
                </div>

                <a href="{{ route('system-config.dashboard') }}" class="btn btn-light">
                    <i class="fas fa-arrow-left me-2"></i>{{ db_trans('system_configuration_center') }}
                </a>
            </div>
        </div>

        <form method="POST" action="{{ route('system-config.maintenance.update') }}">
            @csrf
            @method('PUT')

            <div class="card syscfg-form-card">
                <div class="card-body">
                    <div class="syscfg-section-title">{{ db_trans('global_maintenance_mode') }}</div>

                    <div class="row g-3">
                        <div class="col-lg-4">
                            <label class="form-label">{{ db_trans('maintenance_status') }}</label>
                            <select name="global_enabled" class="form-select @error('global_enabled') is-invalid @enderror">
                                <option value="1" @selected((string) old('global_enabled', !empty($global['enabled']) ? '1' : '0') === '1')>{{ db_trans('enabled') }}</option>
                                <option value="0" @selected((string) old('global_enabled', !empty($global['enabled']) ? '1' : '0') === '0')>{{ db_trans('disabled') }}</option>
                            </select>
                            @error('global_enabled')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-lg-4">
                            <label class="form-label">{{ db_trans('use_laravel_maintenance_mode') }}</label>
                            <select name="use_laravel_down" class="form-select">
                                <option value="0">{{ db_trans('no') }}</option>
                                <option value="1">{{ db_trans('yes') }}</option>
                            </select>
                        </div>

                        <div class="col-lg-12">
                            <label class="form-label">{{ db_trans('maintenance_title') }}</label>
                            <input
                                type="text"
                                name="global_title"
                                value="{{ old('global_title', $global['title'] ?? '') }}"
                                class="form-control @error('global_title') is-invalid @enderror"
                            >
                            @error('global_title')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>

                        <div class="col-lg-12">
                            <label class="form-label">{{ db_trans('maintenance_message') }}</label>
                            <textarea
                                name="global_message"
                                rows="4"
                                class="form-control @error('global_message') is-invalid @enderror"
                            >{{ old('global_message', $global['message'] ?? '') }}</textarea>
                            @error('global_message')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>
            </div>

            <div class="card syscfg-form-card">
                <div class="card-body">
                    <div class="syscfg-section-title">{{ db_trans('page_level_maintenance') }}</div>

                    <div class="syscfg-repeater-list">
                        @foreach($suggestedRoutes as $index => $routeName)
                            @php
                                $routeData = $routes[$routeName] ?? [];
                            @endphp

                            <div class="syscfg-repeater-item">
                                <div class="row g-3">
                                    <div class="col-lg-3">
                                        <label class="form-label">{{ db_trans('route_name') }}</label>
                                        <input type="text" name="routes[{{ $index }}][name]" value="{{ old("routes.$index.name", $routeName) }}" class="form-control">
                                    </div>

                                    <div class="col-lg-2">
                                        <label class="form-label">{{ db_trans('status') }}</label>
                                        <select name="routes[{{ $index }}][enabled]" class="form-select">
                                            <option value="0" @selected((string) old("routes.$index.enabled", !empty($routeData['enabled']) ? '1' : '0') === '0')>{{ db_trans('disabled') }}</option>
                                            <option value="1" @selected((string) old("routes.$index.enabled", !empty($routeData['enabled']) ? '1' : '0') === '1')>{{ db_trans('enabled') }}</option>
                                        </select>
                                    </div>

                                    <div class="col-lg-3">
                                        <label class="form-label">{{ db_trans('maintenance_title') }}</label>
                                        <input type="text" name="routes[{{ $index }}][title]" value="{{ old("routes.$index.title", $routeData['title'] ?? '') }}" class="form-control">
                                    </div>

                                    <div class="col-lg-4">
                                        <label class="form-label">{{ db_trans('maintenance_message') }}</label>
                                        <input type="text" name="routes[{{ $index }}][message]" value="{{ old("routes.$index.message", $routeData['message'] ?? '') }}" class="form-control">
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="syscfg-sticky-actions d-flex justify-content-end gap-2">
                <a href="{{ route('system-config.dashboard') }}" class="btn btn-outline-secondary px-4">
                    {{ db_trans('cancel') }}
                </a>

                <button type="submit" class="btn btn-warning px-4">
                    <i class="fas fa-tools me-2"></i>{{ db_trans('save_changes') }}
                </button>
            </div>
        </form>
    </div>
@endsection
@push('scripts')
    <script src="{{ asset('admin/js/system-config.js') }}"></script>
@endpush