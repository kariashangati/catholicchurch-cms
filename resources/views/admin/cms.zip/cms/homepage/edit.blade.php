@extends('layouts.admin')

@section('title', db_trans('homepage_builder'))

@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/cms.css') }}">
@endpush

@section('content')
    <div class="cms-shell">
        <div class="cms-hero cms-hero-homepage">
            <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">
                <div>
                    <h2 class="cms-hero-title">{{ db_trans('homepage_builder') }}</h2>
                    <p class="cms-hero-subtitle">{{ db_trans('manage_homepage_sections_and_visibility') }}</p>
                </div>

                <a href="{{ route('cms.dashboard') }}" class="btn btn-light">
                    <i class="fas fa-arrow-left me-2"></i>{{ db_trans('content_management_center') }}
                </a>
            </div>
        </div>

        <form method="POST" action="{{ route('cms.homepage.update') }}">
            @csrf
            @method('PUT')

            <div class="card cms-form-card">
                <div class="card-body">
                    <div class="cms-section-title">{{ db_trans('hero_settings') }}</div>

                    <div class="row g-3">
                        <div class="col-lg-4">
                            <label class="form-label">{{ db_trans('hero_badge') }}</label>
                            <input type="text" name="hero_badge" value="{{ old('hero_badge', $heroSettings['hero_badge'] ?? '') }}" class="form-control">
                        </div>

                        <div class="col-lg-4">
                            <label class="form-label">{{ db_trans('enable_video') }}</label>
                            <select name="enable_video" class="form-select">
                                <option value="1" @selected((string) old('enable_video', !empty($heroSettings['enable_video']) ? '1' : '0') === '1')>{{ db_trans('enabled') }}</option>
                                <option value="0" @selected((string) old('enable_video', !empty($heroSettings['enable_video']) ? '1' : '0') === '0')>{{ db_trans('disabled') }}</option>
                            </select>
                        </div>

                        <div class="col-lg-4">
                            <label class="form-label">{{ db_trans('overlay_opacity') }}</label>
                            <input type="number" step="0.01" min="0" max="1" name="overlay_opacity" value="{{ old('overlay_opacity', $heroSettings['overlay_opacity'] ?? '0.50') }}" class="form-control">
                        </div>

                        <div class="col-lg-6">
                            <label class="form-label">{{ db_trans('video_url') }}</label>
                            <input type="text" name="video_url" value="{{ old('video_url', $heroSettings['video_url'] ?? '') }}" class="form-control">
                        </div>

                        <div class="col-lg-6">
                            <label class="form-label">{{ db_trans('poster_url') }}</label>
                            <input type="text" name="poster_url" value="{{ old('poster_url', $heroSettings['poster_url'] ?? '') }}" class="form-control">
                        </div>

                        <div class="col-lg-6">
                            <label class="form-label">{{ db_trans('image_url') }}</label>
                            <input type="text" name="image_url" value="{{ old('image_url', $heroSettings['image_url'] ?? '') }}" class="form-control">
                        </div>

                        <div class="col-lg-6">
                            <label class="form-label">{{ db_trans('mobile_image_url') }}</label>
                            <input type="text" name="mobile_image_url" value="{{ old('mobile_image_url', $heroSettings['mobile_image_url'] ?? '') }}" class="form-control">
                        </div>

                        <div class="col-lg-3">
                            <label class="form-label">{{ db_trans('primary_button_text') }}</label>
                            <input type="text" name="cta_primary_text" value="{{ old('cta_primary_text', $heroSettings['cta_primary_text'] ?? '') }}" class="form-control">
                        </div>

                        <div class="col-lg-3">
                            <label class="form-label">{{ db_trans('primary_button_link') }}</label>
                            <input type="text" name="cta_primary_link" value="{{ old('cta_primary_link', $heroSettings['cta_primary_link'] ?? '') }}" class="form-control">
                        </div>

                        <div class="col-lg-3">
                            <label class="form-label">{{ db_trans('secondary_button_text') }}</label>
                            <input type="text" name="cta_secondary_text" value="{{ old('cta_secondary_text', $heroSettings['cta_secondary_text'] ?? '') }}" class="form-control">
                        </div>

                        <div class="col-lg-3">
                            <label class="form-label">{{ db_trans('secondary_button_link') }}</label>
                            <input type="text" name="cta_secondary_link" value="{{ old('cta_secondary_link', $heroSettings['cta_secondary_link'] ?? '') }}" class="form-control">
                        </div>
                    </div>
                </div>
            </div>

            <div class="card cms-form-card">
                <div class="card-body">
                    <div class="cms-section-title">{{ db_trans('homepage_visibility') }}</div>

                    <div class="row g-3">
                        @foreach($homepageToggles as $key => $value)
                            <div class="col-lg-4">
                                <label class="form-label">{{ str_replace('homepage.show_', '', $key) }}</label>
                                <select name="{{ $key }}" class="form-select">
                                    <option value="1" @selected((string) old($key, $value ? '1' : '0') === '1')>{{ db_trans('enabled') }}</option>
                                    <option value="0" @selected((string) old($key, $value ? '1' : '0') === '0')>{{ db_trans('disabled') }}</option>
                                </select>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="card cms-form-card">
                <div class="card-body">
                    <div class="cms-section-title">{{ db_trans('homepage_sections') }}</div>

                    <div class="cms-repeater-list">
                        @foreach($sections as $index => $section)
                            <div class="cms-repeater-item">
                                <input type="hidden" name="sections[{{ $index }}][section_key]" value="{{ $section->section_key }}">

                                <div class="row g-3">
                                    <div class="col-lg-3">
                                        <label class="form-label">{{ db_trans('section_key') }}</label>
                                        <input type="text" class="form-control" value="{{ $section->section_key }}" disabled>
                                    </div>

                                    <div class="col-lg-3">
                                        <label class="form-label">{{ db_trans('title') }}</label>
                                        <input type="text" name="sections[{{ $index }}][title]" value="{{ old("sections.$index.title", $section->title) }}" class="form-control">
                                    </div>

                                    <div class="col-lg-3">
                                        <label class="form-label">{{ db_trans('subtitle') }}</label>
                                        <input type="text" name="sections[{{ $index }}][subtitle]" value="{{ old("sections.$index.subtitle", $section->subtitle) }}" class="form-control">
                                    </div>

                                    <div class="col-lg-3">
                                        <label class="form-label">{{ db_trans('display_order') }}</label>
                                        <input type="number" name="sections[{{ $index }}][display_order]" value="{{ old("sections.$index.display_order", $section->display_order) }}" class="form-control">
                                    </div>

                                    <div class="col-lg-4">
                                        <label class="form-label">{{ db_trans('data_source') }}</label>
                                        <input type="text" name="sections[{{ $index }}][data_source]" value="{{ old("sections.$index.data_source", $section->data_source) }}" class="form-control">
                                    </div>

                                    <div class="col-lg-4">
                                        <label class="form-label">{{ db_trans('layout') }}</label>
                                        <input type="text" name="sections[{{ $index }}][layout]" value="{{ old("sections.$index.layout", $section->layout) }}" class="form-control">
                                    </div>

                                    <div class="col-lg-4">
                                        <label class="form-label">{{ db_trans('status') }}</label>
                                        <select name="sections[{{ $index }}][is_enabled]" class="form-select">
                                            <option value="1" @selected((string) old("sections.$index.is_enabled", $section->is_enabled ? '1' : '0') === '1')>{{ db_trans('enabled') }}</option>
                                            <option value="0" @selected((string) old("sections.$index.is_enabled", $section->is_enabled ? '1' : '0') === '0')>{{ db_trans('disabled') }}</option>
                                        </select>
                                    </div>

                                    <div class="col-12">
                                        <label class="form-label">{{ db_trans('content') }}</label>
                                        <textarea name="sections[{{ $index }}][content]" rows="3" class="form-control">{{ old("sections.$index.content", $section->content) }}</textarea>
                                    </div>

                                    <div class="col-12">
                                        <label class="form-label">{{ db_trans('settings_json') }}</label>
                                        <textarea name="sections[{{ $index }}][settings_json]" rows="2" class="form-control">{{ old("sections.$index.settings_json", $section->settings_json) }}</textarea>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>

            <div class="cms-sticky-actions d-flex justify-content-end gap-2">
                <a href="{{ route('cms.dashboard') }}" class="btn btn-outline-secondary px-4">{{ db_trans('cancel') }}</a>
                <button type="submit" class="btn btn-primary px-4">
                    <i class="fas fa-save me-2"></i>{{ db_trans('save_changes') }}
                </button>
            </div>
        </form>
    </div>
@endsection

@push('scripts')
    <script src="{{ asset('admin/js/cms.js') }}"></script>
@endpush