@extends('layouts.admin')

@section('title', db_trans('create_history'))

@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/cms.css') }}">
@endpush

@section('content')
    @include('admin.cms.histories.partials.form', [
        'pageTitle' => db_trans('create_history'),
        'pageSubtitle' => db_trans('manage_history_entries_and_story_content'),
        'action' => route('cms.histories.store'),
        'method' => 'POST',
        'history' => null,
    ])
@endsection

@push('scripts')
    <script src="{{ asset('admin/js/cms.js') }}"></script>
@endpush