@extends('layouts.admin')

@section('title', db_trans('content_management_center'))

@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/cms.css') }}">
@endpush

@section('content')
    <div class="cms-shell">
        <div class="cms-hero cms-hero-dashboard">
            <div class="d-flex flex-column flex-xl-row justify-content-between gap-4 align-items-xl-center">
                <div>
                    <span class="cms-hero-badge">
                        <i class="fas fa-layer-group"></i>
                        {{ db_trans('cms') }}
                    </span>

                    <h2 class="cms-hero-title">{{ $page['title'] }}</h2>
                    <p class="cms-hero-subtitle">{{ $page['subtitle'] }}</p>

                    <div class="d-flex flex-wrap gap-2 mt-3">
                        <span class="cms-hero-pill">
                            <i class="fas fa-clock"></i>
                            {{ db_trans('last_updated') }}:
                            {{ optional($page['updated_at'])->format('d M Y, h:i A') }}
                        </span>
                    </div>
                </div>

                <div class="cms-quick-links">
                    @can('cms.homepage.view')
                        <a href="{{ route('cms.homepage.edit') }}" class="btn btn-light">
                            <i class="fas fa-home me-2"></i>{{ db_trans('homepage_builder') }}
                        </a>
                    @endcan
                    @can('cms.heroes.view')
                        <a href="{{ route('cms.heroes.index') }}" class="btn btn-outline-light">
                            <i class="fas fa-images me-2"></i>{{ db_trans('hero_banners') }}
                        </a>
                    @endcan
                </div>
            </div>
        </div>

        <div class="row g-4">
            @foreach($kpis as $card)
                <div class="col-xxl-2 col-xl-4 col-md-6">
                    <div class="card cms-kpi-card">
                        <div class="card-body">
                            <div class="cms-kpi-top">
                                <span class="cms-kpi-icon tone-{{ $card['tone'] }}">
                                    <i class="{{ $card['icon'] }}"></i>
                                </span>
                            </div>
                            <div class="cms-kpi-title">{{ $card['title'] }}</div>
                            <div class="cms-kpi-value">{{ $card['value'] }}</div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="row g-4">
            <div class="col-xl-6">
                <div class="card cms-panel">
                    <div class="card-body">
                        <div class="cms-panel-head">
                            <div>
                                <h4 class="cms-panel-title">{{ db_trans('homepage_sections') }}</h4>
                                <p class="cms-panel-subtitle">{{ db_trans('homepage_sections_and_visibility_summary') }}</p>
                            </div>
                        </div>

                        <div class="cms-list">
                            @foreach($home_sections as $section)
                                <div class="cms-list-item">
                                    <div>
                                        <div class="cms-list-title">{{ $section->title ?: ucfirst($section->section_key) }}</div>
                                        <div class="cms-list-sub">{{ $section->section_key }}</div>
                                    </div>
                                    <span class="badge {{ $section->is_enabled ? 'bg-success' : 'bg-secondary' }}">
                                        {{ $section->is_enabled ? db_trans('enabled') : db_trans('disabled') }}
                                    </span>
                                </div>
                            @endforeach
                        </div>

                        @can('cms.homepage.view')
                            <div class="mt-3">
                                <a href="{{ route('cms.homepage.edit') }}" class="btn btn-outline-primary w-100">
                                    <i class="fas fa-pen-to-square me-2"></i>{{ db_trans('manage_homepage') }}
                                </a>
                            </div>
                        @endcan
                    </div>
                </div>
            </div>

            <div class="col-xl-6">
                <div class="card cms-panel">
                    <div class="card-body">
                        <div class="cms-panel-head">
                            <div>
                                <h4 class="cms-panel-title">{{ db_trans('published_content_summary') }}</h4>
                                <p class="cms-panel-subtitle">{{ db_trans('current_live_content_status') }}</p>
                            </div>
                        </div>

                        <div class="cms-list">
                            <div class="cms-list-item"><span>{{ db_trans('hero_banners') }}</span><strong>{{ $published['hero_banners'] }}</strong></div>
                            <div class="cms-list-item"><span>{{ db_trans('histories') }}</span><strong>{{ $published['histories'] }}</strong></div>
                            <div class="cms-list-item"><span>{{ db_trans('announcements') }}</span><strong>{{ $published['announcements'] }}</strong></div>
                            <div class="cms-list-item"><span>{{ db_trans('pages') }}</span><strong>{{ $published['pages'] }}</strong></div>
                            <div class="cms-list-item"><span>{{ db_trans('galleries') }}</span><strong>{{ $published['galleries'] }}</strong></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            @php
                $recentGroups = [
                    ['title' => db_trans('recent_hero_banners'), 'items' => $recent['hero_banners'], 'route' => 'cms.heroes.index'],
                    ['title' => db_trans('recent_histories'), 'items' => $recent['histories'], 'route' => 'cms.histories.index'],
                    ['title' => db_trans('recent_announcements'), 'items' => $recent['announcements'], 'route' => 'cms.announcements.index'],
                    ['title' => db_trans('recent_pages'), 'items' => $recent['pages'], 'route' => 'cms.pages.index'],
                    ['title' => db_trans('recent_galleries'), 'items' => $recent['galleries'], 'route' => 'cms.galleries.index'],
                ];
            @endphp

            @foreach($recentGroups as $group)
                <div class="col-xl-4">
                    <div class="card cms-panel">
                        <div class="card-body">
                            <div class="cms-panel-head">
                                <div>
                                    <h4 class="cms-panel-title">{{ $group['title'] }}</h4>
                                    <p class="cms-panel-subtitle">{{ db_trans('latest_content_entries') }}</p>
                                </div>
                            </div>

                            <div class="cms-list">
                                @forelse($group['items'] as $item)
                                    <div class="cms-list-item">
                                        <div>
                                            <div class="cms-list-title">{{ $item->title }}</div>
                                            <div class="cms-list-sub">{{ optional($item->created_at)->format('d M Y') }}</div>
                                        </div>
                                    </div>
                                @empty
                                    <div class="text-muted">{{ db_trans('no_records_found') }}</div>
                                @endforelse
                            </div>

                            <div class="mt-3">
                                <a href="{{ route($group['route']) }}" class="btn btn-outline-secondary w-100">
                                    {{ db_trans('view_all') }}
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>
    </div>
@endsection

@push('scripts')
    <script src="{{ asset('admin/js/cms.js') }}"></script>
@endpush