@extends('layouts.admin')

@section('title', db_trans('create_hero_banner'))

@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/cms.css') }}">
@endpush

@section('content')
    @include('admin.cms.heroes.partials.form', [
        'pageTitle' => db_trans('create_hero_banner'),
        'pageSubtitle' => db_trans('manage_hero_banners_and_calls_to_action'),
        'action' => route('cms.heroes.store'),
        'method' => 'POST',
        'heroBanner' => null,
    ])
@endsection

@push('scripts')
    <script src="{{ asset('admin/js/cms.js') }}"></script>
@endpush