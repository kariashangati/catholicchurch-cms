<div class="modal fade finance-modal" id="{{ $modalId }}" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-centered modal-dialog-scrollable">
        <div class="modal-content ui-modal-card border-0">
            <form method="POST" action="{{ $action }}">
                @csrf
                @if($method !== 'POST') @method($method) @endif

                <div class="modal-header">
                    <div>
                        <h5 class="modal-title mb-1">{{ $title }}</h5>
                        <div class="text-muted small">Capture member, type, amount, date and approval status safely.</div>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>

                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label class="form-label">{{ db_trans('member') }}</label>
                            <select name="member_id" class="form-select" required>
                                <option value="">{{ db_trans('select_member') }}</option>
                                @foreach($members as $member)
                                    <option value="{{ $member->id }}" @selected(old('member_id', $item->member_id ?? '') == $member->id)>
                                        {{ $member->name ?? $member->full_name ?? ('#'.$member->id) }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label class="form-label">{{ db_trans('contribution_type') }}</label>
                            <select name="contribution_type_id" class="form-select" required>
                                <option value="">{{ db_trans('select_option') }}</option>
                                @foreach($types as $type)
                                    <option value="{{ $type->id }}" @selected(old('contribution_type_id', $item->contribution_type_id ?? '') == $type->id)>{{ $type->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">{{ db_trans('amount') }}</label>
                            <input type="number" step="0.01" min="0.01" name="amount" class="form-control" value="{{ old('amount', $item->amount ?? '') }}" required>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">{{ db_trans('contribution_date') }}</label>
                            <input type="date" name="contribution_date" class="form-control" value="{{ old('contribution_date', isset($item) && $item->contribution_date ? $item->contribution_date->format('Y-m-d') : now()->format('Y-m-d')) }}" required>
                        </div>

                        <div class="col-md-4">
                            <label class="form-label">{{ db_trans('status') }}</label>
                            <select name="status" class="form-select">
                                @foreach(['pending','approved','rejected'] as $status)
                                    <option value="{{ $status }}" @selected(old('status', $item->status ?? 'approved') === $status)>{{ ucfirst($status) }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-12">
                            <label class="form-label">{{ db_trans('notes') }}</label>
                            <textarea name="notes" class="form-control" rows="3">{{ old('notes', $item->notes ?? '') }}</textarea>
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-light" data-bs-dismiss="modal">{{ db_trans('cancel') }}</button>
                    <button type="submit" class="btn btn-primary">{{ db_trans('save_changes') }}</button>
                </div>
            </form>
        </div>
    </div>
</div>
