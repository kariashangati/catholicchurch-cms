@extends('layouts.admin')

@section('title', db_trans('audit_access_center'))

@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/auditdashboard.css') }}">
@endpush

@section('content')
    <div class="audit-shell">
        <div class="audit-hero">
            <div class="row g-4 align-items-center">
                <div class="col-xl-8">
                    <span class="audit-hero-badge">
                        <i class="fas fa-shield-alt"></i>
                        {{ db_trans('system') }}
                    </span>

                    <h2 class="audit-hero-title">{{ $page['title'] }}</h2>

                    <p class="audit-hero-subtitle">
                        {{ $page['subtitle'] }}
                    </p>

                    <div class="audit-hero-meta">
                        <span class="audit-hero-pill">
                            <i class="fas fa-clock"></i>
                            {{ db_trans('last_updated') }}:
                            {{ optional($page['updated_at'])->format('d M Y, h:i A') }}
                        </span>

                        <span class="audit-hero-pill">
                            <i class="fas fa-user-shield"></i>
                            {{ db_trans('logged_in_as') }}: {{ auth()->user()->name }}
                        </span>
                    </div>
                </div>

                <div class="col-xl-4">
                    <div class="audit-panel bg-transparent border-0 shadow-none">
                        <div class="card-body p-0">
                            <div class="audit-highlight-grid">
                                @foreach($riskHighlights as $item)
                                    <div class="audit-highlight-card">
                                        <div class="audit-highlight-label">{{ $item['label'] }}</div>
                                        <div class="audit-highlight-value">{{ $item['value'] }}</div>
                                        <div class="audit-highlight-meta">{{ $item['meta'] }}</div>
                                    </div>
                                @endforeach
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            @foreach($kpis as $card)
                <div class="col-xxl-2 col-xl-4 col-md-6">
                    <div class="audit-kpi-card card">
                        <div class="card-body">
                            <div class="audit-kpi-top">
                                <span class="audit-kpi-icon tone-{{ $card['tone'] }}">
                                    <i class="{{ $card['icon'] }}"></i>
                                </span>
                                <span class="audit-kpi-chip">{{ db_trans('overview') }}</span>
                            </div>

                            <div class="audit-kpi-title">{{ $card['title'] }}</div>
                            <div class="audit-kpi-value">{{ number_format((int) $card['value']) }}</div>
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="row g-4">
            <div class="col-xl-8">
                <div class="audit-panel card">
                    <div class="card-body">
                        <div class="audit-panel-head">
                            <div>
                                <h4 class="audit-panel-title">{{ db_trans('activity_trend') }}</h4>
                                <p class="audit-panel-subtitle">{{ db_trans('recent_activity_volume_across_days') }}</p>
                            </div>
                            <span class="audit-panel-badge">{{ db_trans('activities_today') }}</span>
                        </div>

                        <div class="audit-chart-shell">
                            <canvas id="auditActivityTrendChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-4">
                <div class="audit-panel card">
                    <div class="card-body">
                        <div class="audit-panel-head">
                            <div>
                                <h4 class="audit-panel-title">{{ db_trans('login_risk_breakdown') }}</h4>
                                <p class="audit-panel-subtitle">{{ db_trans('risk_distribution_for_recent_logins') }}</p>
                            </div>
                            <span class="audit-panel-badge">{{ db_trans('logins_24h') }}</span>
                        </div>

                        <div class="audit-chart-shell audit-chart-shell-sm">
                            <canvas id="auditRiskBreakdownChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-6">
                <div class="audit-panel card">
                    <div class="card-body">
                        <div class="audit-panel-head">
                            <div>
                                <h4 class="audit-panel-title">{{ db_trans('login_trend') }}</h4>
                                <p class="audit-panel-subtitle">{{ db_trans('successful_and_failed_login_activity') }}</p>
                            </div>
                            <span class="audit-panel-badge">{{ db_trans('login_history') }}</span>
                        </div>

                        <div class="audit-chart-shell audit-chart-shell-sm">
                            <canvas id="auditLoginTrendChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-6">
                <div class="audit-panel card">
                    <div class="card-body">
                        <div class="audit-panel-head">
                            <div>
                                <h4 class="audit-panel-title">{{ db_trans('module_breakdown') }}</h4>
                                <p class="audit-panel-subtitle">{{ db_trans('which_modules_generate_the_most_activity') }}</p>
                            </div>
                            <span class="audit-panel-badge">{{ db_trans('activity_logs') }}</span>
                        </div>

                        <div class="audit-chart-shell audit-chart-shell-sm">
                            <canvas id="auditModuleBreakdownChart"></canvas>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-5">
                <div class="audit-panel card">
                    <div class="card-body">
                        <div class="audit-panel-head">
                            <div>
                                <h4 class="audit-panel-title">{{ db_trans('live_security_feed') }}</h4>
                                <p class="audit-panel-subtitle">{{ db_trans('recent_admin_actions_and_security_signals') }}</p>
                            </div>
                            <span class="audit-panel-badge">{{ db_trans('live') }}</span>
                        </div>

                        <div class="audit-feed-list">
                            @forelse($liveFeed as $item)
                                <div class="audit-feed-item">
                                    <span class="audit-feed-icon tone-{{ $item['tone'] }}">
                                        <i class="{{ $item['icon'] }}"></i>
                                    </span>

                                    <div class="flex-grow-1">
                                        <div class="audit-feed-title">{{ $item['title'] }}</div>
                                        <div class="audit-feed-meta">
                                            {{ $item['actor'] }}
                                            @if(!empty($item['meta']))
                                                • {{ $item['meta'] }}
                                            @endif
                                        </div>
                                        <div class="audit-feed-time">{{ $item['time'] }}</div>
                                    </div>
                                </div>
                            @empty
                                <div class="text-muted">{{ db_trans('no_recent_activity_found') }}</div>
                            @endforelse
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-xl-7">
                <div class="row g-4">
                    <div class="col-lg-6">
                        <div class="audit-panel card">
                            <div class="card-body">
                                <div class="audit-panel-head">
                                    <div>
                                        <h4 class="audit-panel-title">{{ db_trans('top_actors') }}</h4>
                                        <p class="audit-panel-subtitle">{{ db_trans('most_active_users_in_recent_days') }}</p>
                                    </div>
                                </div>

                                <div class="d-flex flex-column gap-3">
                                    @forelse($topActors as $actor)
                                        <div class="audit-list-card">
                                            <div class="audit-list-title">{{ $actor['name'] }}</div>
                                            <div class="audit-list-meta">
                                                {{ $actor['email'] ?: db_trans('not_available') }}
                                            </div>
                                            <div class="audit-list-meta mt-1">
                                                {{ number_format((int) $actor['total']) }} {{ db_trans('events') }}
                                            </div>
                                        </div>
                                    @empty
                                        <div class="text-muted">{{ db_trans('no_activity_found') }}</div>
                                    @endforelse
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="audit-panel card">
                            <div class="card-body">
                                <div class="audit-panel-head">
                                    <div>
                                        <h4 class="audit-panel-title">{{ db_trans('event_breakdown') }}</h4>
                                        <p class="audit-panel-subtitle">{{ db_trans('distribution_of_logged_actions') }}</p>
                                    </div>
                                </div>

                                <div class="audit-chart-shell audit-chart-shell-sm">
                                    <canvas id="auditEventBreakdownChart"></canvas>
                                </div>
                            </div>
                        </div>

                        <div class="audit-panel card mt-4">
                            <div class="card-body">
                                <div class="audit-panel-head">
                                    <div>
                                        <h4 class="audit-panel-title">{{ db_trans('browser_usage') }}</h4>
                                        <p class="audit-panel-subtitle">{{ db_trans('most_common_login_clients') }}</p>
                                    </div>
                                </div>

                                <div class="audit-chart-shell audit-chart-shell-sm">
                                    <canvas id="auditBrowserUsageChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="d-flex flex-wrap gap-3">
            @can('audit.logs.view')
                <a href="{{ route('system.activity-logs.index') }}" class="btn btn-primary px-4">
                    <i class="fas fa-stream me-2"></i>{{ db_trans('activity_logs') }}
                </a>
            @endcan

            @can('audit.logins.view')
                <a href="{{ route('system.login-history.index') }}" class="btn btn-outline-dark px-4">
                    <i class="fas fa-sign-in-alt me-2"></i>{{ db_trans('login_history') }}
                </a>
            @endcan
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js@3.9.1/dist/chart.min.js"></script>
    <script>
        window.auditDashboardData = {
            activityTrendChart: @json($activityTrendChart),
            loginTrendChart: @json($loginTrendChart),
            moduleBreakdownChart: @json($moduleBreakdownChart),
            eventBreakdownChart: @json($eventBreakdownChart),
            riskBreakdownChart: @json($riskBreakdownChart),
            browserUsageChart: @json($browserUsageChart),
            labels: {
                success: @json(db_trans('success')),
                failed: @json(db_trans('failed')),
            }
        };

        document.addEventListener('DOMContentLoaded', function () {
            if (typeof Chart === 'undefined') {
                return;
            }

            const data = window.auditDashboardData || {};

            const makeLineChart = (id, labels, datasets) => {
                const canvas = document.getElementById(id);
                if (!canvas) return;

                new Chart(canvas, {
                    type: 'line',
                    data: { labels, datasets },
                    options: {
                        maintainAspectRatio: false,
                        responsive: true,
                        interaction: { mode: 'index', intersect: false },
                        plugins: {
                            legend: { display: true, position: 'bottom' }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: { precision: 0 }
                            }
                        }
                    }
                });
            };

            const makeBarChart = (id, labels, values, horizontal = false) => {
                const canvas = document.getElementById(id);
                if (!canvas) return;

                new Chart(canvas, {
                    type: 'bar',
                    data: {
                        labels,
                        datasets: [{
                            label: '',
                            data: values,
                            borderRadius: 10,
                            borderWidth: 0,
                        }]
                    },
                    options: {
                        indexAxis: horizontal ? 'y' : 'x',
                        maintainAspectRatio: false,
                        responsive: true,
                        plugins: {
                            legend: { display: false }
                        },
                        scales: {
                            y: {
                                beginAtZero: true,
                                ticks: { precision: 0 }
                            },
                            x: {
                                ticks: { precision: 0 }
                            }
                        }
                    }
                });
            };

            const makeDoughnutChart = (id, labels, values) => {
                const canvas = document.getElementById(id);
                if (!canvas) return;

                new Chart(canvas, {
                    type: 'doughnut',
                    data: {
                        labels,
                        datasets: [{
                            data: values,
                            borderWidth: 0,
                        }]
                    },
                    options: {
                        maintainAspectRatio: false,
                        responsive: true,
                        plugins: {
                            legend: {
                                display: true,
                                position: 'bottom'
                            }
                        }
                    }
                });
            };

            makeLineChart(
                'auditActivityTrendChart',
                data.activityTrendChart?.labels || [],
                [{
                    label: @json(db_trans('activities_today')),
                    data: data.activityTrendChart?.values || [],
                    tension: .35,
                    fill: false,
                }]
            );

            makeLineChart(
                'auditLoginTrendChart',
                data.loginTrendChart?.labels || [],
                [
                    {
                        label: data.labels?.success || 'Success',
                        data: data.loginTrendChart?.success || [],
                        tension: .35,
                        fill: false,
                    },
                    {
                        label: data.labels?.failed || 'Failed',
                        data: data.loginTrendChart?.failed || [],
                        tension: .35,
                        fill: false,
                    }
                ]
            );

            makeBarChart(
                'auditModuleBreakdownChart',
                data.moduleBreakdownChart?.labels || [],
                data.moduleBreakdownChart?.values || [],
                true
            );

            makeBarChart(
                'auditEventBreakdownChart',
                data.eventBreakdownChart?.labels || [],
                data.eventBreakdownChart?.values || []
            );

            makeDoughnutChart(
                'auditRiskBreakdownChart',
                data.riskBreakdownChart?.labels || [],
                data.riskBreakdownChart?.values || []
            );

            makeDoughnutChart(
                'auditBrowserUsageChart',
                data.browserUsageChart?.labels || [],
                data.browserUsageChart?.values || []
            );
        });
    </script>
@endpush