@extends('layouts.admin')

@section('title', db_trans('activity_logs'))

@push('styles')
    <link rel="stylesheet" href="{{ asset('admin/css/activity.css') }}">
@endpush

@section('content')
    <div class="audit-page-shell">
        <div class="audit-page-hero">
            <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-3">
                <div>
                    <h2 class="audit-page-hero-title">{{ db_trans('activity_logs') }}</h2>
                    <p class="audit-page-hero-subtitle">
                        {{ db_trans('detailed_action_trail_showing_who_did_what_and_on_which_record') }}
                    </p>
                </div>

                <div class="d-flex flex-wrap gap-2">
                    <a href="{{ route('system.audit.index') }}" class="btn btn-light">
                        <i class="fas fa-chart-line me-2"></i>{{ db_trans('audit_access_center') }}
                    </a>
                    <a href="{{ route('system.login-history.index') }}" class="btn btn-outline-light">
                        <i class="fas fa-sign-in-alt me-2"></i>{{ db_trans('login_history') }}
                    </a>
                </div>
            </div>
        </div>

        <div class="card audit-filter-card">
            <div class="card-body">
                <form method="GET" action="{{ route('system.activity-logs.index') }}">
                    <div class="row g-3">
                        <div class="col-xl-3 col-md-6">
                            <label class="audit-filter-label">{{ db_trans('search') }}</label>
                            <input
                                type="text"
                                name="search"
                                value="{{ $filters['search'] ?? '' }}"
                                class="form-control"
                                placeholder="{{ db_trans('description_event_log_name') }}"
                            >
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="audit-filter-label">{{ db_trans('module') }}</label>
                            <select name="module" class="form-select">
                                <option value="">{{ db_trans('all') }}</option>
                                @foreach($modules as $module)
                                    <option value="{{ $module }}" @selected(($filters['module'] ?? '') === $module)>
                                        {{ ucfirst($module) }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="audit-filter-label">{{ db_trans('event') }}</label>
                            <select name="event" class="form-select">
                                <option value="">{{ db_trans('all') }}</option>
                                @foreach($events as $event)
                                    <option value="{{ $event }}" @selected(($filters['event'] ?? '') === $event)>
                                        {{ ucfirst(str_replace('_', ' ', $event)) }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="audit-filter-label">{{ db_trans('risk') }}</label>
                            <select name="risk_level" class="form-select">
                                <option value="">{{ db_trans('all') }}</option>
                                @foreach(['low', 'medium', 'high', 'critical'] as $risk)
                                    <option value="{{ $risk }}" @selected(($filters['risk_level'] ?? '') === $risk)>
                                        {{ ucfirst($risk) }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-xl-3 col-md-6">
                            <label class="audit-filter-label">{{ db_trans('actor') }}</label>
                            <select name="user_id" class="form-select">
                                <option value="">{{ db_trans('all') }}</option>
                                @foreach($users as $user)
                                    <option value="{{ $user->id }}" @selected((string) ($filters['user_id'] ?? '') === (string) $user->id)>
                                        {{ $user->name }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="audit-filter-label">{{ db_trans('from') }}</label>
                            <input type="date" name="from" value="{{ $filters['from'] ?? '' }}" class="form-control">
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="audit-filter-label">{{ db_trans('to') }}</label>
                            <input type="date" name="to" value="{{ $filters['to'] ?? '' }}" class="form-control">
                        </div>

                        <div class="col-xl-2 col-md-6">
                            <label class="audit-filter-label">{{ db_trans('per_page') }}</label>
                            <select name="per_page" class="form-select">
                                @foreach([20, 30, 50, 100] as $size)
                                    <option value="{{ $size }}" @selected((int) ($filters['per_page'] ?? 20) === $size)>
                                        {{ $size }}
                                    </option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-xl-6 d-flex align-items-end gap-2">
                            <button type="submit" class="btn btn-primary px-4">
                                <i class="fas fa-filter me-2"></i>{{ db_trans('apply_filters') }}
                            </button>

                            <a href="{{ route('system.activity-logs.index') }}" class="btn btn-outline-secondary px-4">
                                <i class="fas fa-rotate-left me-2"></i>{{ db_trans('reset') }}
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

        <div class="card audit-table-card">
            <div class="card-body">
                <div class="d-flex flex-column flex-lg-row justify-content-between align-items-lg-center gap-2 mb-3">
                    <div>
                        <h4 class="mb-1">{{ db_trans('activity_logs') }}</h4>
                        <div class="text-muted">
                            {{ db_trans('showing') }} {{ $logs->firstItem() ?? 0 }}
                            {{ db_trans('to') }} {{ $logs->lastItem() ?? 0 }}
                            {{ db_trans('of') }} {{ $logs->total() }}
                            {{ db_trans('activity_records') }}
                        </div>
                    </div>
                </div>

                <div class="table-responsive">
                    <table class="table audit-table align-middle">
                        <thead>
                            <tr>
                                <th>{{ db_trans('time') }}</th>
                                <th>{{ db_trans('actor') }}</th>
                                <th>{{ db_trans('action') }}</th>
                                <th>{{ db_trans('subject') }}</th>
                                <th>{{ db_trans('source') }}</th>
                                <th>{{ db_trans('details') }}</th>
                                <th>{{ db_trans('risk') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @forelse($logs as $log)
                                <tr>
                                    <td style="min-width: 170px;">
                                        <div class="audit-cell-title">
                                            {{ optional($log->occurred_at ?: $log->created_at)->format('d M Y, h:i A') }}
                                        </div>
                                        <div class="audit-cell-meta">
                                            {{ optional($log->created_at)->diffForHumans() }}
                                        </div>
                                    </td>

                                    <td style="min-width: 170px;">
                                        <div class="audit-cell-title">{{ $log->actor_name }}</div>
                                        <div class="audit-cell-meta">
                                            {{ $log->module ? ucfirst($log->module) : db_trans('system') }}
                                        </div>
                                    </td>

                                    <td style="min-width: 180px;">
                                        <span class="audit-event-badge">
                                            {{ ucfirst(str_replace('_', ' ', $log->event)) }}
                                        </span>
                                        @if($log->action)
                                            <div class="audit-cell-meta mt-2">{{ $log->action }}</div>
                                        @endif
                                    </td>

                                    <td style="min-width: 180px;">
                                        <div class="audit-cell-title">{{ $log->display_subject }}</div>
                                        <div class="audit-cell-meta">
                                            {{ class_basename((string) $log->subject_type) ?: db_trans('not_available') }}
                                        </div>
                                    </td>

                                    <td style="min-width: 190px;">
                                        <div class="audit-cell-title">{{ $log->ip_address ?: db_trans('not_available') }}</div>
                                        <div class="audit-cell-meta">
                                            {{ $log->browser ?: db_trans('unknown_browser') }}
                                            @if($log->platform)
                                                • {{ $log->platform }}
                                            @endif
                                        </div>
                                        <div class="audit-cell-meta">
                                            {{ $log->method ?: db_trans('not_available') }}
                                            @if($log->route_name)
                                                • {{ $log->route_name }}
                                            @endif
                                        </div>
                                    </td>

                                    <td style="min-width: 260px;">
                                        <div class="audit-cell-title">
                                            {{ $log->description ?: ucfirst(str_replace('_', ' ', $log->event)) }}
                                        </div>

                                        @if(!empty($log->properties))
                                            <div class="audit-cell-meta mt-1">
                                                {{ collect($log->properties)->take(3)->map(function ($value, $key) {
                                                    if (is_array($value)) {
                                                        return $key . ': ' . json_encode($value);
                                                    }

                                                    return $key . ': ' . $value;
                                                })->implode(' • ') }}
                                            </div>
                                        @endif
                                    </td>

                                    <td>
                                        <span class="audit-risk-badge risk-{{ $log->risk_level }}">
                                            {{ ucfirst($log->risk_level) }}
                                        </span>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="7">
                                        <div class="audit-empty">
                                            {{ db_trans('no_activity_records_found') }}
                                        </div>
                                    </td>
                                </tr>
                            @endforelse
                        </tbody>
                    </table>
                </div>

                @if($logs->hasPages())
                    <div class="mt-4">
                        {{ $logs->links() }}
                    </div>
                @endif
            </div>
        </div>
    </div>
@endsection