<?php

namespace App\Http\Controllers\Admin\SystemConfig;

use App\Http\Controllers\Controller;
use App\Http\Requests\SystemConfig\UpdateMaintenanceSettingsRequest;
use App\Services\Audit\AuditLogService;
use App\Services\SystemConfig\MaintenanceModeService;
use App\Services\SystemConfig\SiteSettingsService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class MaintenanceSettingController extends Controller
{
    public function __construct(
        protected MaintenanceModeService $maintenanceModeService,
        protected SiteSettingsService $siteSettingsService,
        protected AuditLogService $auditLogService
    ) {
    }

    public function edit(Request $request): View
    {
        abort_unless($request->user()?->can('system.config.maintenance.view'), 403);

        return view('admin.system-config.maintenance', [
            'global' => $this->maintenanceModeService->globalSettings(),
            'routes' => $this->siteSettingsService->maintenanceRoutes(),
            'suggestedRoutes' => [
                'home',
                'projects.index',
                'contact.index',
                'dashboard',
                'admin.communication.dashboard',
                'receipts.dashboard',
                'system-access.dashboard',
            ],
        ]);
    }

    public function update(UpdateMaintenanceSettingsRequest $request): RedirectResponse
    {
        $data = $request->validated();

        $oldValues = [
            'global' => $this->maintenanceModeService->globalSettings(),
            'routes' => $this->siteSettingsService->maintenanceRoutes(),
        ];

        $useLaravelDown = (bool) ($data['use_laravel_down'] ?? false);

        if ((bool) $data['global_enabled']) {
            $this->maintenanceModeService->enableGlobal(
                $data['global_title'] ?? 'Maintenance Mode',
                $data['global_message'] ?? 'The system is under maintenance.',
                $useLaravelDown
            );
        } else {
            $this->maintenanceModeService->disableGlobal($useLaravelDown);
            $this->siteSettingsService->set('maintenance.global.title', $data['global_title'] ?? 'Maintenance Mode', 'string', 'maintenance');
            $this->siteSettingsService->set('maintenance.global.message', $data['global_message'] ?? 'The system is under maintenance.', 'string', 'maintenance');
        }

        foreach ($data['routes'] ?? [] as $route) {
            $this->maintenanceModeService->setRouteMaintenance(
                $route['name'],
                (bool) ($route['enabled'] ?? false),
                $route['title'] ?? 'Maintenance Mode',
                $route['message'] ?? 'This page is under maintenance.'
            );
        }

        $this->auditLogService->log([
            'user' => $request->user(),
            'event' => 'updated',
            'module' => 'system_config',
            'action' => 'Maintenance settings updated',
            'subject_type' => 'system_config',
            'subject_id' => null,
            'subject_label' => 'Maintenance Settings',
            'description' => 'System maintenance settings updated',
            'old_values' => $oldValues,
            'new_values' => [
                'global' => $this->maintenanceModeService->globalSettings(),
                'routes' => $this->siteSettingsService->maintenanceRoutes(),
            ],
            'risk_level' => 'high',
        ]);

        return back()->with('success', db_trans('maintenance_settings_updated_successfully'));
    }
}