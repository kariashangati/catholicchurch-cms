<?php

namespace App\Http\Controllers\Admin\Operations;

use App\Http\Controllers\Controller;
use App\Http\Requests\StoreChurchAssetRequest;
use App\Http\Requests\UpdateChurchAssetRequest;
use App\Models\AssetCategory;
use App\Models\ChurchAsset;
use App\Services\Operations\ChurchAssetService;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;

class ChurchAssetController extends Controller
{
    public function __construct(private readonly ChurchAssetService $service)
    {
    }

    public function index(): View
    {
        return view('admin.operations.church-assets.index', [
            'assets' => ChurchAsset::query()->with('category')->latest()->get(),
            'categories' => AssetCategory::query()->where('is_active', true)->orderBy('name')->get(),
            'conditionStatuses' => ChurchAsset::conditionStatuses(),
        ]);
    }

    public function store(StoreChurchAssetRequest $request): RedirectResponse
    {
        $this->service->create($request->validated());

        return back()->with('success', db_trans('church_asset_created'));
    }

    public function update(UpdateChurchAssetRequest $request, ChurchAsset $church_asset): RedirectResponse
    {
        $this->service->update($church_asset, $request->validated());

        return back()->with('success', db_trans('church_asset_updated'));
    }

    public function destroy(ChurchAsset $church_asset): RedirectResponse
    {
        $church_asset->delete();

        return back()->with('success', db_trans('church_asset_deleted'));
    }
}
