<?php

namespace App\Http\Requests\Finance\Budgets;

use App\Models\BudgetIncomeEstimate;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreBudgetIncomeEstimateRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('finance.budgets.income.create') ?? false;
    }

    public function rules(): array
    {
        return [
            'source_type' => ['required', Rule::in(BudgetIncomeEstimate::sourceOptions())],
            'category_name' => ['required', 'string', 'max:150'],
            'category_group' => ['required', Rule::in(BudgetIncomeEstimate::groupOptions())],
            'amount' => ['required', 'numeric', 'min:0'],
            'budget_year' => ['required', 'integer', 'min:2020', 'max:2100'],
            'notes' => ['nullable', 'string', 'max:1000'],
        ];
    }
}
