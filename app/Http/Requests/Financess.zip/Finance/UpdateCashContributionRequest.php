<?php

namespace App\Http\Requests\Finance;

class UpdateCashContributionRequest extends StoreCashContributionRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('finance.contributions.cash.update') ?? false;
    }
}
