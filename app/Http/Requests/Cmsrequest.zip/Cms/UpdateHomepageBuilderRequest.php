<?php

namespace App\Http\Requests\Cms;

use Illuminate\Foundation\Http\FormRequest;

class UpdateHomepageBuilderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('cms.homepage.update') ?? false;
    }

    public function rules(): array
    {
        return [
            'hero_badge' => ['nullable', 'string', 'max:255'],
            'enable_video' => ['nullable', 'boolean'],
            'video_url' => ['nullable', 'string', 'max:255'],
            'poster_url' => ['nullable', 'string', 'max:255'],
            'image_url' => ['nullable', 'string', 'max:255'],
            'mobile_image_url' => ['nullable', 'string', 'max:255'],
            'overlay_opacity' => ['nullable', 'numeric', 'min:0', 'max:1'],
            'cta_primary_text' => ['nullable', 'string', 'max:255'],
            'cta_primary_link' => ['nullable', 'string', 'max:255'],
            'cta_secondary_text' => ['nullable', 'string', 'max:255'],
            'cta_secondary_link' => ['nullable', 'string', 'max:255'],

            'homepage.show_announcements' => ['nullable', 'boolean'],
            'homepage.show_masses' => ['nullable', 'boolean'],
            'homepage.show_projects' => ['nullable', 'boolean'],
            'homepage.show_ministries' => ['nullable', 'boolean'],
            'homepage.show_gallery' => ['nullable', 'boolean'],
            'homepage.show_leadership' => ['nullable', 'boolean'],
            'homepage.show_contact' => ['nullable', 'boolean'],

            'sections' => ['nullable', 'array'],
            'sections.*.section_key' => ['required_with:sections', 'string', 'max:255'],
            'sections.*.title' => ['nullable', 'string', 'max:255'],
            'sections.*.subtitle' => ['nullable', 'string', 'max:255'],
            'sections.*.content' => ['nullable', 'string'],
            'sections.*.data_source' => ['nullable', 'string', 'max:255'],
            'sections.*.layout' => ['nullable', 'string', 'max:255'],
            'sections.*.is_enabled' => ['nullable', 'boolean'],
            'sections.*.display_order' => ['nullable', 'integer', 'min:0'],
            'sections.*.settings_json' => ['nullable', 'string'],
        ];
    }
}