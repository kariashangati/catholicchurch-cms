<?php

namespace App\Http\Requests\Receipts;

use Illuminate\Foundation\Http\FormRequest;

class SendReceiptSmsRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->can('finance.receipts.send') ?? false;
    }

    public function rules(): array
    {
        return [
            'phone' => ['nullable', 'string', 'max:30'],
            'message' => ['nullable', 'string', 'max:1000'],
            'expires_in_days' => ['nullable', 'integer', 'min:1', 'max:30'],
            'force_regenerate_token' => ['nullable', 'boolean'],
        ];
    }

    /**
     * Preserve old default behavior (VERY IMPORTANT)
     */
    protected function prepareForValidation(): void
    {
        $this->merge([
            'expires_in_days' => $this->input('expires_in_days', 7),
            'force_regenerate_token' => $this->boolean('force_regenerate_token'),
        ]);
    }

    /**
     * NEW FEATURE: better UI/validation labels
     */
    public function attributes(): array
    {
        return [
            'phone' => db_trans('receipts.fields.phone'),
            'message' => db_trans('receipts.fields.message'),
            'expires_in_days' => db_trans('receipts.fields.expires_in_days'),
            'force_regenerate_token' => db_trans('receipts.fields.force_regenerate_token'),
        ];
    }
}