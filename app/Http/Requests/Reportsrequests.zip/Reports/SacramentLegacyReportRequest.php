<?php

namespace App\Http\Requests\Reports;

use Illuminate\Foundation\Http\FormRequest;

class SacramentLegacyReportRequest extends FormRequest
{
    public function authorize(): bool
    {
        return auth()->check();
    }

    public function rules(): array
    {
        return [
            'scope_level' => ['required', 'in:parish,kanda,jumuiya,familia'],
            'scope_id' => ['nullable', 'integer'],
            'member_filter' => ['nullable', 'in:all,baptized,not_baptized,married,not_married,confirmed,not_confirmed,communion,not_communion,eucharist,not_eucharist,male,female'],
            'date_mode' => ['nullable', 'in:all_time,custom_range'],
            'start_date' => ['nullable', 'date'],
            'end_date' => ['nullable', 'date', 'after_or_equal:start_date'],
            'view_mode' => ['nullable', 'in:summary,detailed'],
        ];
    }
}
