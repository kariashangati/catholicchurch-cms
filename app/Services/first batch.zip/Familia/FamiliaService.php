<?php

namespace App\Services\Familia;

use App\Models\ApostolicGroupMember;
use App\Models\CashContribution;
use App\Models\ContributionType;
use App\Models\Familia;
use App\Models\Jumuiya;
use App\Models\Member;
use App\Models\Tithe;
use App\Models\User;
use App\Services\Access\ScopeAccessGate;
use App\Services\Access\UserScopeResolver;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Str;

class FamiliaService
{
    public function __construct(
        protected UserScopeResolver $scopeResolver,
        protected ScopeAccessGate $scopeAccessGate,
    ) {
    }

    public function getIndexData(User $user, array $filters = []): array
    {
        $familias = $this->scopedFamiliasQuery($user)
            ->with('jumuiya.kanda')
            ->withCount('members')
            ->latest()
            ->get();

        $availableJumuiyas = $this->availableJumuiyasForUser($user);
        $recentFamilias = $familias->take(5)->values();
        $familiaNames = $familias->take(8)->pluck('name')->values();
        $memberCounts = $familias->take(8)->pluck('members_count')->map(fn ($value) => (int) $value)->values();
        $activeCount = $familias->where('is_active', true)->count();
        $inactiveCount = $familias->where('is_active', false)->count();
        $withPhone = $familias->filter(fn ($familia) => filled($familia->phone))->count();
        $withoutPhone = $familias->count() - $withPhone;
        $withoutAddress = $familias->filter(fn ($familia) => blank($familia->address))->count();
        $withoutEnvelope = $familias->filter(fn ($familia) => blank($familia->envelope_no))->count();

        $jumuiyaDistribution = $familias
            ->groupBy(fn ($familia) => $familia->jumuiya?->name ?: db_trans('unassigned'))
            ->map(fn (Collection $group) => $group->count())
            ->sortDesc()
            ->take(6);

        return [
            'pageTitle' => db_trans('familias'),
            'familias' => $familias,
            'jumuiyas' => $availableJumuiyas,
            'recentFamilias' => $recentFamilias,
            'stats' => [
                'total_familias' => $familias->count(),
                'active_familias' => $activeCount,
                'inactive_familias' => $inactiveCount,
                'total_members' => $familias->sum('members_count'),
                'familias_with_phone' => $withPhone,
                'average_members_per_familia' => $familias->count() > 0
                    ? round($familias->sum('members_count') / $familias->count(), 1)
                    : 0,
                'familias_without_phone' => $withoutPhone,
                'familias_without_address' => $withoutAddress,
                'familias_without_envelope' => $withoutEnvelope,
            ],
            'chartData' => [
                'size_labels' => $familiaNames,
                'size_members' => $memberCounts,
                'status_labels' => [db_trans('active_familias'), db_trans('inactive_familias')],
                'status_data' => [$activeCount, $inactiveCount],
                'phone_labels' => [db_trans('familias_with_phone'), db_trans('familias_without_phone')],
                'phone_data' => [$withPhone, $withoutPhone],
                'jumuiya_labels' => $jumuiyaDistribution->keys()->values(),
                'jumuiya_data' => $jumuiyaDistribution->values(),
            ],
        ];
    }

    public function getShowData(Familia $familia, User $user): array
    {
        $this->scopeAccessGate->authorizeFamilia($user, $familia);

        $familia->load('jumuiya.kanda');

        $members = Member::query()
            ->with('familia.jumuiya.kanda')
            ->where('familia_id', $familia->id)
            ->latest()
            ->get();

        $normalize = fn ($value) => Str::lower(trim((string) $value));
        $maleCount = $members->filter(fn ($member) => $normalize($member->gender) === 'male')->count();
        $femaleCount = $members->filter(fn ($member) => $normalize($member->gender) === 'female')->count();
        $fathersCount = $members->filter(fn ($member) => $normalize($member->family_role) === 'father')->count();
        $mothersCount = $members->filter(fn ($member) => $normalize($member->family_role) === 'mother')->count();
        $childrenCount = $members->filter(fn ($member) => $normalize($member->family_role) === 'child')->count();

        $currentYear = now()->year;
        $previousYear = now()->copy()->subYear()->year;
        $memberIds = $members->pluck('id');
        $mavunoTypeId = ContributionType::query()->where('slug', 'mavuno')->value('id');

        $totalsCurrent = [
            'zaka' => Tithe::query()->whereIn('member_id', $memberIds)->whereYear('contribution_date', $currentYear)->sum('amount'),
            'mavuno' => $mavunoTypeId
                ? CashContribution::query()->whereIn('member_id', $memberIds)->where('contribution_type_id', $mavunoTypeId)->whereYear('contribution_date', $currentYear)->sum('amount')
                : 0,
            'other' => CashContribution::query()->whereIn('member_id', $memberIds)
                ->when($mavunoTypeId, fn ($query) => $query->where('contribution_type_id', '!=', $mavunoTypeId))
                ->whereYear('contribution_date', $currentYear)
                ->sum('amount'),
        ];

        $totalsPrevious = [
            'zaka' => Tithe::query()->whereIn('member_id', $memberIds)->whereYear('contribution_date', $previousYear)->sum('amount'),
            'mavuno' => $mavunoTypeId
                ? CashContribution::query()->whereIn('member_id', $memberIds)->where('contribution_type_id', $mavunoTypeId)->whereYear('contribution_date', $previousYear)->sum('amount')
                : 0,
            'other' => CashContribution::query()->whereIn('member_id', $memberIds)
                ->when($mavunoTypeId, fn ($query) => $query->where('contribution_type_id', '!=', $mavunoTypeId))
                ->whereYear('contribution_date', $previousYear)
                ->sum('amount'),
        ];

        $profileCompletedChecks = [
            filled($familia->phone),
            filled($familia->address),
            filled($familia->envelope_no),
            (bool) $familia->jumuiya_id,
            $members->count() > 0,
        ];

        $profileReadiness = (int) round(
            (collect($profileCompletedChecks)->filter()->count() / max(count($profileCompletedChecks), 1)) * 100
        );

        return [
            'pageTitle' => db_trans('family_details'),
            'familia' => $familia,
            'members' => $members,
            'jumuiyas' => $this->availableJumuiyasForUser($user),
            'availableFamiliaRoles' => ['Father', 'Mother', 'Child', 'Other'],
            'stats' => [
                'members_count' => $members->count(),
                'male_members_count' => $maleCount,
                'female_members_count' => $femaleCount,
                'fathers_count' => $fathersCount,
                'mothers_count' => $mothersCount,
                'children_count' => $childrenCount,
                'active_members_count' => $members->where('is_active', true)->count(),
                'baptized_count' => $members->where('is_baptized', true)->count(),
                'communion_count' => $members->where('has_communion', true)->count(),
                'confirmation_count' => $members->where('has_confirmation', true)->count(),
                'married_count' => $members->where('is_married', true)->count(),
                'profile_readiness' => $profileReadiness,
            ],
            'chartData' => [
                'genderLabels' => [db_trans('male_members'), db_trans('female_members')],
                'genderData' => [$maleCount, $femaleCount],
                'roleLabels' => [db_trans('father'), db_trans('mother'), db_trans('child')],
                'roleData' => [$fathersCount, $mothersCount, $childrenCount],
                'sacramentLabels' => [db_trans('baptized'), db_trans('communion'), db_trans('confirmation'), db_trans('married')],
                'sacramentData' => [
                    $members->where('is_baptized', true)->count(),
                    $members->where('has_communion', true)->count(),
                    $members->where('has_confirmation', true)->count(),
                    $members->where('is_married', true)->count(),
                ],
            ],
            'finance' => [
                'current_year' => $currentYear,
                'previous_year' => $previousYear,
                'current' => [
                    'zaka' => (float) $totalsCurrent['zaka'],
                    'mavuno' => (float) $totalsCurrent['mavuno'],
                    'other' => (float) $totalsCurrent['other'],
                    'total' => (float) array_sum($totalsCurrent),
                ],
                'previous' => [
                    'zaka' => (float) $totalsPrevious['zaka'],
                    'mavuno' => (float) $totalsPrevious['mavuno'],
                    'other' => (float) $totalsPrevious['other'],
                    'total' => (float) array_sum($totalsPrevious),
                ],
            ],
        ];
    }

    public function store(array $data, User $user): Familia
    {
        $jumuiya = Jumuiya::findOrFail($data['jumuiya_id']);
        $this->scopeAccessGate->authorizeJumuiya($user, $jumuiya);

        return Familia::create([
            'jumuiya_id' => $data['jumuiya_id'],
            'name' => Str::upper(trim($data['name'])),
            'phone' => $data['phone'] ?? null,
            'envelope_no' => $data['envelope_no'] ?? null,
            'address' => $data['address'] ?? null,
            'notes' => $data['notes'] ?? null,
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);
    }

    public function update(Familia $familia, array $data, User $user): Familia
    {
        $this->scopeAccessGate->authorizeFamilia($user, $familia);

        $jumuiya = Jumuiya::findOrFail($data['jumuiya_id']);
        $this->scopeAccessGate->authorizeJumuiya($user, $jumuiya);

        $familia->update([
            'jumuiya_id' => $data['jumuiya_id'],
            'name' => Str::upper(trim($data['name'])),
            'phone' => $data['phone'] ?? null,
            'envelope_no' => $data['envelope_no'] ?? null,
            'address' => $data['address'] ?? null,
            'notes' => $data['notes'] ?? null,
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);

        return $familia->refresh();
    }

    public function delete(Familia $familia, User $user): bool
    {
        $this->scopeAccessGate->authorizeFamilia($user, $familia);

        if ($familia->members()->exists()) {
            abort(422, db_trans('cannot_delete_family_with_members'));
        }

        return (bool) $familia->delete();
    }

    public function addMember(Familia $familia, array $data, User $user): Member
    {
        $this->scopeAccessGate->authorizeFamilia($user, $familia);
        $data['member_code'] = $data['member_code'] ?: $this->generateMemberCode($familia);

        return Member::create([
            'familia_id' => $familia->id,
            'first_name' => Str::upper(trim($data['first_name'])),
            'middle_name' => filled($data['middle_name'] ?? null) ? Str::upper(trim($data['middle_name'])) : null,
            'last_name' => Str::upper(trim($data['last_name'])),
            'phone' => $data['phone'] ?? null,
            'gender' => $data['gender'] ?? null,
            'date_of_birth' => $data['date_of_birth'] ?? null,
            'occupation' => $data['occupation'] ?? null,
            'is_baptized' => (bool) ($data['is_baptized'] ?? false),
            'has_communion' => (bool) ($data['has_communion'] ?? false),
            'has_confirmation' => (bool) ($data['has_confirmation'] ?? false),
            'receives_eucharist' => (bool) ($data['receives_eucharist'] ?? false),
            'is_married' => (bool) ($data['is_married'] ?? false),
            'marriage_type' => $data['marriage_type'] ?? null,
            'baptism_certificate_number' => $data['baptism_certificate_number'] ?? null,
            'marriage_certificate_number' => $data['marriage_certificate_number'] ?? null,
            'baptism_parish' => $data['baptism_parish'] ?? null,
            'baptism_diocese' => $data['baptism_diocese'] ?? null,
            'family_role' => $data['family_role'] ?? null,
            'notes' => $data['notes'] ?? null,
            'member_code' => $data['member_code'],
            'bahasha' => $data['bahasha'] ?? null,
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);
    }

    public function updateMember(Familia $familia, Member $member, array $data, User $user): Member
    {
        $this->scopeAccessGate->authorizeFamilia($user, $familia);
        $this->scopeAccessGate->authorizeMember($user, $member);
        abort_unless((int) $member->familia_id === (int) $familia->id, 404);

        $member->update([
            'first_name' => Str::upper(trim($data['first_name'])),
            'middle_name' => filled($data['middle_name'] ?? null) ? Str::upper(trim($data['middle_name'])) : null,
            'last_name' => Str::upper(trim($data['last_name'])),
            'phone' => $data['phone'] ?? null,
            'gender' => $data['gender'] ?? null,
            'date_of_birth' => $data['date_of_birth'] ?? null,
            'occupation' => $data['occupation'] ?? null,
            'is_baptized' => (bool) ($data['is_baptized'] ?? false),
            'has_communion' => (bool) ($data['has_communion'] ?? false),
            'has_confirmation' => (bool) ($data['has_confirmation'] ?? false),
            'receives_eucharist' => (bool) ($data['receives_eucharist'] ?? false),
            'is_married' => (bool) ($data['is_married'] ?? false),
            'marriage_type' => $data['marriage_type'] ?? null,
            'baptism_certificate_number' => $data['baptism_certificate_number'] ?? null,
            'marriage_certificate_number' => $data['marriage_certificate_number'] ?? null,
            'baptism_parish' => $data['baptism_parish'] ?? null,
            'baptism_diocese' => $data['baptism_diocese'] ?? null,
            'family_role' => $data['family_role'] ?? null,
            'notes' => $data['notes'] ?? null,
            'member_code' => $data['member_code'] ?? $member->member_code,
            'bahasha' => $data['bahasha'] ?? null,
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);

        return $member->refresh();
    }

    public function deleteMember(Familia $familia, Member $member, User $user): bool
    {
        $this->scopeAccessGate->authorizeFamilia($user, $familia);
        $this->scopeAccessGate->authorizeMember($user, $member);
        abort_unless((int) $member->familia_id === (int) $familia->id, 404);

        $hasTithes = Tithe::query()->where('member_id', $member->id)->exists();
        $hasCashContributions = CashContribution::query()->where('member_id', $member->id)->exists();
        $hasGroupMemberships = class_exists(ApostolicGroupMember::class)
            ? ApostolicGroupMember::query()->where('member_id', $member->id)->exists()
            : false;

        if ($hasTithes || $hasCashContributions || $hasGroupMemberships) {
            abort(422, db_trans('cannot_delete_member_with_related_records'));
        }

        return (bool) $member->delete();
    }

    protected function scopedFamiliasQuery(User $user): Builder
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = Familia::query()
            ->select('familias.*')
            ->leftJoin('jumuiyas', 'jumuiyas.id', '=', 'familias.jumuiya_id');

        if ($scope->isInvalid()) {
            return $query->whereRaw('1 = 0');
        }

        if ($scope->isGlobal()) {
            return $query;
        }

        if ($scope->isKanda()) {
            return $query->where('jumuiyas.kanda_id', $scope->kandaId);
        }

        if ($scope->isJumuiya()) {
            return $query->where('familias.jumuiya_id', $scope->jumuiyaId);
        }

        return $query->whereRaw('1 = 0');
    }

    protected function availableJumuiyasForUser(User $user)
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = Jumuiya::query()->with('kanda')->orderBy('name');

        if ($scope->isInvalid()) {
            return collect();
        }

        if ($scope->isGlobal()) {
            return $query->get();
        }

        if ($scope->isKanda()) {
            return $query->where('kanda_id', $scope->kandaId)->get();
        }

        if ($scope->isJumuiya()) {
            return $query->whereKey($scope->jumuiyaId)->get();
        }

        return collect();
    }

    protected function generateMemberCode(Familia $familia): string
    {
        $familia->loadMissing('jumuiya.kanda');
        $prefix = optional($familia->jumuiya?->kanda)->code ?: 'MBR';
        $latestId = (Member::query()->max('id') ?? 0) + 1;

        return strtoupper($prefix) . str_pad((string) $latestId, 5, '0', STR_PAD_LEFT);
    }
}