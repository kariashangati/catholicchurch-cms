<?php

namespace App\Services\Communication\Support;

use App\Models\CommunicationPreference;
use App\Models\Member;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use InvalidArgumentException;

class RecipientResolverService
{
    public function __construct(
        protected PhoneNumberService $phoneNumberService,
    ) {
    }

    /**
     * Supported audience_type values:
     * - member
     * - members
     * - familia
     * - familias
     * - jumuiya
     * - jumuiyas
     * - kanda
     * - kandas
     * - apostolic_group
     * - apostolic_groups
     * - leadership_assignment
     * - leadership_assignments
     * - all_members
     * - all_active_members
     * - filtered_members
     */
    public function resolve(array $payload, bool $respectPreferences = true): Collection
    {
        $audienceType = $payload['audience_type'] ?? null;

        if (! $audienceType) {
            throw new InvalidArgumentException('The audience_type field is required.');
        }

        $recipients = match ($audienceType) {
            'member' => $this->resolveMembersByIds([$payload['member_id'] ?? null]),
            'members' => $this->resolveMembersByIds($payload['member_ids'] ?? []),

            'familia' => $this->resolveMembersFromFamilias([$payload['familia_id'] ?? null]),
            'familias' => $this->resolveMembersFromFamilias($payload['familia_ids'] ?? []),

            'jumuiya' => $this->resolveMembersFromJumuiyas([$payload['jumuiya_id'] ?? null]),
            'jumuiyas' => $this->resolveMembersFromJumuiyas($payload['jumuiya_ids'] ?? []),

            'kanda' => $this->resolveMembersFromKandas([$payload['kanda_id'] ?? null]),
            'kandas' => $this->resolveMembersFromKandas($payload['kanda_ids'] ?? []),

            'apostolic_group' => $this->resolveMembersFromApostolicGroups([$payload['apostolic_group_id'] ?? null]),
            'apostolic_groups' => $this->resolveMembersFromApostolicGroups($payload['apostolic_group_ids'] ?? []),

            'leadership_assignment' => $this->resolveMembersFromLeadershipAssignments([$payload['leadership_assignment_id'] ?? null]),
            'leadership_assignments' => $this->resolveMembersFromLeadershipAssignments($payload['leadership_assignment_ids'] ?? []),

            'all_members' => $this->resolveAllMembers(),
            'all_active_members' => $this->resolveAllActiveMembers(),

            'filtered_members' => $this->resolveFilteredMembers($payload['filters'] ?? []),

            default => throw new InvalidArgumentException("Unsupported audience_type [{$audienceType}]."),
        };

        return $this->transformMembersToRecipients($recipients, $respectPreferences)
            ->unique('phone_normalized')
            ->values();
    }

    protected function resolveMembersByIds(array $memberIds): Collection
    {
        $ids = collect($memberIds)->filter()->values();

        if ($ids->isEmpty()) {
            return collect();
        }

        return Member::query()
            ->whereIn('id', $ids)
            ->get();
    }

    protected function resolveMembersFromFamilias(array $familiaIds): Collection
    {
        $ids = collect($familiaIds)->filter()->values();

        if ($ids->isEmpty()) {
            return collect();
        }

        return Member::query()
            ->whereIn('familia_id', $ids)
            ->get();
    }

    protected function resolveMembersFromJumuiyas(array $jumuiyaIds): Collection
    {
        $ids = collect($jumuiyaIds)->filter()->values();

        if ($ids->isEmpty()) {
            return collect();
        }

        return Member::query()
            ->whereIn('jumuiya_id', $ids)
            ->get();
    }

    protected function resolveMembersFromKandas(array $kandaIds): Collection
    {
        $ids = collect($kandaIds)->filter()->values();

        if ($ids->isEmpty()) {
            return collect();
        }

        return Member::query()
            ->whereIn('kanda_id', $ids)
            ->get();
    }

    protected function resolveMembersFromApostolicGroups(array $groupIds): Collection
    {
        $ids = collect($groupIds)->filter()->values();

        if ($ids->isEmpty()) {
            return collect();
        }

        return Member::query()
            ->whereHas('apostolicGroups', function (Builder $query) use ($ids) {
                $query->whereIn('apostolic_groups.id', $ids);
            })
            ->get();
    }

    protected function resolveMembersFromLeadershipAssignments(array $assignmentIds): Collection
    {
        $ids = collect($assignmentIds)->filter()->values();

        if ($ids->isEmpty()) {
            return collect();
        }

        return Member::query()
            ->whereHas('leadershipAssignments', function (Builder $query) use ($ids) {
                $query->whereIn('leadership_assignments.id', $ids);
            })
            ->get();
    }

    protected function resolveAllMembers(): Collection
    {
        return Member::query()->get();
    }

    protected function resolveAllActiveMembers(): Collection
    {
        return Member::query()
            ->where('is_active', true)
            ->get();
    }

    protected function resolveFilteredMembers(array $filters): Collection
    {
        return Member::query()
            ->when(array_key_exists('is_active', $filters), fn (Builder $q) => $q->where('is_active', (bool) $filters['is_active']))
            ->when(! empty($filters['gender']), fn (Builder $q) => $q->where('gender', $filters['gender']))
            ->when(! empty($filters['age_group_id']), fn (Builder $q) => $q->where('age_group_id', $filters['age_group_id']))
            ->when(! empty($filters['familia_id']), fn (Builder $q) => $q->where('familia_id', $filters['familia_id']))
            ->when(! empty($filters['jumuiya_id']), fn (Builder $q) => $q->where('jumuiya_id', $filters['jumuiya_id']))
            ->when(! empty($filters['kanda_id']), fn (Builder $q) => $q->where('kanda_id', $filters['kanda_id']))
            ->when(! empty($filters['apostolic_group_id']), function (Builder $query) use ($filters) {
                $query->whereHas('apostolicGroups', function (Builder $subQuery) use ($filters) {
                    $subQuery->where('apostolic_groups.id', $filters['apostolic_group_id']);
                });
            })
            ->when(! empty($filters['leadership_position_id']), function (Builder $query) use ($filters) {
                $query->whereHas('leadershipAssignments', function (Builder $subQuery) use ($filters) {
                    $subQuery->where('leadership_position_id', $filters['leadership_position_id'])
                        ->where('status', 'active');
                });
            })
            ->get();
    }

    protected function transformMembersToRecipients(Collection $members, bool $respectPreferences): Collection
    {
        return $members
            ->map(function (Member $member) use ($respectPreferences) {
                $preferences = $member->communicationPreference;
                $rawPhone = $preferences?->preferred_phone ?: $member->phone;
                $normalizedPhone = $rawPhone
                    ? $this->phoneNumberService->normalize($rawPhone)
                    : null;

                $fullName = $member->name ?? trim(($member->first_name ?? '') . ' ' . ($member->last_name ?? ''));

                return [
                    'member_id' => $member->id,
                    'familia_id' => $member->familia_id,
                    'jumuiya_id' => $member->jumuiya_id,
                    'kanda_id' => $member->kanda_id,
                    'recipient_name' => $fullName,
                    'name' => $fullName,
                    'phone' => $rawPhone,
                    'phone_normalized' => $normalizedPhone,
                    'recipient_type' => 'member',
                    'locale' => $preferences?->preferred_locale ?: app()->getLocale(),
                    'can_receive' => $this->canReceiveSms($preferences, $respectPreferences),
                    'preference_reason' => $this->preferenceReason($preferences, $rawPhone, $normalizedPhone),
                ];
            })
            ->filter(fn (array $recipient) => $recipient['phone_normalized'] && $recipient['can_receive'])
            ->values();
    }

    protected function canReceiveSms(?CommunicationPreference $preferences, bool $respectPreferences): bool
    {
        if (! $respectPreferences) {
            return true;
        }

        if (! $preferences) {
            return true;
        }

        return (bool) ($preferences->allow_sms && is_null($preferences->opted_out_at));
    }

    protected function preferenceReason(?CommunicationPreference $preferences, ?string $rawPhone, ?string $normalizedPhone): ?string
    {
        if (! $rawPhone) {
            return 'missing_phone';
        }

        if (! $normalizedPhone) {
            return 'invalid_phone';
        }

        if ($preferences && ! $preferences->allow_sms) {
            return 'sms_disabled';
        }

        if ($preferences && $preferences->opted_out_at) {
            return 'opted_out';
        }

        return null;
    }
}