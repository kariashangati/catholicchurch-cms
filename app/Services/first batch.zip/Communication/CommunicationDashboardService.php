<?php

namespace App\Services\Communication;

use App\Models\CommunicationBalanceSnapshot;
use App\Models\CommunicationCampaign;
use App\Models\CommunicationMessage;
use Carbon\Carbon;
use Illuminate\Support\Facades\DB;

class CommunicationDashboardService
{
    public function getOverview(): array
    {
        $today = Carbon::today();
        $weekStart = Carbon::now()->startOfWeek();
        $monthStart = Carbon::now()->startOfMonth();

        $latestBalance = CommunicationBalanceSnapshot::query()
            ->latest('fetched_at')
            ->first();

        $messagesToday = CommunicationMessage::query()
            ->whereDate('created_at', $today)
            ->count();

        $messagesThisWeek = CommunicationMessage::query()
            ->where('created_at', '>=', $weekStart)
            ->count();

        $messagesThisMonth = CommunicationMessage::query()
            ->where('created_at', '>=', $monthStart)
            ->count();

        $sentToday = CommunicationMessage::query()
            ->whereDate('sent_at', $today)
            ->whereIn('status', ['sent'])
            ->count();

        $failedToday = CommunicationMessage::query()
            ->whereDate('created_at', $today)
            ->where('status', 'failed')
            ->count();

        $scheduledCount = CommunicationCampaign::query()
            ->where('status', 'scheduled')
            ->count();

        $processingCount = CommunicationCampaign::query()
            ->where('status', 'processing')
            ->count();

        $completionStats = CommunicationCampaign::query()
            ->selectRaw('COUNT(*) as total_campaigns')
            ->selectRaw('SUM(CASE WHEN status = "completed" THEN 1 ELSE 0 END) as completed_campaigns')
            ->selectRaw('SUM(CASE WHEN status = "partially_failed" THEN 1 ELSE 0 END) as partial_campaigns')
            ->selectRaw('SUM(CASE WHEN status = "failed" THEN 1 ELSE 0 END) as failed_campaigns')
            ->first();

        $recentCampaigns = CommunicationCampaign::query()
            ->latest()
            ->take(8)
            ->get();

        $recentFailures = CommunicationMessage::query()
            ->where('status', 'failed')
            ->latest('failed_at')
            ->take(10)
            ->get();

        $statusBreakdown = CommunicationMessage::query()
            ->select('status', DB::raw('COUNT(*) as total'))
            ->groupBy('status')
            ->pluck('total', 'status')
            ->toArray();

        return [
            'latest_balance' => $latestBalance,
            'kpis' => [
                'messages_today' => $messagesToday,
                'messages_this_week' => $messagesThisWeek,
                'messages_this_month' => $messagesThisMonth,
                'sent_today' => $sentToday,
                'failed_today' => $failedToday,
                'scheduled_count' => $scheduledCount,
                'processing_count' => $processingCount,
            ],
            'completion' => [
                'total_campaigns' => (int) ($completionStats->total_campaigns ?? 0),
                'completed_campaigns' => (int) ($completionStats->completed_campaigns ?? 0),
                'partial_campaigns' => (int) ($completionStats->partial_campaigns ?? 0),
                'failed_campaigns' => (int) ($completionStats->failed_campaigns ?? 0),
            ],
            'recent_campaigns' => $recentCampaigns,
            'recent_failures' => $recentFailures,
            'status_breakdown' => $statusBreakdown,
        ];
    }

    public function getBalanceSummary(): array
    {
        $latestBalance = CommunicationBalanceSnapshot::query()
            ->latest('fetched_at')
            ->first();

        $snapshots = CommunicationBalanceSnapshot::query()
            ->latest('fetched_at')
            ->paginate(20);

        $transactions = DB::table('communication_balance_transactions')
            ->latest('created_at')
            ->paginate(20, ['*'], 'transactions_page');

        return [
            'latest_balance' => $latestBalance,
            'snapshots' => $snapshots,
            'transactions' => $transactions,
        ];
    }
}
