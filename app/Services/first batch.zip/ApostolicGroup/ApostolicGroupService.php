<?php

namespace App\Services\ApostolicGroup;

use App\Models\ApostolicGroup;
use App\Models\ApostolicGroupMember;
use App\Models\Member;
use App\Models\User;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ApostolicGroupService
{
    public function getIndexData(User $user): array
    {
        $groups = ApostolicGroup::query()
            ->with(['leader', 'assistantLeader', 'patron'])
            ->withCount([
                'groupMembers as total_members_count',
                'groupMembers as active_members_count' => fn ($q) => $q->where('status', 'active'),
            ])
            ->latest()
            ->get();

        $recentGroups = $groups->take(5);
        $members = Member::query()->with('familia.jumuiya')->where('is_active', true)->orderBy('first_name')->get();

        $chartLabels = [];
        $chartData = [];
        for ($i = 5; $i >= 0; $i--) {
            $month = now()->copy()->subMonths($i);
            $chartLabels[] = $month->format('M Y');
            $chartData[] = ApostolicGroup::query()
                ->whereYear('created_at', $month->year)
                ->whereMonth('created_at', $month->month)
                ->count();
        }

        $membershipRoleCounts = ApostolicGroupMember::query()
            ->selectRaw('role, COUNT(*) as aggregate')
            ->groupBy('role')
            ->pluck('aggregate', 'role');

        $ruleTypeCounts = $groups->groupBy(fn ($group) => $group->membership_rule_type ?: 'manual')
            ->map->count();

        $meetingDayCounts = $groups->filter(fn ($group) => filled($group->meeting_day))
            ->groupBy('meeting_day')
            ->map->count();

        $groupsWithoutLeader = $groups->filter(fn ($group) => blank($group->leader_member_id))->count();
        $groupsWithMeetings = $groups->filter(fn ($group) => filled($group->meeting_day) || filled($group->meeting_time) || filled($group->meeting_location))->count();

        return [
            'pageTitle' => db_trans('apostolic_groups'),
            'groups' => $groups,
            'recentGroups' => $recentGroups,
            'availableMembers' => $members,
            'stats' => [
                'total_groups' => $groups->count(),
                'active_groups' => $groups->where('is_active', true)->count(),
                'inactive_groups' => $groups->where('is_active', false)->count(),
                'active_memberships' => $groups->sum('active_members_count'),
                'groups_without_leaders' => $groupsWithoutLeader,
                'groups_with_meetings' => $groupsWithMeetings,
                'manual_rule_groups' => $groups->where('membership_rule_type', 'manual')->count(),
                'auto_rule_groups' => $groups->whereIn('membership_rule_type', ['gender', 'family_role'])->count(),
            ],
            'chart' => [
                'labels' => $chartLabels,
                'data' => $chartData,
            ],
            'roleChart' => [
                'labels' => $this->formatRoleLabels(array_keys($membershipRoleCounts->toArray())),
                'data' => array_values($membershipRoleCounts->toArray()),
            ],
            'ruleChart' => [
                'labels' => $this->formatRuleTypeLabels(array_keys($ruleTypeCounts->toArray())),
                'data' => array_values($ruleTypeCounts->toArray()),
            ],
            'meetingChart' => [
                'labels' => array_keys($meetingDayCounts->toArray()),
                'data' => array_values($meetingDayCounts->toArray()),
            ],
        ];
    }

    public function getShowData(ApostolicGroup $group): array
    {
        $group->load(['leader', 'assistantLeader', 'patron']);

        $memberships = ApostolicGroupMember::query()
            ->with(['member.familia.jumuiya'])
            ->where('apostolic_group_id', $group->id)
            ->latest()
            ->get();

        $members = $memberships->pluck('member')->filter();

        $familiaCount = $members->pluck('familia_id')->filter()->unique()->count();
        $jumuiyaCount = $members->map(fn ($member) => $member?->familia?->jumuiya_id)->filter()->unique()->count();
        $maleMembers = $members->filter(fn ($member) => strtolower((string) $member->gender) === 'male')->count();
        $femaleMembers = $members->filter(fn ($member) => strtolower((string) $member->gender) === 'female')->count();
        $activeMembers = $memberships->where('status', 'active')->count();
        $inactiveMembers = $memberships->where('status', 'inactive')->count();
        $leadershipFilled = collect([$group->leader_member_id, $group->assistant_leader_member_id, $group->patron_member_id])->filter()->count();
        $profileReadiness = (int) round((collect([
            filled($group->leader_member_id),
            filled($group->meeting_day) || filled($group->meeting_time) || filled($group->meeting_location),
            filled($group->membership_rule_type),
            filled($group->founded_on),
            $activeMembers > 0,
        ])->filter()->count() / 5) * 100);

        $roleBreakdown = $memberships->groupBy('role')->map->count();

        return [
            'pageTitle' => db_trans('apostolic_group_details'),
            'group' => $group,
            'memberships' => $memberships,
            'availableMembers' => Member::query()->with('familia.jumuiya')->where('is_active', true)->orderBy('first_name')->get(),
            'stats' => [
                'total_members' => $memberships->count(),
                'active_members' => $activeMembers,
                'inactive_members' => $inactiveMembers,
                'male_members' => $maleMembers,
                'female_members' => $femaleMembers,
                'familias_represented' => $familiaCount,
                'jumuiyas_represented' => $jumuiyaCount,
                'leadership_filled' => $leadershipFilled,
                'profile_readiness' => $profileReadiness,
            ],
            'memberChart' => [
                'labels' => [db_trans('male_members'), db_trans('female_members')],
                'data' => [$maleMembers, $femaleMembers],
            ],
            'statusChart' => [
                'labels' => [db_trans('active_members'), db_trans('inactive_members')],
                'data' => [$activeMembers, $inactiveMembers],
            ],
            'roleChart' => [
                'labels' => $this->formatRoleLabels(array_keys($roleBreakdown->toArray())),
                'data' => array_values($roleBreakdown->toArray()),
            ],
        ];
    }

    public function store(array $data): ApostolicGroup
    {
        $imagePath = $this->storeImage($data['image'] ?? null);

        return ApostolicGroup::create([
            'name' => Str::upper(trim($data['name'])),
            'code' => Str::upper(trim($data['code'])),
            'slug' => Str::slug($data['name']),
            'notes' => $data['notes'] ?? null,
            'is_active' => (bool) ($data['is_active'] ?? true),
            'leader_member_id' => $data['leader_member_id'] ?? null,
            'assistant_leader_member_id' => $data['assistant_leader_member_id'] ?? null,
            'patron_member_id' => $data['patron_member_id'] ?? null,
            'membership_rule_type' => $data['membership_rule_type'] ?? 'manual',
            'membership_rule_value' => $data['membership_rule_value'] ?? null,
            'image' => $imagePath,
            'founded_on' => $data['founded_on'] ?? null,
            'meeting_day' => $data['meeting_day'] ?? null,
            'meeting_time' => $data['meeting_time'] ?? null,
            'meeting_location' => $data['meeting_location'] ?? null,
        ]);
    }

    public function update(ApostolicGroup $group, array $data): ApostolicGroup
    {
        $imagePath = $group->image;

        if (!empty($data['image'])) {
            if ($group->image && Storage::disk('public')->exists($group->image)) {
                Storage::disk('public')->delete($group->image);
            }
            $imagePath = $this->storeImage($data['image']);
        }

        $group->update([
            'name' => Str::upper(trim($data['name'])),
            'code' => Str::upper(trim($data['code'])),
            'slug' => Str::slug($data['name']),
            'notes' => $data['notes'] ?? null,
            'is_active' => (bool) ($data['is_active'] ?? true),
            'leader_member_id' => $data['leader_member_id'] ?? null,
            'assistant_leader_member_id' => $data['assistant_leader_member_id'] ?? null,
            'patron_member_id' => $data['patron_member_id'] ?? null,
            'membership_rule_type' => $data['membership_rule_type'] ?? 'manual',
            'membership_rule_value' => $data['membership_rule_value'] ?? null,
            'image' => $imagePath,
            'founded_on' => $data['founded_on'] ?? null,
            'meeting_day' => $data['meeting_day'] ?? null,
            'meeting_time' => $data['meeting_time'] ?? null,
            'meeting_location' => $data['meeting_location'] ?? null,
        ]);

        return $group->refresh();
    }

    public function delete(ApostolicGroup $group): bool
    {
        if ($group->image && Storage::disk('public')->exists($group->image)) {
            Storage::disk('public')->delete($group->image);
        }

        return (bool) $group->delete();
    }

    public function addMembers(ApostolicGroup $group, array $memberIds, array $payload, User $user): void
    {
        DB::transaction(function () use ($group, $memberIds, $payload, $user) {
            foreach ($memberIds as $memberId) {
                ApostolicGroupMember::updateOrCreate(
                    [
                        'apostolic_group_id' => $group->id,
                        'member_id' => $memberId,
                    ],
                    [
                        'role' => $payload['role'] ?? 'member',
                        'status' => $payload['status'] ?? 'active',
                        'joined_at' => $payload['joined_at'] ?? now()->toDateString(),
                        'left_at' => ($payload['status'] ?? 'active') === 'inactive' ? ($payload['left_at'] ?? now()->toDateString()) : null,
                        'notes' => $payload['notes'] ?? null,
                        'added_by' => $user->id,
                    ]
                );
            }
        });
    }

    public function updateMembership(ApostolicGroupMember $membership, array $data): ApostolicGroupMember
    {
        $membership->update([
            'role' => $data['role'],
            'status' => $data['status'],
            'joined_at' => $data['joined_at'] ?? $membership->joined_at,
            'left_at' => $data['status'] === 'inactive' ? ($data['left_at'] ?? now()->toDateString()) : null,
            'notes' => $data['notes'] ?? null,
        ]);

        return $membership->refresh();
    }

    public function removeMembership(ApostolicGroupMember $membership): bool
    {
        return (bool) $membership->delete();
    }

    public function syncRuleMembers(ApostolicGroup $group, User $user): int
    {
        $query = Member::query()->where('is_active', true);

        if ($group->membership_rule_type === 'gender' && filled($group->membership_rule_value)) {
            $query->whereRaw('LOWER(gender) = ?', [strtolower($group->membership_rule_value)]);
        } elseif ($group->membership_rule_type === 'family_role' && filled($group->membership_rule_value)) {
            $query->whereRaw('LOWER(family_role) = ?', [strtolower($group->membership_rule_value)]);
        } else {
            return 0;
        }

        $memberIds = $query->pluck('id');

        $count = 0;
        DB::transaction(function () use ($group, $memberIds, $user, &$count) {
            foreach ($memberIds as $memberId) {
                $membership = ApostolicGroupMember::firstOrCreate(
                    [
                        'apostolic_group_id' => $group->id,
                        'member_id' => $memberId,
                    ],
                    [
                        'role' => 'member',
                        'status' => 'active',
                        'joined_at' => now()->toDateString(),
                        'added_by' => $user->id,
                    ]
                );

                if ($membership->wasRecentlyCreated) {
                    $count++;
                }
            }
        });

        return $count;
    }

    protected function storeImage(?UploadedFile $file): ?string
    {
        if (!$file) {
            return null;
        }

        return $file->store('apostolic-groups', 'public');
    }

    protected function formatRoleLabels(array $roles): array
    {
        return collect($roles)->map(function ($role) {
            return db_trans($role) !== $role ? db_trans($role) : Str::headline((string) $role);
        })->values()->all();
    }

    protected function formatRuleTypeLabels(array $types): array
    {
        return collect($types)->map(function ($type) {
            return match ($type) {
                'manual' => db_trans('manual_rule'),
                'gender' => db_trans('gender_rule'),
                'family_role' => db_trans('family_role_rule'),
                default => Str::headline((string) $type),
            };
        })->values()->all();
    }
}
