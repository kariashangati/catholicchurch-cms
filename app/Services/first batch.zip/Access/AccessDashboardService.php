<?php

namespace App\Services\Access;

use App\Models\Permission;
use App\Models\User;
use Spatie\Permission\Models\Role;

class AccessDashboardService
{
    public function getDataFor(User $user): array
    {
        abort_unless($user->can('access.dashboard.view'), 403);

        return [
            'page' => [
                'title' => db_trans('access_control_center'),
                'subtitle' => db_trans('manage_admin_users_roles_permissions_and_access_notifications'),
                'updated_at' => now(),
            ],
            'kpis' => [
                [
                    'title' => db_trans('total_admin_users'),
                    'value' => User::query()->count(),
                    'icon' => 'fas fa-user-shield',
                    'tone' => 'primary',
                ],
                [
                    'title' => db_trans('active_admin_users'),
                    'value' => User::query()->where('is_active', true)->count(),
                    'icon' => 'fas fa-user-check',
                    'tone' => 'success',
                ],
                [
                    'title' => db_trans('inactive_admin_users'),
                    'value' => User::query()->where('is_active', false)->count(),
                    'icon' => 'fas fa-user-slash',
                    'tone' => 'warning',
                ],
                [
                    'title' => db_trans('roles_count'),
                    'value' => Role::query()->count(),
                    'icon' => 'fas fa-id-badge',
                    'tone' => 'info',
                ],
                [
                    'title' => db_trans('permissions_count'),
                    'value' => Permission::query()->count(),
                    'icon' => 'fas fa-key',
                    'tone' => 'secondary',
                ],
                [
                    'title' => db_trans('disabled_permissions'),
                    'value' => Permission::query()->where('is_active', false)->count(),
                    'icon' => 'fas fa-toggle-off',
                    'tone' => 'danger',
                ],
            ],
            'recentUsers' => User::query()
                ->with(['roles', 'kanda', 'jumuiya', 'member'])
                ->latest()
                ->take(8)
                ->get(),
            'recentRoles' => Role::query()
                ->withCount(['users', 'permissions'])
                ->latest()
                ->take(8)
                ->get(),
            'permissionModules' => Permission::query()
                ->selectRaw('module, COUNT(*) as total')
                ->groupBy('module')
                ->orderBy('module')
                ->get(),
        ];
    }
}