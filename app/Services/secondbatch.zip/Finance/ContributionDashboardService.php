<?php

namespace App\Services\Finance;

use App\Models\BankContribution;
use App\Models\CashContribution;
use App\Models\ContributionType;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class ContributionDashboardService
{
    public function __construct(
        protected ContributionAccessService $access
    ) {
    }

    public function getDashboardData(User $user, array $filters = []): array
    {
        $year = (int) ($filters['year'] ?? now()->year);

        $cashQuery = CashContribution::query()->select('cash_contributions.*');
        $bankQuery = BankContribution::query()->select('bank_contributions.*');

        $cashQuery = $this->access->applyMemberScope($cashQuery, $user);
        $bankQuery = $this->access->applyMemberScope($bankQuery, $user);

        if (! empty($filters['contribution_type_id'])) {
            $cashQuery->where('cash_contributions.contribution_type_id', (int) $filters['contribution_type_id']);
            $bankQuery->where('bank_contributions.contribution_type_id', (int) $filters['contribution_type_id']);
        }

        if (! empty($filters['status'])) {
            $cashQuery->where('cash_contributions.status', $filters['status']);
            $bankQuery->where('bank_contributions.status', $filters['status']);
        }

        $cashYearQuery = (clone $cashQuery)->whereYear('cash_contributions.contribution_date', $year);
        $bankYearQuery = (clone $bankQuery)->whereYear('bank_contributions.contribution_date', $year);

        $cashTotal = (float) (clone $cashYearQuery)->sum('cash_contributions.amount');
        $bankTotal = (float) (clone $bankYearQuery)->sum('bank_contributions.amount');
        $grandTotal = $cashTotal + $bankTotal;

        return [
            'year' => $year,
            'filters' => [
                'year' => $year,
                'contribution_type_id' => $filters['contribution_type_id'] ?? null,
                'status' => $filters['status'] ?? null,
            ],
            'stats' => [
                'cash_total' => $cashTotal,
                'bank_total' => $bankTotal,
                'grand_total' => $grandTotal,
                'cash_count' => (int) (clone $cashYearQuery)->count(),
                'bank_count' => (int) (clone $bankYearQuery)->count(),
                'type_count' => ContributionType::query()->where('is_active', true)->count(),
            ],
            'monthly' => $this->monthlyBreakdown($cashQuery, $bankQuery, $year),
            'topTypes' => $this->topContributionTypes($cashQuery, $bankQuery, $year),
            'recentCash' => (clone $cashYearQuery)
                ->with(['member', 'contributionType'])
                ->latest('cash_contributions.contribution_date')
                ->latest('cash_contributions.id')
                ->limit(5)
                ->get(),
            'recentBank' => (clone $bankYearQuery)
                ->with(['member', 'contributionType', 'bankAccount'])
                ->latest('bank_contributions.contribution_date')
                ->latest('bank_contributions.id')
                ->limit(5)
                ->get(),
        ];
    }

    protected function monthlyBreakdown(Builder $cashQuery, Builder $bankQuery, int $year): Collection
    {
        return collect(range(1, 12))
            ->map(function (int $month) use ($cashQuery, $bankQuery, $year) {
                return [
                    'label' => Carbon::create()->month($month)->format('M'),
                    'cash_amount' => (float) (clone $cashQuery)
                        ->whereYear('cash_contributions.contribution_date', $year)
                        ->whereMonth('cash_contributions.contribution_date', $month)
                        ->sum('cash_contributions.amount'),
                    'bank_amount' => (float) (clone $bankQuery)
                        ->whereYear('bank_contributions.contribution_date', $year)
                        ->whereMonth('bank_contributions.contribution_date', $month)
                        ->sum('bank_contributions.amount'),
                ];
            })
            ->map(function (array $row) {
                $row['total_amount'] = (float) $row['cash_amount'] + (float) $row['bank_amount'];

                return $row;
            });
    }

    protected function topContributionTypes(Builder $cashQuery, Builder $bankQuery, int $year): Collection
    {
        $cash = (clone $cashQuery)
            ->join('contribution_types', 'contribution_types.id', '=', 'cash_contributions.contribution_type_id')
            ->whereYear('cash_contributions.contribution_date', $year)
            ->select('contribution_types.name', DB::raw('SUM(cash_contributions.amount) as amount'))
            ->groupBy('contribution_types.name')
            ->pluck('amount', 'name');

        $bank = (clone $bankQuery)
            ->join('contribution_types', 'contribution_types.id', '=', 'bank_contributions.contribution_type_id')
            ->whereYear('bank_contributions.contribution_date', $year)
            ->select('contribution_types.name', DB::raw('SUM(bank_contributions.amount) as amount'))
            ->groupBy('contribution_types.name')
            ->pluck('amount', 'name');

        return $cash->keys()
            ->merge($bank->keys())
            ->unique()
            ->map(function (string $name) use ($cash, $bank) {
                return [
                    'name' => $name,
                    'cash_amount' => (float) ($cash[$name] ?? 0),
                    'bank_amount' => (float) ($bank[$name] ?? 0),
                    'total_amount' => (float) ($cash[$name] ?? 0) + (float) ($bank[$name] ?? 0),
                ];
            })
            ->sortByDesc('total_amount')
            ->take(8)
            ->values();
    }
}