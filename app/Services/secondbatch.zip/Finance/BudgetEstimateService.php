<?php

namespace App\Services\Finance;

use App\Models\BudgetExpenseEstimate;
use App\Models\BudgetIncomeEstimate;
use App\Models\ContributionType;
use App\Models\OfferingType;

class BudgetEstimateService
{
    public function dashboardData(int $year): array
    {
        $income = (float) BudgetIncomeEstimate::query()->where('budget_year', $year)->sum('amount');
        $expense = (float) BudgetExpenseEstimate::query()->where('budget_year', $year)->sum('amount');

        return [
            'year' => $year,
            'income_total' => $income,
            'expense_total' => $expense,
            'net_total' => $income - $expense,
        ];
    }

    public function incomeIndexData(int $year): array
    {
        return [
            'year' => $year,
            'records' => BudgetIncomeEstimate::query()->where('budget_year', $year)->latest()->get(),
            'total' => (float) BudgetIncomeEstimate::query()->where('budget_year', $year)->sum('amount'),
            'sourceOptions' => BudgetIncomeEstimate::sourceOptions(),
            'groupOptions' => BudgetIncomeEstimate::groupOptions(),
            'suggestedCategories' => collect(['Tithe', 'Main Offering'])
                ->merge(OfferingType::query()->where('is_active', true)->pluck('name'))
                ->merge(ContributionType::query()->where('is_active', true)->pluck('name'))
                ->unique()->values(),
        ];
    }

    public function expenseIndexData(int $year): array
    {
        return [
            'year' => $year,
            'records' => BudgetExpenseEstimate::query()->where('budget_year', $year)->latest()->get(),
            'total' => (float) BudgetExpenseEstimate::query()->where('budget_year', $year)->sum('amount'),
            'groupOptions' => BudgetExpenseEstimate::groupOptions(),
            'suggestedCategories' => collect(['Maintenance', 'Utilities', 'Charity', 'Transport', 'Office Operations', 'Youth Ministry']),
        ];
    }
}
