<?php

namespace App\Services\Finance;

use App\Models\Project;
use App\Models\ProjectCategory;
use App\Models\ProjectTransaction;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class ProjectFinanceDashboardService
{
    public function getDashboardData(array $filters = []): array
    {
        $year = (int) ($filters['year'] ?? now()->year);
        $month = !empty($filters['month']) ? (int) $filters['month'] : null;

        $projectsQuery = $this->projectQuery($filters);
        $transactionsQuery = $this->transactionQuery($filters);

        $monthIncome = (clone $transactionsQuery)
            ->where('transaction_type', ProjectTransaction::TYPE_INCOME)
            ->when($month, fn ($q) => $q->whereMonth('transaction_date', $month), fn ($q) => $q->whereMonth('transaction_date', now()->month))
            ->sum('amount');

        $monthExpense = (clone $transactionsQuery)
            ->where('transaction_type', ProjectTransaction::TYPE_EXPENSE)
            ->when($month, fn ($q) => $q->whereMonth('transaction_date', $month), fn ($q) => $q->whereMonth('transaction_date', now()->month))
            ->sum('amount');

        $yearIncome = (clone $transactionsQuery)
            ->where('transaction_type', ProjectTransaction::TYPE_INCOME)
            ->sum('amount');

        $yearExpense = (clone $transactionsQuery)
            ->where('transaction_type', ProjectTransaction::TYPE_EXPENSE)
            ->sum('amount');

        $pendingTransactions = (clone $transactionsQuery)
            ->where('status', ProjectTransaction::STATUS_PENDING)
            ->count();

        $activeProjects = (clone $projectsQuery)
            ->where('status', Project::STATUS_ACTIVE)
            ->count();

        $completedProjects = (clone $projectsQuery)
            ->where('status', Project::STATUS_COMPLETED)
            ->count();

        $projectCount = (clone $projectsQuery)->count();

        $monthlyTrend = collect(range(1, 12))->map(function (int $monthNumber) use ($year, $filters) {
            $query = $this->transactionQuery(array_merge($filters, ['year' => $year]));

            return [
                'label' => Carbon::create()->month($monthNumber)->format('M'),
                'income' => (float) (clone $query)
                    ->whereMonth('transaction_date', $monthNumber)
                    ->where('transaction_type', ProjectTransaction::TYPE_INCOME)
                    ->sum('amount'),
                'expense' => (float) (clone $query)
                    ->whereMonth('transaction_date', $monthNumber)
                    ->where('transaction_type', ProjectTransaction::TYPE_EXPENSE)
                    ->sum('amount'),
            ];
        });

        $topProjects = $this->topProjects($filters);
        $categoryBreakdown = $this->categoryBreakdown($filters);
        $recentTransactions = $this->transactionQuery($filters)
            ->with(['project.category', 'recorder', 'approver'])
            ->latest('transaction_date')
            ->latest('id')
            ->limit(8)
            ->get();

        return [
            'pageTitle' => db_trans('project_finance'),
            'filters' => $filters,
            'stats' => [
                'month_income' => $monthIncome,
                'month_expense' => $monthExpense,
                'month_net' => $monthIncome - $monthExpense,
                'year_income' => $yearIncome,
                'year_expense' => $yearExpense,
                'year_net' => $yearIncome - $yearExpense,
                'project_count' => $projectCount,
                'active_projects' => $activeProjects,
                'completed_projects' => $completedProjects,
                'pending_transactions' => $pendingTransactions,
            ],
            'monthlyChart' => [
                'labels' => $monthlyTrend->pluck('label')->values(),
                'income' => $monthlyTrend->pluck('income')->values(),
                'expense' => $monthlyTrend->pluck('expense')->values(),
            ],
            'categoryChart' => [
                'labels' => $categoryBreakdown->pluck('name')->values(),
                'amounts' => $categoryBreakdown->pluck('amount')->values(),
            ],
            'topProjects' => $topProjects,
            'recentTransactions' => $recentTransactions,
        ];
    }

    public function getIndexData(array $filters = []): array
    {
        return [
            'pageTitle' => db_trans('project_finance'),
            'filters' => $filters,
            'categories' => ProjectCategory::query()->withCount('projects')->orderBy('name')->get(),
            'projects' => $this->projectQuery($filters)
                ->with('category')
                ->withSum(['transactions as total_income' => fn ($q) => $q->where('transaction_type', ProjectTransaction::TYPE_INCOME)], 'amount')
                ->withSum(['transactions as total_expense' => fn ($q) => $q->where('transaction_type', ProjectTransaction::TYPE_EXPENSE)], 'amount')
                ->latest('id')
                ->get(),
            'transactions' => $this->transactionQuery($filters)
                ->with(['project.category', 'recorder', 'approver'])
                ->latest('transaction_date')
                ->latest('id')
                ->paginate(15)
                ->withQueryString(),
        ];
    }

    protected function projectQuery(array $filters = [])
    {
        return Project::query()
            ->when(!empty($filters['project_category_id']), fn ($q) => $q->where('project_category_id', (int) $filters['project_category_id']))
            ->when(!empty($filters['project_id']), fn ($q) => $q->where('id', (int) $filters['project_id']))
            ->when(!empty($filters['project_status']), fn ($q) => $q->where('status', $filters['project_status']));
    }

    protected function transactionQuery(array $filters = [])
    {
        $year = (int) ($filters['year'] ?? now()->year);

        return ProjectTransaction::query()
            ->whereYear('transaction_date', $year)
            ->when(!empty($filters['month']), fn ($q) => $q->whereMonth('transaction_date', (int) $filters['month']))
            ->when(!empty($filters['transaction_type']), fn ($q) => $q->where('transaction_type', $filters['transaction_type']))
            ->when(!empty($filters['transaction_status']), fn ($q) => $q->where('status', $filters['transaction_status']))
            ->when(!empty($filters['project_id']), fn ($q) => $q->where('project_id', (int) $filters['project_id']))
            ->when(!empty($filters['project_category_id']), function ($q) use ($filters) {
                $q->whereHas('project', fn ($projectQ) => $projectQ->where('project_category_id', (int) $filters['project_category_id']));
            })
            ->when(!empty($filters['project_status']), function ($q) use ($filters) {
                $q->whereHas('project', fn ($projectQ) => $projectQ->where('status', $filters['project_status']));
            });
    }

    protected function topProjects(array $filters = []): Collection
    {
        return $this->projectQuery($filters)
            ->withSum(['transactions as total_income' => fn ($q) => $q->where('transaction_type', ProjectTransaction::TYPE_INCOME)], 'amount')
            ->withSum(['transactions as total_expense' => fn ($q) => $q->where('transaction_type', ProjectTransaction::TYPE_EXPENSE)], 'amount')
            ->get()
            ->map(function (Project $project) {
                $income = (float) ($project->total_income ?? 0);
                $expense = (float) ($project->total_expense ?? 0);

                return (object) [
                    'id' => $project->id,
                    'name' => $project->name,
                    'status' => $project->status,
                    'income' => $income,
                    'expense' => $expense,
                    'net' => $income - $expense,
                ];
            })
            ->sortByDesc('income')
            ->take(8)
            ->values();
    }

    protected function categoryBreakdown(array $filters = []): Collection
    {
        return ProjectCategory::query()
            ->with(['projects.transactions'])
            ->get()
            ->map(function (ProjectCategory $category) use ($filters) {
                $amount = 0;

                foreach ($category->projects as $project) {
                    foreach ($project->transactions as $transaction) {
                        if (!empty($filters['year']) && (int) $transaction->transaction_date?->format('Y') !== (int) $filters['year']) {
                            continue;
                        }

                        if (!empty($filters['month']) && (int) $transaction->transaction_date?->format('n') !== (int) $filters['month']) {
                            continue;
                        }

                        if ($transaction->transaction_type === ProjectTransaction::TYPE_INCOME) {
                            $amount += (float) $transaction->amount;
                        }
                    }
                }

                return (object) [
                    'name' => $category->name,
                    'amount' => $amount,
                ];
            })
            ->filter(fn ($row) => $row->amount > 0)
            ->values();
    }
}
