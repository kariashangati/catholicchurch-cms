<?php

namespace App\Services\Finance;

use App\Models\Jumuiya;
use App\Models\Member;
use App\Models\Tithe;
use App\Models\User;
use App\Services\Access\UserScopeResolver;
use Carbon\Carbon;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class TitheDashboardService
{
    public function __construct(
        protected TitheAccessService $access,
        protected UserScopeResolver $scopeResolver,
    ) {
    }

    public function dashboardData(User $user, array $filters = []): array
    {
        $filters = $this->normalizeFilters($user, $filters);

        $year = (int) ($filters['year'] ?? now()->year);
        $month = ! empty($filters['month']) ? (int) $filters['month'] : null;

        $base = $this->query($user, ['year' => $year]);
        $filtered = $this->query($user, array_filter([
            'year' => $year,
            'month' => $month,
            'jumuiya_id' => $filters['jumuiya_id'] ?? null,
            'status' => $filters['status'] ?? null,
            'payment_method' => $filters['payment_method'] ?? null,
            'member_id' => $filters['member_id'] ?? null,
        ]));

        $monthlyTrend = collect(range(1, 12))->map(function (int $m) use ($user, $year, $filters) {
            $query = $this->query($user, array_filter([
                'year' => $year,
                'month' => $m,
                'jumuiya_id' => $filters['jumuiya_id'] ?? null,
                'status' => $filters['status'] ?? null,
                'payment_method' => $filters['payment_method'] ?? null,
                'member_id' => $filters['member_id'] ?? null,
            ]));

            return [
                'label' => Carbon::create()->month($m)->format('M'),
                'amount' => (float) (clone $query)->sum('amount'),
                'members' => (int) (clone $query)->distinct('member_id')->count('member_id'),
            ];
        });

        $topJumuiyasYear = $this->topJumuiyas($user, $year, null, 5, $filters);
        $topJumuiyasMonth = $this->topJumuiyas($user, $year, $month ?: now()->month, 5, $filters);
        $topKandas = $this->topKandas($user, $year, $month, 5, $filters);

        $recent = (clone $filtered)
            ->with(['member.familia.jumuiya.kanda', 'jumuiya', 'recorder', 'approver'])
            ->latest('contribution_date')
            ->latest('id')
            ->limit(8)
            ->get();

        $monthTotal = (float) (clone $filtered)->sum('amount');
        $yearTotal = (float) (clone $base)->sum('amount');
        $approvedTotal = (float) (clone $base)->where('status', Tithe::STATUS_APPROVED)->sum('amount');
        $pendingTotal = (float) (clone $base)->where('status', Tithe::STATUS_PENDING)->sum('amount');
        $recordsCount = (int) (clone $base)->count();
        $membersPaidCount = (int) (clone $base)->distinct('member_id')->count('member_id');

        $duplicateMonthlyMembers = (int) $this->duplicateMonthlyGroups($user, [
            'year' => $year,
            'month' => $month,
            'jumuiya_id' => $filters['jumuiya_id'] ?? null,
        ])->count();

        return [
            'pageTitle' => db_trans('tithe_dashboard'),
            'filters' => $filters,
            'hero' => [
                'eyebrow' => db_trans('finance'),
                'title' => db_trans('tithe_dashboard'),
                'subtitle' => db_trans('manage_financial_records'),
                'scope_badge' => $this->scopeLabel($user),
                'pending_items' => (int) (clone $base)->where('status', Tithe::STATUS_PENDING)->count(),
            ],
            'stats' => [
                'month_total' => $monthTotal,
                'year_total' => $yearTotal,
                'approved_total' => $approvedTotal,
                'pending_total' => $pendingTotal,
                'records_count' => $recordsCount,
                'members_paid_count' => $membersPaidCount,
                'average_per_member' => $membersPaidCount > 0 ? round($yearTotal / $membersPaidCount, 2) : 0,
                'duplicate_monthly_members' => $duplicateMonthlyMembers,
            ],
            'summaryCards' => [
                ['title' => db_trans('month'), 'value' => number_format($monthTotal, 2), 'meta' => db_trans('current_year_breakdown'), 'icon' => 'fas fa-calendar-day', 'tone' => 'primary'],
                ['title' => db_trans('year'), 'value' => number_format($yearTotal, 2), 'meta' => db_trans('financial_summary'), 'icon' => 'fas fa-calendar', 'tone' => 'success'],
                ['title' => db_trans('approved_total'), 'value' => number_format($approvedTotal, 2), 'meta' => db_trans('status_breakdown'), 'icon' => 'fas fa-circle-check', 'tone' => 'info'],
                ['title' => db_trans('pending_total'), 'value' => number_format($pendingTotal, 2), 'meta' => db_trans('pending_finance_records'), 'icon' => 'fas fa-clock', 'tone' => 'warning'],
                ['title' => db_trans('members_paid'), 'value' => number_format($membersPaidCount), 'meta' => db_trans('records'), 'icon' => 'fas fa-users', 'tone' => 'dark'],
                ['title' => db_trans('records'), 'value' => number_format($recordsCount), 'meta' => db_trans('recent_tithes'), 'icon' => 'fas fa-receipt', 'tone' => 'danger'],
            ],
            'monthlyChart' => [
                'labels' => $monthlyTrend->pluck('label')->values(),
                'amounts' => $monthlyTrend->pluck('amount')->values(),
                'members' => $monthlyTrend->pluck('members')->values(),
            ],
            'statusChart' => [
                'labels' => collect(Tithe::availableStatuses())->map(fn ($status) => ucfirst($status))->values(),
                'amounts' => collect(Tithe::availableStatuses())->map(fn ($status) => (float) (clone $base)->where('status', $status)->sum('amount'))->values(),
            ],
            'topJumuiyasYear' => $topJumuiyasYear,
            'topJumuiyasMonth' => $topJumuiyasMonth,
            'topKandas' => $topKandas,
            'recentTithes' => $recent,
            'quickLinks' => [
                ['label' => db_trans('record_tithe'), 'icon' => 'fas fa-plus-circle', 'route' => route('finance.tithes.index')],
                ['label' => db_trans('bulk_tithe_entry'), 'icon' => 'fas fa-layer-group', 'route' => route('finance.tithes.bulk.entry')],
                ['label' => db_trans('monthly_matrix'), 'icon' => 'fas fa-table', 'route' => route('finance.tithes.index')],
                ['label' => db_trans('finance_dashboard'), 'icon' => 'fas fa-chart-pie', 'route' => route('finance.dashboard')],
            ],
        ];
    }

    public function indexData(User $user, array $filters = []): array
    {
        $filters = $this->normalizeFilters($user, $filters);

        $query = $this->query($user, $filters)
            ->with(['member.familia.jumuiya.kanda', 'jumuiya', 'recorder', 'approver'])
            ->latest('contribution_date')
            ->latest('id');

        return [
            'pageTitle' => db_trans('tithes'),
            'filters' => $filters,
            'items' => $query->paginate(20)->withQueryString(),
            'total' => (float) $this->query($user, $filters)->sum('amount'),
            'defaultBulkDate' => now()->subMonthNoOverflow()->toDateString(),
        ];
    }

    public function bulkEntryData(User $user, array $filters = []): array
    {
        $filters = $this->normalizeFilters($user, $filters);

        $selectedDate = ! empty($filters['date']) ? Carbon::parse($filters['date']) : now()->subMonthNoOverflow();
        $selectedJumuiyaId = (int) ($filters['jumuiya_id'] ?? 0);
        $selectedKandaId = (int) ($filters['kanda_id'] ?? 0);

        $rows = collect();
        $existingMembers = collect();

        if ($selectedJumuiyaId > 0) {
            $rows = Member::query()
                ->whereHas('familia', fn (Builder $q) => $q->where('jumuiya_id', $selectedJumuiyaId))
                ->with('familia')
                ->orderBy('first_name')
                ->get();

            $existingMembers = $this->query($user, [
                'year' => (int) $selectedDate->format('Y'),
                'month' => (int) $selectedDate->format('n'),
                'jumuiya_id' => $selectedJumuiyaId,
            ], false)
                ->with(['member:id,first_name,middle_name,last_name,member_code', 'recorder:id,name'])
                ->get()
                ->groupBy('member_id');
        }

        return [
            'pageTitle' => db_trans('bulk_tithe_entry'),
            'selectedDate' => $selectedDate->toDateString(),
            'selectedMonthLabel' => $selectedDate->translatedFormat('F Y'),
            'selectedJumuiyaId' => $selectedJumuiyaId,
            'selectedKandaId' => $selectedKandaId,
            'rows' => $rows,
            'existingMembers' => $existingMembers,
            'denominationOptions' => [10000, 5000, 2000, 1000, 500, 200, 100],
        ];
    }

    public function duplicateReviewData(User $user, array $filters = []): array
    {
        $filters = $this->normalizeFilters($user, $filters);

        $groups = $this->duplicateMonthlyGroups($user, $filters)
            ->paginate(20)
            ->withQueryString();

        return [
            'pageTitle' => db_trans('duplicate_monthly_tithes_review'),
            'filters' => $filters,
            'groups' => $groups,
        ];
    }

    public function jumuiyaDetail(User $user, Jumuiya $jumuiya, array $filters = []): array
    {
        $this->ensureCanSeeJumuiya($user, $jumuiya);

        $year = (int) ($filters['year'] ?? now()->year);

        $base = $this->query($user, [
            'year' => $year,
            'jumuiya_id' => $jumuiya->id,
        ], false)
            ->leftJoin('members', 'members.id', '=', 'tithes.member_id')
            ->leftJoin('familias', 'familias.id', '=', 'members.familia_id');

        $members = $base
            ->selectRaw('members.id as member_id')
            ->selectRaw("TRIM(CONCAT(COALESCE(members.first_name, ''), ' ', COALESCE(members.middle_name, ''), ' ', COALESCE(members.last_name, ''))) as member_name")
            ->selectRaw('members.member_code')
            ->selectRaw('members.bahasha')
            ->selectRaw('familias.name as familia_name')
            ->selectRaw('SUM(tithes.amount) as total_amount')
            ->groupBy(
                'members.id',
                'members.first_name',
                'members.middle_name',
                'members.last_name',
                'members.member_code',
                'members.bahasha',
                'familias.name'
            )
            ->orderByDesc(DB::raw('SUM(tithes.amount)'))
            ->get();

        return [
            'pageTitle' => db_trans('jumuiya_tithe_detail'),
            'jumuiya' => $jumuiya->load('kanda'),
            'filters' => $filters,
            'items' => $members,
            'total' => (float) $members->sum('total_amount'),
        ];
    }

    public function monthlyBreakdown(User $user, int $month, int $year): array
    {
        $items = $this->query($user, ['year' => $year, 'month' => $month], false)
            ->leftJoin('jumuiyas', 'jumuiyas.id', '=', 'tithes.jumuiya_id')
            ->leftJoin('kandas', 'kandas.id', '=', 'jumuiyas.kanda_id')
            ->selectRaw('jumuiyas.id as jumuiya_id')
            ->selectRaw('COALESCE(jumuiyas.name, ?) as jumuiya_name', [db_trans('unknown')])
            ->selectRaw('COALESCE(kandas.name, ?) as kanda_name', [db_trans('unknown')])
            ->selectRaw('SUM(tithes.amount) as total_amount')
            ->groupBy('jumuiyas.id', 'jumuiyas.name', 'kandas.name')
            ->orderByDesc(DB::raw('SUM(tithes.amount)'))
            ->get();

        return [
            'pageTitle' => db_trans('monthly_tithe_breakdown'),
            'month' => $month,
            'year' => $year,
            'items' => $items,
            'total' => (float) $items->sum('total_amount'),
        ];
    }

    public function memberMatrix(User $user, Jumuiya $jumuiya, int $year): array
    {
        $this->ensureCanSeeJumuiya($user, $jumuiya);

        $members = Member::query()
            ->whereHas('familia', fn (Builder $q) => $q->where('jumuiya_id', $jumuiya->id))
            ->with('familia')
            ->orderBy('first_name')
            ->get();

        $payments = $this->query($user, ['year' => $year, 'jumuiya_id' => $jumuiya->id], false)
            ->selectRaw('tithes.member_id as member_id')
            ->selectRaw('MONTH(tithes.contribution_date) as month_no')
            ->selectRaw('SUM(tithes.amount) as total_amount')
            ->groupBy('tithes.member_id', DB::raw('MONTH(tithes.contribution_date)'))
            ->get()
            ->groupBy('member_id');

        $rows = $members->map(function (Member $member) use ($payments) {
            $memberPayments = collect($payments->get($member->id, []))->keyBy('month_no');

            $months = collect(range(1, 12))->mapWithKeys(function (int $month) use ($memberPayments) {
                return [$month => (float) ($memberPayments->get($month)->total_amount ?? 0)];
            });

            return [
                'member' => $member,
                'months' => $months,
                'total' => $months->sum(),
            ];
        });

        return [
            'pageTitle' => db_trans('member_monthly_tithe_matrix'),
            'jumuiya' => $jumuiya->load('kanda'),
            'year' => $year,
            'rows' => $rows,
        ];
    }

    protected function topJumuiyas(User $user, int $year, ?int $month, int $limit = 5, array $filters = []): Collection
    {
        $queryFilters = array_filter([
            'year' => $year,
            'month' => $month,
            'status' => $filters['status'] ?? null,
            'payment_method' => $filters['payment_method'] ?? null,
        ]);

        $query = $this->query($user, $queryFilters, false)
            ->leftJoin('jumuiyas', 'jumuiyas.id', '=', 'tithes.jumuiya_id')
            ->selectRaw('COALESCE(jumuiyas.name, ?) as name', [db_trans('unknown')])
            ->selectRaw('SUM(tithes.amount) as total_amount')
            ->groupBy('jumuiyas.name')
            ->orderByDesc(DB::raw('SUM(tithes.amount)'))
            ->limit($limit);

        return $query->get();
    }

    protected function topKandas(User $user, int $year, ?int $month, int $limit = 5, array $filters = []): Collection
    {
        return $this->query($user, array_filter([
            'year' => $year,
            'month' => $month,
            'status' => $filters['status'] ?? null,
            'payment_method' => $filters['payment_method'] ?? null,
        ]), false)
            ->leftJoin('jumuiyas', 'jumuiyas.id', '=', 'tithes.jumuiya_id')
            ->leftJoin('kandas', 'kandas.id', '=', 'jumuiyas.kanda_id')
            ->selectRaw('COALESCE(kandas.name, ?) as name', [db_trans('unknown')])
            ->selectRaw('SUM(tithes.amount) as total_amount')
            ->groupBy('kandas.name')
            ->orderByDesc(DB::raw('SUM(tithes.amount)'))
            ->limit($limit)
            ->get();
    }

    protected function duplicateMonthlyGroups(User $user, array $filters = [])
    {
        $filters = $this->normalizeFilters($user, $filters);

        $year = (int) ($filters['year'] ?? now()->year);
        $month = ! empty($filters['month']) ? (int) $filters['month'] : null;

        return $this->query(
            $user,
            array_filter([
                'year' => $year,
                'month' => $month,
                'jumuiya_id' => $filters['jumuiya_id'] ?? null,
            ]),
            false
        )
            ->leftJoin('members', 'members.id', '=', 'tithes.member_id')
            ->leftJoin('jumuiyas', 'jumuiyas.id', '=', 'tithes.jumuiya_id')
            ->selectRaw('tithes.member_id')
            ->selectRaw('YEAR(tithes.contribution_date) as tithe_year')
            ->selectRaw('MONTH(tithes.contribution_date) as tithe_month')
            ->selectRaw("TRIM(CONCAT(COALESCE(members.first_name, ''), ' ', COALESCE(members.middle_name, ''), ' ', COALESCE(members.last_name, ''))) as member_name")
            ->selectRaw('members.member_code as member_code')
            ->selectRaw('COALESCE(jumuiyas.name, ?) as jumuiya_name', [db_trans('unknown')])
            ->selectRaw('COUNT(tithes.id) as entries_count')
            ->selectRaw('SUM(tithes.amount) as total_amount')
            ->groupBy(
                'tithes.member_id',
                DB::raw('YEAR(tithes.contribution_date)'),
                DB::raw('MONTH(tithes.contribution_date)'),
                'members.first_name',
                'members.middle_name',
                'members.last_name',
                'members.member_code',
                'jumuiyas.name'
            )
            ->havingRaw('COUNT(tithes.id) > 1')
            ->orderByDesc(DB::raw('COUNT(tithes.id)'))
            ->orderByDesc(DB::raw('SUM(tithes.amount)'));
    }

    protected function scopeLabel(User $user): string
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            return db_trans('unknown');
        }

        return match (true) {
            $scope->isKanda() => db_trans('kanda'),
            $scope->isJumuiya() => db_trans('jumuiya'),
            default => db_trans('parish'),
        };
    }

    protected function query(User $user, array $filters = [], bool $selectAll = true): Builder
    {
        $scope = $this->access->scopeForUser($user);
        $query = Tithe::query();

        if ($selectAll) {
            $query->select('tithes.*');
        }

        $query = $this->access->applyScope($query, $scope);

        if (! empty($filters['year'])) {
            $query->whereYear('contribution_date', (int) $filters['year']);
        }

        if (! empty($filters['month'])) {
            $query->whereMonth('contribution_date', (int) $filters['month']);
        }

        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }

        if (! empty($filters['payment_method'])) {
            $query->where('payment_method', $filters['payment_method']);
        }

        if (! empty($filters['jumuiya_id'])) {
            $query->where('jumuiya_id', (int) $filters['jumuiya_id']);
        }

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        return $query;
    }

    protected function ensureCanSeeJumuiya(User $user, Jumuiya $jumuiya): void
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            abort(403);
        }

        if ($scope->isGlobal()) {
            return;
        }

        if ($scope->isKanda() && (int) $jumuiya->kanda_id === (int) $scope->kandaId) {
            return;
        }

        if ($scope->isJumuiya() && (int) $jumuiya->id === (int) $scope->jumuiyaId) {
            return;
        }

        abort(403);
    }

    protected function normalizeFilters(User $user, array $filters): array
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            throw new AuthorizationException($scope->reason ?? 'This account has an invalid scope.');
        }

        $filters['jumuiya_id'] = ! empty($filters['jumuiya_id']) ? (int) $filters['jumuiya_id'] : null;
        $filters['member_id'] = ! empty($filters['member_id']) ? (int) $filters['member_id'] : null;

        if ($scope->isGlobal()) {
            return $filters;
        }

        if ($scope->isKanda()) {
            if ($filters['jumuiya_id']) {
                $jumuiya = Jumuiya::query()->findOrFail($filters['jumuiya_id']);

                if ((int) $jumuiya->kanda_id !== (int) $scope->kandaId) {
                    throw new AuthorizationException('You cannot access another jumuiya tithe scope.');
                }
            }

            return $filters;
        }

        if ($scope->isJumuiya()) {
            if ($filters['jumuiya_id'] && (int) $filters['jumuiya_id'] !== (int) $scope->jumuiyaId) {
                throw new AuthorizationException('You cannot access another jumuiya tithe scope.');
            }

            $filters['jumuiya_id'] = (int) $scope->jumuiyaId;

            return $filters;
        }

        return $filters;
    }
}