<?php

namespace App\Services\Finance;

use App\Models\Message;
use App\Models\MessageBalance;
use App\Models\Member;
use App\Models\User;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class TitheSmsService
{
    public function sendAcknowledgement(Member $member, string $message, User $sender): void
    {
        if (blank($member->phone) || blank($message)) {
            return;
        }

        $phone = '255' . ltrim((string) $member->phone, '0');
        $chars = max(1, (int) ceil(strlen($message) / 160));

        try {
            if (config('app.env') === 'production') {
                $response = Http::withBasicAuth(config('services.bongo.key'), config('services.bongo.secret'))
                    ->withHeaders(['Content-Type' => 'application/json'])
                    ->post('https://apisms.beem.africa/v1/send', [
                        'source_addr' => config('services.bongo.sender'),
                        'encoding' => 0,
                        'schedule_time' => '',
                        'message' => $message,
                        'recipients' => [
                            ['recipient_id' => '1', 'dest_addr' => $phone],
                        ],
                    ]);

                $status = (string) ($response->json('code') ?? $response->status());
            } else {
                $status = 'sandbox';
            }

            Message::create([
                'mtumaji' => $sender->email,
                'mpokeaji' => $phone,
                'ujumbe' => $message,
                'status' => $status,
                'idadi' => $chars,
                'tarehe' => now()->toDateString(),
            ]);

            if (class_exists(MessageBalance::class) && MessageBalance::query()->exists()) {
                MessageBalance::query()->decrement('balance', $chars);
            }
        } catch (\Throwable $e) {
            Log::warning('Tithe SMS acknowledgement failed', [
                'member_id' => $member->id,
                'phone' => $phone,
                'message' => $e->getMessage(),
            ]);
        }
    }
}
