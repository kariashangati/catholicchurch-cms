<?php

namespace App\Services\Finance;

use App\Models\BankAccount;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;

class BankAccountService
{
    public function create(array $data): BankAccount
    {
        return DB::transaction(function () use ($data) {
            return BankAccount::create($this->payload($data));
        });
    }

    public function update(BankAccount $bankAccount, array $data): BankAccount
    {
        return DB::transaction(function () use ($bankAccount, $data) {
            $bankAccount->update($this->payload($data));

            return $bankAccount->fresh();
        });
    }

    public function delete(BankAccount $bankAccount): void
    {
        DB::transaction(function () use ($bankAccount) {
            if ($bankAccount->bankContributions()->exists()) {
                throw new \RuntimeException('This bank account cannot be deleted because contributions are already linked to it.');
            }

            $bankAccount->delete();
        });
    }

    protected function payload(array $data): array
    {
        return Arr::only([
            'bank_name' => trim((string) ($data['bank_name'] ?? '')),
            'account_name' => trim((string) ($data['account_name'] ?? '')),
            'account_number' => preg_replace('/\s+/', '', (string) ($data['account_number'] ?? '')),
            'branch_name' => trim((string) ($data['branch_name'] ?? '')),
            'status' => $data['status'] ?? BankAccount::STATUS_ACTIVE,
            'description' => filled($data['description'] ?? null) ? trim((string) $data['description']) : null,
            'is_active' => (bool) ($data['is_active'] ?? true),
        ], [
            'bank_name',
            'account_name',
            'account_number',
            'branch_name',
            'status',
            'description',
            'is_active',
        ]);
    }
}
