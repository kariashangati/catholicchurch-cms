<?php

namespace App\Services\Jumuiya;

use App\Models\BankContribution;
use App\Models\CashContribution;
use App\Models\Familia;
use App\Models\Jumuiya;
use App\Models\Member;
use App\Models\Offering;
use App\Models\Tithe;
use App\Models\User;
use App\Services\Access\ScopeAccessGate;
use App\Services\Access\UserScopeResolver;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class JumuiyaReportService
{
    public function __construct(
        protected UserScopeResolver $scopeResolver,
        protected ScopeAccessGate $scopeAccessGate,
    ) {
    }

    public function getIndexData(User $user, array $filters = []): array
    {
        $year = (int) ($filters['year'] ?? now()->year);
        $month = ! empty($filters['month']) ? (int) $filters['month'] : null;

        $jumuiyas = $this->scopedJumuiyasQuery($user)
            ->with('kanda')
            ->where('is_active', true)
            ->orderBy('name')
            ->get()
            ->map(fn (Jumuiya $jumuiya) => $this->buildJumuiyaReportRow($jumuiya, $year, $month));

        $topRows = $jumuiyas->sortByDesc('grand_total')->take(5)->values();

        return [
            'pageTitle' => db_trans('jumuiya_financial_reports'),
            'selectedYear' => $year,
            'selectedMonth' => $month,
            'availableYears' => range(now()->year, now()->year - 5),
            'reports' => $jumuiyas,
            'stats' => [
                'total_jumuiyas' => $jumuiyas->count(),
                'total_familias' => $jumuiyas->sum('familias_count'),
                'total_members' => $jumuiyas->sum('members_count'),
                'total_tithes' => $jumuiyas->sum('tithe_total'),
                'total_cash' => $jumuiyas->sum('cash_total'),
                'total_bank' => $jumuiyas->sum('bank_total'),
                'total_offerings' => $jumuiyas->sum('offering_total'),
                'grand_total' => $jumuiyas->sum('grand_total'),
            ],
            'chartData' => [
                'labels' => $jumuiyas->pluck('name')->values(),
                'tithes' => $jumuiyas->pluck('tithe_total')->map(fn ($value) => (float) $value)->values(),
                'cash' => $jumuiyas->pluck('cash_total')->map(fn ($value) => (float) $value)->values(),
                'bank' => $jumuiyas->pluck('bank_total')->map(fn ($value) => (float) $value)->values(),
                'offerings' => $jumuiyas->pluck('offering_total')->map(fn ($value) => (float) $value)->values(),
                'grand_total' => $jumuiyas->pluck('grand_total')->map(fn ($value) => (float) $value)->values(),
            ],
            'topReports' => $topRows,
        ];
    }

    public function getShowData(Jumuiya $jumuiya, User $user, array $filters = []): array
    {
        $this->scopeAccessGate->authorizeJumuiya($user, $jumuiya);

        $year = (int) ($filters['year'] ?? now()->year);

        $jumuiya->load('kanda');

        $summary = $this->buildJumuiyaSummary($jumuiya, $year);
        $monthlyTrends = $this->buildMonthlyTrends($jumuiya, $year);
        $familyBreakdown = $this->buildFamilyBreakdown($jumuiya, $year);
        $bankAccountBreakdown = $this->buildBankAccountBreakdown($jumuiya, $year);
        $contributionTypeBreakdown = $this->buildContributionTypeBreakdown($jumuiya, $year);
        $recentTransactions = $this->getRecentTransactions($jumuiya, $year);
        $recentMembers = $this->getRecentMembers($jumuiya);

        return [
            'pageTitle' => db_trans('jumuiya_financial_report'),
            'jumuiya' => $jumuiya,
            'selectedYear' => $year,
            'availableYears' => range(now()->year, now()->year - 5),
            'stats' => $summary,
            'monthlyTrends' => $monthlyTrends,
            'familyBreakdown' => $familyBreakdown,
            'bankAccountBreakdown' => $bankAccountBreakdown,
            'contributionTypeBreakdown' => $contributionTypeBreakdown,
            'recentTransactions' => $recentTransactions,
            'recentMembers' => $recentMembers,
        ];
    }

    protected function scopedJumuiyasQuery(User $user): Builder
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = Jumuiya::query();

        if ($scope->isInvalid()) {
            return $query->whereRaw('1 = 0');
        }

        if ($scope->isGlobal()) {
            return $query;
        }

        if ($scope->isKanda()) {
            return $query->where('kanda_id', $scope->kandaId);
        }

        if ($scope->isJumuiya()) {
            return $query->whereKey($scope->jumuiyaId);
        }

        return $query->whereRaw('1 = 0');
    }

    protected function buildJumuiyaReportRow(Jumuiya $jumuiya, int $year, ?int $month = null): Jumuiya
    {
        $familiaIds = Familia::where('jumuiya_id', $jumuiya->id)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $titheQuery = Tithe::where('jumuiya_id', $jumuiya->id)
            ->whereYear('contribution_date', $year);

        $cashQuery = CashContribution::whereIn('member_id', $memberIds)
            ->whereYear('contribution_date', $year);

        $bankQuery = BankContribution::where('jumuiya_id', $jumuiya->id)
            ->whereYear('contribution_date', $year);

        $offeringQuery = Offering::where('collection_scope', Offering::SCOPE_JUMUIYA)
            ->where('jumuiya_id', $jumuiya->id)
            ->whereYear('collection_date', $year);

        if ($month) {
            $titheQuery->whereMonth('contribution_date', $month);
            $cashQuery->whereMonth('contribution_date', $month);
            $bankQuery->whereMonth('contribution_date', $month);
            $offeringQuery->whereMonth('collection_date', $month);
        }

        $jumuiya->familias_count = $familiaIds->count();
        $jumuiya->members_count = $memberIds->count();
        $jumuiya->tithe_total = (float) $titheQuery->sum('amount');
        $jumuiya->cash_total = (float) $cashQuery->sum('amount');
        $jumuiya->bank_total = (float) $bankQuery->sum('amount');
        $jumuiya->offering_total = (float) $offeringQuery->sum('amount');
        $jumuiya->grand_total = $jumuiya->tithe_total + $jumuiya->cash_total + $jumuiya->bank_total + $jumuiya->offering_total;

        return $jumuiya;
    }

    protected function buildJumuiyaSummary(Jumuiya $jumuiya, int $year): array
    {
        $row = $this->buildJumuiyaReportRow($jumuiya, $year);

        return [
            'familias_count' => $row->familias_count,
            'members_count' => $row->members_count,
            'tithe_total' => $row->tithe_total,
            'cash_total' => $row->cash_total,
            'bank_total' => $row->bank_total,
            'offering_total' => $row->offering_total,
            'grand_total' => $row->grand_total,
        ];
    }

    protected function buildMonthlyTrends(Jumuiya $jumuiya, int $year): array
    {
        $familiaIds = Familia::where('jumuiya_id', $jumuiya->id)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $labels = [];
        $tithes = [];
        $cash = [];
        $bank = [];
        $offerings = [];

        for ($month = 1; $month <= 12; $month++) {
            $labels[] = Carbon::create()->month($month)->format('M');

            $tithes[] = (float) Tithe::where('jumuiya_id', $jumuiya->id)
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount');

            $cash[] = (float) CashContribution::whereIn('member_id', $memberIds)
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount');

            $bank[] = (float) BankContribution::where('jumuiya_id', $jumuiya->id)
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount');

            $offerings[] = (float) Offering::where('collection_scope', Offering::SCOPE_JUMUIYA)
                ->where('jumuiya_id', $jumuiya->id)
                ->whereYear('collection_date', $year)
                ->whereMonth('collection_date', $month)
                ->sum('amount');
        }

        return [
            'labels' => $labels,
            'tithes' => $tithes,
            'cash' => $cash,
            'bank' => $bank,
            'offerings' => $offerings,
        ];
    }

    protected function buildFamilyBreakdown(Jumuiya $jumuiya, int $year): Collection
    {
        return Familia::where('jumuiya_id', $jumuiya->id)
            ->orderBy('name')
            ->get()
            ->map(function (Familia $familia) use ($year, $jumuiya) {
                $memberIds = Member::where('familia_id', $familia->id)->pluck('id');

                $familia->members_count = $memberIds->count();
                $familia->tithe_total = (float) Tithe::where('jumuiya_id', $jumuiya->id)
                    ->whereIn('member_id', $memberIds)
                    ->whereYear('contribution_date', $year)
                    ->sum('amount');

                $familia->cash_total = (float) CashContribution::whereIn('member_id', $memberIds)
                    ->whereYear('contribution_date', $year)
                    ->sum('amount');

                $familia->bank_total = (float) BankContribution::where('familia_id', $familia->id)
                    ->whereYear('contribution_date', $year)
                    ->sum('amount');

                $familia->offering_total = 0.0;
                $familia->grand_total = $familia->tithe_total + $familia->cash_total + $familia->bank_total;

                return $familia;
            })
            ->sortByDesc('grand_total')
            ->values();
    }

    protected function buildBankAccountBreakdown(Jumuiya $jumuiya, int $year): Collection
    {
        return BankContribution::query()
            ->with('bankAccount')
            ->where('jumuiya_id', $jumuiya->id)
            ->whereYear('contribution_date', $year)
            ->get()
            ->groupBy(fn ($row) => $row->bankAccount?->display_name ?: db_trans('unassigned_bank_account'))
            ->map(function (Collection $group, string $accountName) {
                return (object) [
                    'bank_account' => $accountName,
                    'transactions_count' => $group->count(),
                    'amount' => (float) $group->sum('amount'),
                ];
            })
            ->sortByDesc('amount')
            ->values();
    }

    protected function buildContributionTypeBreakdown(Jumuiya $jumuiya, int $year): Collection
    {
        $familiaIds = Familia::where('jumuiya_id', $jumuiya->id)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $rows = collect();

        CashContribution::query()
            ->with('contributionType')
            ->whereIn('member_id', $memberIds)
            ->whereYear('contribution_date', $year)
            ->get()
            ->groupBy(fn ($item) => $item->contributionType?->name ?: db_trans('cash_contribution'))
            ->each(function (Collection $group, string $name) use ($rows) {
                $rows->push([
                    'type_name' => $name,
                    'cash_total' => (float) $group->sum('amount'),
                    'bank_total' => 0.0,
                ]);
            });

        BankContribution::query()
            ->with('contributionType')
            ->where('jumuiya_id', $jumuiya->id)
            ->whereYear('contribution_date', $year)
            ->get()
            ->groupBy(fn ($item) => $item->contributionType?->name ?: db_trans('bank_contribution'))
            ->each(function (Collection $group, string $name) use ($rows) {
                $existingIndex = $rows->search(fn (array $row) => $row['type_name'] === $name);

                if ($existingIndex !== false) {
                    $row = $rows->get($existingIndex);
                    $row['bank_total'] = (float) $group->sum('amount');
                    $rows->put($existingIndex, $row);

                    return;
                }

                $rows->push([
                    'type_name' => $name,
                    'cash_total' => 0.0,
                    'bank_total' => (float) $group->sum('amount'),
                ]);
            });

        return $rows
            ->map(fn (array $row) => (object) [
                'type_name' => $row['type_name'],
                'cash_total' => $row['cash_total'],
                'bank_total' => $row['bank_total'],
                'grand_total' => $row['cash_total'] + $row['bank_total'],
            ])
            ->sortByDesc('grand_total')
            ->values();
    }

    protected function getRecentTransactions(Jumuiya $jumuiya, int $year): Collection
    {
        $familiaIds = Familia::where('jumuiya_id', $jumuiya->id)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $items = collect();

        Tithe::query()
            ->with(['member.familia'])
            ->where('jumuiya_id', $jumuiya->id)
            ->whereYear('contribution_date', $year)
            ->latest('contribution_date')
            ->take(10)
            ->get()
            ->each(function (Tithe $item) use ($items) {
                $items->push((object) [
                    'source' => db_trans('tithes'),
                    'category' => db_trans('tithe'),
                    'member_name' => $item->member?->full_name ?: '—',
                    'familia_name' => $item->member?->familia?->name ?: '—',
                    'amount' => (float) $item->amount,
                    'date' => $item->contribution_date,
                    'status' => $item->status ?: '—',
                ]);
            });

        CashContribution::query()
            ->with(['member.familia', 'contributionType'])
            ->whereIn('member_id', $memberIds)
            ->whereYear('contribution_date', $year)
            ->latest('contribution_date')
            ->take(10)
            ->get()
            ->each(function (CashContribution $item) use ($items) {
                $items->push((object) [
                    'source' => db_trans('cash_contributions'),
                    'category' => $item->contributionType?->name ?: db_trans('cash_contribution'),
                    'member_name' => $item->member?->full_name ?: '—',
                    'familia_name' => $item->member?->familia?->name ?: '—',
                    'amount' => (float) $item->amount,
                    'date' => $item->contribution_date,
                    'status' => $item->status ?: '—',
                ]);
            });

        BankContribution::query()
            ->with(['member.familia', 'contributionType'])
            ->where('jumuiya_id', $jumuiya->id)
            ->whereYear('contribution_date', $year)
            ->latest('contribution_date')
            ->take(10)
            ->get()
            ->each(function (BankContribution $item) use ($items) {
                $items->push((object) [
                    'source' => db_trans('bank_contributions'),
                    'category' => $item->contributionType?->name ?: db_trans('bank_contribution'),
                    'member_name' => $item->member?->full_name ?: '—',
                    'familia_name' => $item->member?->familia?->name ?: '—',
                    'amount' => (float) $item->amount,
                    'date' => $item->contribution_date,
                    'status' => $item->status ?: '—',
                ]);
            });

        Offering::query()
            ->with(['offeringType'])
            ->where('collection_scope', Offering::SCOPE_JUMUIYA)
            ->where('jumuiya_id', $jumuiya->id)
            ->whereYear('collection_date', $year)
            ->latest('collection_date')
            ->take(10)
            ->get()
            ->each(function (Offering $item) use ($items) {
                $items->push((object) [
                    'source' => db_trans('offerings'),
                    'category' => $item->offeringType?->name ?: db_trans('offering'),
                    'member_name' => db_trans('mass_collection'),
                    'familia_name' => $item->scope_label,
                    'amount' => (float) $item->amount,
                    'date' => $item->collection_date,
                    'status' => $item->status ?: '—',
                ]);
            });

        return $items
            ->sortByDesc(fn ($item) => optional($item->date)?->timestamp ?? 0)
            ->take(12)
            ->values();
    }

    protected function getRecentMembers(Jumuiya $jumuiya): Collection
    {
        $familiaIds = Familia::where('jumuiya_id', $jumuiya->id)->pluck('id');

        return Member::query()
            ->with('familia')
            ->whereIn('familia_id', $familiaIds)
            ->latest()
            ->limit(8)
            ->get();
    }
}