<?php

namespace App\Services\Member;

use App\Models\CashContribution;
use App\Models\Familia;
use App\Models\Member;
use App\Models\Tithe;
use App\Models\User;
use App\Services\Access\ScopeAccessGate;
use App\Services\Access\UserScopeResolver;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class MemberService
{
    public function __construct(
        protected UserScopeResolver $scopeResolver,
        protected ScopeAccessGate $scopeAccessGate,
    ) {
    }

    public function getIndexData(User $user, array $filters = []): array
    {
        $membersQuery = $this->scopedMembersQuery($user);

        if (! empty($filters['status'])) {
            $membersQuery->where('members.is_active', $filters['status'] === 'active');
        }

        if (! empty($filters['family_role'])) {
            $membersQuery->where('members.family_role', $filters['family_role']);
        }

        if (! empty($filters['gender'])) {
            $membersQuery->where('members.gender', $filters['gender']);
        }

        if (! empty($filters['search'])) {
            $search = trim((string) $filters['search']);

            $membersQuery->where(function (Builder $query) use ($search) {
                $query->where('members.first_name', 'like', "%{$search}%")
                    ->orWhere('members.middle_name', 'like', "%{$search}%")
                    ->orWhere('members.last_name', 'like', "%{$search}%")
                    ->orWhere('members.phone', 'like', "%{$search}%")
                    ->orWhere('members.member_code', 'like', "%{$search}%")
                    ->orWhere('familias.name', 'like', "%{$search}%")
                    ->orWhere('jumuiyas.name', 'like', "%{$search}%")
                    ->orWhere('kandas.name', 'like', "%{$search}%");
            });
        }

        $members = (clone $membersQuery)
            ->with(['familia.jumuiya.kanda'])
            ->orderBy('members.first_name')
            ->orderBy('members.last_name')
            ->get();

        $baseStatsQuery = $this->scopedMembersBaseQuery($user);

        $totalMembers = (clone $baseStatsQuery)->count('members.id');

        $stats = [
            'total_members' => $totalMembers,
            'male_members' => (clone $baseStatsQuery)->where('members.gender', 'Male')->count('members.id'),
            'female_members' => (clone $baseStatsQuery)->where('members.gender', 'Female')->count('members.id'),
            'fathers' => (clone $baseStatsQuery)->where('members.family_role', 'Father')->count('members.id'),
            'mothers' => (clone $baseStatsQuery)->where('members.family_role', 'Mother')->count('members.id'),
            'children' => (clone $baseStatsQuery)->where('members.family_role', 'Child')->count('members.id'),
            'active_members' => (clone $baseStatsQuery)->where('members.is_active', true)->count('members.id'),
            'inactive_members' => (clone $baseStatsQuery)->where('members.is_active', false)->count('members.id'),
            'new_members_this_month' => (clone $baseStatsQuery)
                ->whereBetween('members.created_at', [now()->copy()->startOfMonth(), now()->copy()->endOfMonth()])
                ->count('members.id'),
            'members_without_phone' => (clone $baseStatsQuery)
                ->where(function (Builder $query) {
                    $query->whereNull('members.phone')
                        ->orWhere('members.phone', '');
                })
                ->count('members.id'),
            'members_missing_sacrament_data' => (clone $baseStatsQuery)
                ->where(function (Builder $query) {
                    $query->whereNull('members.is_baptized')
                        ->orWhereNull('members.has_communion')
                        ->orWhereNull('members.has_confirmation')
                        ->orWhereNull('members.receives_eucharist')
                        ->orWhereNull('members.is_married');
                })
                ->count('members.id'),
            'baptized_members' => (clone $baseStatsQuery)->where('members.is_baptized', true)->count('members.id'),
            'communion_members' => (clone $baseStatsQuery)->where('members.has_communion', true)->count('members.id'),
            'confirmation_members' => (clone $baseStatsQuery)->where('members.has_confirmation', true)->count('members.id'),
            'eucharist_members' => (clone $baseStatsQuery)->where('members.receives_eucharist', true)->count('members.id'),
            'married_members' => (clone $baseStatsQuery)->where('members.is_married', true)->count('members.id'),
        ];

        $rangeStart = now()->copy()->startOfMonth()->subMonths(5);
        $rangeEnd = now()->copy()->endOfMonth();

        $monthlyGrowth = $this->scopedMembersBaseQuery($user)
            ->selectRaw("DATE_FORMAT(members.created_at, '%b %Y') as label")
            ->selectRaw("DATE_FORMAT(members.created_at, '%Y-%m') as month_key")
            ->selectRaw('COUNT(members.id) as total')
            ->whereBetween('members.created_at', [$rangeStart, $rangeEnd])
            ->groupBy('month_key', 'label')
            ->orderBy('month_key')
            ->get();

        $chartLabels = collect(range(5, 0))
            ->map(fn ($monthsAgo) => now()->copy()->subMonths($monthsAgo)->format('M Y'))
            ->push(now()->format('M Y'))
            ->values();

        $growthMap = $monthlyGrowth->pluck('total', 'label');

        $chartData = $chartLabels
            ->map(fn ($label) => (int) ($growthMap[$label] ?? 0))
            ->values();

        return [
            'pageTitle' => db_trans('members'),
            'members' => $members,
            'familias' => $this->availableFamiliasForUser($user, $filters),
            'filters' => $filters,
            'stats' => $stats,
            'familyRoles' => ['Father', 'Mother', 'Child', 'Other'],
            'genders' => ['Male', 'Female'],
            'memberGrowthChart' => [
                'labels' => $chartLabels,
                'data' => $chartData,
            ],
            'sacramentOverview' => [
                ['key' => 'baptized_members', 'label' => db_trans('baptized'), 'value' => $stats['baptized_members']],
                ['key' => 'communion_members', 'label' => db_trans('communion'), 'value' => $stats['communion_members']],
                ['key' => 'confirmation_members', 'label' => db_trans('confirmation'), 'value' => $stats['confirmation_members']],
                ['key' => 'eucharist_members', 'label' => db_trans('eucharist'), 'value' => $stats['eucharist_members']],
                ['key' => 'married_members', 'label' => db_trans('married'), 'value' => $stats['married_members']],
            ],
        ];
    }

    public function getCreateData(User $user, array $filters = []): array
    {
        return [
            'pageTitle' => db_trans('add_member'),
            'familias' => $this->availableFamiliasForUser($user, $filters),
        ];
    }

    public function getEditData(Member $member, User $user): array
    {
        $this->scopeAccessGate->authorizeMember($user, $member);

        return [
            'pageTitle' => db_trans('edit_member'),
            'member' => $member->load('familia.jumuiya.kanda'),
            'familias' => $this->availableFamiliasForUser($user),
        ];
    }

    public function getShowData(Member $member, User $user): array
    {
        $this->scopeAccessGate->authorizeMember($user, $member);

        $member->load('familia.jumuiya.kanda');

        $currentYear = now()->year;
        $previousYear = now()->copy()->subYear()->year;

        $zakaCurrent = Tithe::where('member_id', $member->id)
            ->whereYear('contribution_date', $currentYear)
            ->sum('amount');

        $zakaPrevious = Tithe::where('member_id', $member->id)
            ->whereYear('contribution_date', $previousYear)
            ->sum('amount');

        $mavunoCurrent = CashContribution::where('member_id', $member->id)
            ->whereYear('contribution_date', $currentYear)
            ->whereHas('contributionType', fn ($q) => $q->where('slug', 'mavuno'))
            ->sum('amount');

        $mavunoPrevious = CashContribution::where('member_id', $member->id)
            ->whereYear('contribution_date', $previousYear)
            ->whereHas('contributionType', fn ($q) => $q->where('slug', 'mavuno'))
            ->sum('amount');

        $otherCurrent = CashContribution::where('member_id', $member->id)
            ->whereYear('contribution_date', $currentYear)
            ->whereHas('contributionType', fn ($q) => $q->where('slug', '!=', 'mavuno'))
            ->sum('amount');

        $otherPrevious = CashContribution::where('member_id', $member->id)
            ->whereYear('contribution_date', $previousYear)
            ->whereHas('contributionType', fn ($q) => $q->where('slug', '!=', 'mavuno'))
            ->sum('amount');

        return [
            'pageTitle' => db_trans('member_details'),
            'member' => $member,
            'currentYear' => $currentYear,
            'previousYear' => $previousYear,
            'finance' => [
                'zaka_current' => $zakaCurrent,
                'zaka_previous' => $zakaPrevious,
                'mavuno_current' => $mavunoCurrent,
                'mavuno_previous' => $mavunoPrevious,
                'other_current' => $otherCurrent,
                'other_previous' => $otherPrevious,
                'total_current' => $zakaCurrent + $mavunoCurrent + $otherCurrent,
                'total_previous' => $zakaPrevious + $mavunoPrevious + $otherPrevious,
            ],
        ];
    }

    public function store(array $data, User $user): Member
    {
        $familia = Familia::findOrFail($data['familia_id']);
        $this->scopeAccessGate->authorizeFamilia($user, $familia);

        $data['member_code'] = $data['member_code'] ?? $this->generateMemberCode($familia);

        return Member::create($data);
    }

    public function update(Member $member, array $data, User $user): Member
    {
        $this->scopeAccessGate->authorizeMember($user, $member);

        if (! empty($data['familia_id'])) {
            $familia = Familia::findOrFail($data['familia_id']);
            $this->scopeAccessGate->authorizeFamilia($user, $familia);
        }

        $member->update($data);

        return $member->refresh();
    }

    public function delete(Member $member, User $user): bool
    {
        $this->scopeAccessGate->authorizeMember($user, $member);

        return (bool) $member->delete();
    }

    protected function scopedMembersQuery(User $user): Builder
    {
        return $this->scopedMembersBaseQuery($user)->select('members.*');
    }

    protected function scopedMembersBaseQuery(User $user): Builder
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = Member::query()
            ->leftJoin('familias', 'familias.id', '=', 'members.familia_id')
            ->leftJoin('jumuiyas', 'jumuiyas.id', '=', 'familias.jumuiya_id')
            ->leftJoin('kandas', 'kandas.id', '=', 'jumuiyas.kanda_id');

        if ($scope->isInvalid()) {
            return $query->whereRaw('1 = 0');
        }

        if ($scope->isGlobal()) {
            return $query;
        }

        if ($scope->isKanda()) {
            return $query->where('jumuiyas.kanda_id', $scope->kandaId);
        }

        if ($scope->isJumuiya()) {
            return $query->where('familias.jumuiya_id', $scope->jumuiyaId);
        }

        return $query->whereRaw('1 = 0');
    }

    protected function availableFamiliasForUser(User $user, array $filters = []): Collection
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = Familia::query()
            ->with('jumuiya.kanda')
            ->orderBy('name');

        if (! empty($filters['jumuiya_id'])) {
            $query->where('jumuiya_id', $filters['jumuiya_id']);
        }

        if ($scope->isInvalid()) {
            return collect();
        }

        if ($scope->isGlobal()) {
            return $query->get();
        }

        if ($scope->isKanda()) {
            return $query->whereHas('jumuiya', function ($q) use ($scope) {
                $q->where('kanda_id', $scope->kandaId);
            })->get();
        }

        if ($scope->isJumuiya()) {
            return $query->where('jumuiya_id', $scope->jumuiyaId)->get();
        }

        return collect();
    }

    protected function generateMemberCode(Familia $familia): string
    {
        $familia->loadMissing('jumuiya.kanda');
        $prefix = optional($familia->jumuiya?->kanda)->code ?: 'MBR';
        $latestId = (Member::max('id') ?? 0) + 1;

        return strtoupper($prefix) . str_pad((string) $latestId, 5, '0', STR_PAD_LEFT);
    }
}