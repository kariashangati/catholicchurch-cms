<?php

namespace App\Services\Mafundisho;

use App\Models\MafundishoEnrollment;
use App\Models\Member;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class MafundishoEnrollmentService
{
    public function getSummaryData(User $user): array
    {
        $baseEnrollments = $this->scopedEnrollmentQuery($user);
        $baseMembers = $this->scopedEligibleMembersBaseQuery($user);

        $summaryByType = collect(MafundishoEnrollment::availableTypes())
            ->map(function (string $type) use ($baseEnrollments, $user): array {
                $typedQuery = (clone $baseEnrollments)
                    ->where('mafundisho_enrollments.type', $type);

                $eligibleCount = $this->eligibleMembersForType($user, $type)
                    ->count('members.id');

                $completed = (clone $typedQuery)
                    ->where('mafundisho_enrollments.status', MafundishoEnrollment::STATUS_COMPLETED)
                    ->count('mafundisho_enrollments.id');

                $total = (clone $typedQuery)->count('mafundisho_enrollments.id');

                return [
                    'type' => $type,
                    'label' => $this->labelForType($type),
                    'total' => $total,
                    'active' => (clone $typedQuery)
                        ->where('mafundisho_enrollments.status', MafundishoEnrollment::STATUS_ACTIVE)
                        ->count('mafundisho_enrollments.id'),
                    'completed' => $completed,
                    'withdrawn' => (clone $typedQuery)
                        ->where('mafundisho_enrollments.status', MafundishoEnrollment::STATUS_WITHDRAWN)
                        ->count('mafundisho_enrollments.id'),
                    'eligible' => $eligibleCount,
                    'completion_rate' => $total > 0 ? (int) round(($completed / $total) * 100) : 0,
                ];
            })
            ->values();

        $chartRows = (clone $baseEnrollments)
            ->toBase()
            ->selectRaw('mafundisho_enrollments.year, COUNT(*) as total')
            ->groupBy('mafundisho_enrollments.year')
            ->orderBy('mafundisho_enrollments.year')
            ->get();

        $statusChartRows = (clone $baseEnrollments)
            ->toBase()
            ->selectRaw('mafundisho_enrollments.status, COUNT(*) as total')
            ->groupBy('mafundisho_enrollments.status')
            ->pluck('total', 'status');

        $recentEnrollments = (clone $baseEnrollments)
            ->select('mafundisho_enrollments.*')
            ->with([
                'member:id,first_name,middle_name,last_name,member_code,phone,gender,familia_id',
                'member.familia:id,name,jumuiya_id',
                'member.familia.jumuiya:id,name,kanda_id',
            ])
            ->latest('mafundisho_enrollments.created_at')
            ->take(10)
            ->get();

        $currentYear = (int) now()->year;
        $thisYearEnrollments = (clone $baseEnrollments)
            ->where('mafundisho_enrollments.year', $currentYear)
            ->count('mafundisho_enrollments.id');

        return [
            'stats' => [
                'total_students' => (clone $baseEnrollments)->count('mafundisho_enrollments.id'),
                'active_students' => (clone $baseEnrollments)
                    ->where('mafundisho_enrollments.status', MafundishoEnrollment::STATUS_ACTIVE)
                    ->count('mafundisho_enrollments.id'),
                'completed_students' => (clone $baseEnrollments)
                    ->where('mafundisho_enrollments.status', MafundishoEnrollment::STATUS_COMPLETED)
                    ->count('mafundisho_enrollments.id'),
                'withdrawn_students' => (clone $baseEnrollments)
                    ->where('mafundisho_enrollments.status', MafundishoEnrollment::STATUS_WITHDRAWN)
                    ->count('mafundisho_enrollments.id'),
                'eligible_members' => (clone $baseMembers)->count('members.id'),
                'this_year_enrollments' => $thisYearEnrollments,
            ],
            'summaryByType' => $summaryByType,
            'recentEnrollments' => $recentEnrollments,
            'chart' => [
                'labels' => $chartRows->pluck('year')->map(fn ($year) => (string) $year)->values()->all(),
                'data' => $chartRows->pluck('total')->map(fn ($total) => (int) $total)->values()->all(),
            ],
            'statusChart' => [
                'labels' => [db_trans('active'), db_trans('completed'), db_trans('withdrawn')],
                'data' => [
                    (int) ($statusChartRows[MafundishoEnrollment::STATUS_ACTIVE] ?? 0),
                    (int) ($statusChartRows[MafundishoEnrollment::STATUS_COMPLETED] ?? 0),
                    (int) ($statusChartRows[MafundishoEnrollment::STATUS_WITHDRAWN] ?? 0),
                ],
            ],
        ];
    }

    public function getTypeIndexData(User $user, string $type, ?int $year = null, ?string $status = null): array
    {
        $this->ensureValidType($type);
        $this->ensureValidStatus($status);

        $availableYears = $this->availableYears($user, $type);

        if ($year === null) {
            $year = $availableYears->first() ?: (int) now()->year;
        }

        $baseTypeQuery = $this->scopedEnrollmentQuery($user)
            ->where('mafundisho_enrollments.type', $type)
            ->where('mafundisho_enrollments.year', $year);

        $enrollments = (clone $baseTypeQuery)
            ->when($status, fn (Builder $query) => $query->where('mafundisho_enrollments.status', $status))
            ->select('mafundisho_enrollments.*')
            ->with([
                'member:id,first_name,middle_name,last_name,member_code,phone,gender,familia_id',
                'member.familia:id,name,jumuiya_id',
                'member.familia.jumuiya:id,name,kanda_id',
                'member.familia.jumuiya.kanda:id,name',
            ])
            ->latest('mafundisho_enrollments.created_at')
            ->get();

        $members = $this->eligibleMembersForType($user, $type)
            ->select([
                'members.id',
                'members.first_name',
                'members.middle_name',
                'members.last_name',
                'members.member_code',
                'members.phone',
                'members.gender',
                'members.familia_id',
            ])
            ->with([
                'familia:id,name,jumuiya_id',
                'familia.jumuiya:id,name,kanda_id',
            ])
            ->orderBy('members.first_name')
            ->orderBy('members.last_name')
            ->get();

        $statusCounts = [
            MafundishoEnrollment::STATUS_ACTIVE => (clone $baseTypeQuery)
                ->where('mafundisho_enrollments.status', MafundishoEnrollment::STATUS_ACTIVE)
                ->count('mafundisho_enrollments.id'),
            MafundishoEnrollment::STATUS_COMPLETED => (clone $baseTypeQuery)
                ->where('mafundisho_enrollments.status', MafundishoEnrollment::STATUS_COMPLETED)
                ->count('mafundisho_enrollments.id'),
            MafundishoEnrollment::STATUS_WITHDRAWN => (clone $baseTypeQuery)
                ->where('mafundisho_enrollments.status', MafundishoEnrollment::STATUS_WITHDRAWN)
                ->count('mafundisho_enrollments.id'),
        ];

        $stats = [
            'total' => (clone $baseTypeQuery)->count('mafundisho_enrollments.id'),
            'active' => $statusCounts[MafundishoEnrollment::STATUS_ACTIVE] ?? 0,
            'completed' => $statusCounts[MafundishoEnrollment::STATUS_COMPLETED] ?? 0,
            'withdrawn' => $statusCounts[MafundishoEnrollment::STATUS_WITHDRAWN] ?? 0,
            'eligible' => $members->count(),
            'eligible_not_enrolled' => max($members->count() - ((clone $baseTypeQuery)->distinct('mafundisho_enrollments.member_id')->count('mafundisho_enrollments.member_id')), 0),
        ];

        $monthlyRows = (clone $baseTypeQuery)
            ->toBase()
            ->selectRaw('MONTH(COALESCE(mafundisho_enrollments.started_at, mafundisho_enrollments.created_at)) as month_no, COUNT(*) as total')
            ->groupBy('month_no')
            ->orderBy('month_no')
            ->get();

        return [
            'type' => $type,
            'typeLabel' => $this->labelForType($type),
            'year' => $year,
            'status' => $status,
            'enrollments' => $enrollments,
            'members' => $members,
            'availableYears' => $availableYears,
            'statusCounts' => $statusCounts,
            'stats' => $stats,
            'statusChart' => [
                'labels' => [db_trans('active'), db_trans('completed'), db_trans('withdrawn')],
                'data' => [
                    (int) ($statusCounts[MafundishoEnrollment::STATUS_ACTIVE] ?? 0),
                    (int) ($statusCounts[MafundishoEnrollment::STATUS_COMPLETED] ?? 0),
                    (int) ($statusCounts[MafundishoEnrollment::STATUS_WITHDRAWN] ?? 0),
                ],
            ],
            'monthlyChart' => [
                'labels' => $monthlyRows->pluck('month_no')->map(function ($month) {
                    return $month ? now()->startOfYear()->month((int) $month)->format('M') : db_trans('unknown');
                })->values()->all(),
                'data' => $monthlyRows->pluck('total')->map(fn ($total) => (int) $total)->values()->all(),
            ],
        ];
    }

    public function getShowData(User $user, MafundishoEnrollment $enrollment): array
    {
        $this->authorizeEnrollmentAccess($user, $enrollment);

        $enrollment->load([
            'member:id,first_name,middle_name,last_name,member_code,gender,phone,email,date_of_birth,familia_id',
            'member.familia:id,name,jumuiya_id',
            'member.familia.jumuiya:id,name,kanda_id',
            'member.familia.jumuiya.kanda:id,name',
        ]);

        return [
            'enrollment' => $enrollment,
            'typeLabel' => $this->labelForType($enrollment->type),
        ];
    }

    public function store(array $validated, User $user): void
    {
        $type = $validated['type'];
        $year = (int) ($validated['year'] ?? now()->year);
        $status = $validated['status'];

        $memberIds = collect($validated['member_ids'] ?? $validated['members'] ?? [])
            ->filter()
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values();

        if ($memberIds->isEmpty()) {
            throw ValidationException::withMessages([
                'member_ids' => db_trans('validation_member_required'),
            ]);
        }

        $eligibleMembers = $this->eligibleMembersForType($user, $type)
            ->whereIn('members.id', $memberIds)
            ->get()
            ->keyBy('id');

        if ($eligibleMembers->count() !== $memberIds->count()) {
            throw ValidationException::withMessages([
                'member_ids' => db_trans('validation_member_invalid'),
            ]);
        }

        DB::transaction(function () use ($validated, $memberIds, $eligibleMembers, $type, $year, $status): void {
            foreach ($memberIds as $memberId) {
                $member = $eligibleMembers->get($memberId);

                $enrollment = MafundishoEnrollment::updateOrCreate(
                    [
                        'member_id' => $member->id,
                        'type' => $type,
                        'year' => $year,
                    ],
                    [
                        'status' => $status,
                        'started_at' => $validated['started_at'] ?? null,
                        'ended_at' => $validated['ended_at'] ?? null,
                        'notes' => $validated['notes'] ?? null,
                        'partner_name' => $validated['partner_name'] ?? null,
                        'partner_jumuiya' => $validated['partner_jumuiya'] ?? null,
                        'partner_phone' => $validated['partner_phone'] ?? null,
                    ]
                );

                $this->syncMemberSacramentStatus($member, $type, $enrollment->status);
            }
        });
    }

    public function update(MafundishoEnrollment $enrollment, array $validated, User $user): void
    {
        $this->authorizeEnrollmentAccess($user, $enrollment);

        $type = $validated['type'];
        $status = $validated['status'];

        DB::transaction(function () use ($enrollment, $validated, $type, $status): void {
            $enrollment->update([
                'member_id' => (int) $validated['member_id'],
                'year' => (int) ($validated['year'] ?? now()->year),
                'type' => $type,
                'status' => $status,
                'started_at' => $validated['started_at'] ?? null,
                'ended_at' => $validated['ended_at'] ?? null,
                'notes' => $validated['notes'] ?? null,
                'partner_name' => $validated['partner_name'] ?? null,
                'partner_jumuiya' => $validated['partner_jumuiya'] ?? null,
                'partner_phone' => $validated['partner_phone'] ?? null,
            ]);

            $member = Member::findOrFail($enrollment->member_id);
            $this->syncMemberSacramentStatus($member, $type, $status);
        });
    }

    public function delete(MafundishoEnrollment $enrollment, User $user): void
    {
        $this->authorizeEnrollmentAccess($user, $enrollment);

        DB::transaction(function () use ($enrollment): void {
            $member = Member::findOrFail($enrollment->member_id);
            $type = $enrollment->type;

            $enrollment->delete();

            $latestRelevantEnrollment = MafundishoEnrollment::query()
                ->where('member_id', $member->id)
                ->where('type', $type)
                ->latest('year')
                ->latest('id')
                ->first();

            if ($latestRelevantEnrollment) {
                $this->syncMemberSacramentStatus($member, $type, $latestRelevantEnrollment->status);
            } else {
                $this->resetMemberSacramentStatus($member, $type);
            }
        });
    }

    public function availableYears(User $user, ?string $type = null): Collection
    {
        return $this->scopedEnrollmentQuery($user)
            ->when($type, fn (Builder $query) => $query->where('mafundisho_enrollments.type', $type))
            ->toBase()
            ->select('mafundisho_enrollments.year')
            ->distinct()
            ->orderByDesc('mafundisho_enrollments.year')
            ->pluck('year')
            ->map(fn ($year) => (int) $year)
            ->values();
    }

    protected function scopedEnrollmentQuery(User $user): Builder
    {
        $query = MafundishoEnrollment::query()
            ->leftJoin('members', 'members.id', '=', 'mafundisho_enrollments.member_id')
            ->leftJoin('familias', 'familias.id', '=', 'members.familia_id')
            ->leftJoin('jumuiyas', 'jumuiyas.id', '=', 'familias.jumuiya_id');

        if ($user->can('mafundisho.view-all')) {
            return $query;
        }

        if (!empty($user->jumuiya_id)) {
            return $query->where('jumuiyas.id', $user->jumuiya_id);
        }

        if (!empty($user->kanda_id)) {
            return $query->where('jumuiyas.kanda_id', $user->kanda_id);
        }

        return $query->whereRaw('1 = 0');
    }

    protected function scopedEligibleMembersBaseQuery(User $user): Builder
    {
        $query = Member::query()
            ->select('members.*')
            ->leftJoin('familias', 'familias.id', '=', 'members.familia_id')
            ->leftJoin('jumuiyas', 'jumuiyas.id', '=', 'familias.jumuiya_id');

        if ($user->can('mafundisho.view-all')) {
            return $query;
        }

        if (!empty($user->jumuiya_id)) {
            return $query->where('jumuiyas.id', $user->jumuiya_id);
        }

        if (!empty($user->kanda_id)) {
            return $query->where('jumuiyas.kanda_id', $user->kanda_id);
        }

        return $query->whereRaw('1 = 0');
    }

    protected function eligibleMembersForType(User $user, string $type): Builder
    {
        $this->ensureValidType($type);

        $query = $this->scopedEligibleMembersBaseQuery($user);

        return match ($type) {
            MafundishoEnrollment::TYPE_KOMUNIO => $query->where(function (Builder $builder): void {
                $builder->whereNull('members.has_communion')
                    ->orWhere('members.has_communion', false)
                    ->orWhere('members.has_communion', 0);
            }),
            MafundishoEnrollment::TYPE_KIPAIMARA => $query->where(function (Builder $builder): void {
                $builder->whereNull('members.has_confirmation')
                    ->orWhere('members.has_confirmation', false)
                    ->orWhere('members.has_confirmation', 0);
            }),
            MafundishoEnrollment::TYPE_NDOA => $query->where(function (Builder $builder): void {
                $builder->whereNull('members.is_married')
                    ->orWhere('members.is_married', false)
                    ->orWhere('members.is_married', 0);
            }),
            default => $query->whereRaw('1 = 0'),
        };
    }

    protected function syncMemberSacramentStatus(Member $member, string $type, string $status): void
    {
        $column = match ($type) {
            MafundishoEnrollment::TYPE_KOMUNIO => 'has_communion',
            MafundishoEnrollment::TYPE_KIPAIMARA => 'has_confirmation',
            MafundishoEnrollment::TYPE_NDOA => 'is_married',
            default => null,
        };

        if (!$column) {
            return;
        }

        $value = $status === MafundishoEnrollment::STATUS_COMPLETED;

        $member->forceFill([$column => $value])->save();
    }

    protected function resetMemberSacramentStatus(Member $member, string $type): void
    {
        $column = match ($type) {
            MafundishoEnrollment::TYPE_KOMUNIO => 'has_communion',
            MafundishoEnrollment::TYPE_KIPAIMARA => 'has_confirmation',
            MafundishoEnrollment::TYPE_NDOA => 'is_married',
            default => null,
        };

        if (!$column) {
            return;
        }

        $member->forceFill([$column => false])->save();
    }

    protected function authorizeEnrollmentAccess(User $user, MafundishoEnrollment $enrollment): void
    {
        $exists = $this->scopedEnrollmentQuery($user)
            ->where('mafundisho_enrollments.id', $enrollment->id)
            ->exists();

        if (!$exists) {
            abort(403);
        }
    }

    protected function ensureValidType(string $type): void
    {
        if (!in_array($type, MafundishoEnrollment::availableTypes(), true)) {
            throw ValidationException::withMessages([
                'type' => db_trans('validation_invalid_selection'),
            ]);
        }
    }

    protected function ensureValidStatus(?string $status): void
    {
        if ($status === null || $status === '') {
            return;
        }

        if (!in_array($status, MafundishoEnrollment::availableStatuses(), true)) {
            throw ValidationException::withMessages([
                'status' => db_trans('validation_invalid_selection'),
            ]);
        }
    }

    protected function labelForType(string $type): string
    {
        return match ($type) {
            MafundishoEnrollment::TYPE_KOMUNIO => db_trans('communion'),
            MafundishoEnrollment::TYPE_KIPAIMARA => db_trans('confirmation'),
            MafundishoEnrollment::TYPE_NDOA => db_trans('married'),
            default => ucfirst($type),
        };
    }
}
