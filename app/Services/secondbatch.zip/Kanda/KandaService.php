<?php

namespace App\Services\Kanda;

use App\Models\BankContribution;
use App\Models\CashContribution;
use App\Models\Familia;
use App\Models\Jumuiya;
use App\Models\Kanda;
use App\Models\Member;
use App\Models\Offering;
use App\Models\Tithe;
use App\Models\User;
use App\Services\Access\ScopeAccessGate;
use App\Services\Access\UserScopeResolver;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

class KandaService
{
    public function __construct(
        protected UserScopeResolver $scopeResolver,
        protected ScopeAccessGate $scopeAccessGate,
    ) {
    }

    public function getIndexData(User $user): array
    {
        $kandas = $this->scopedKandasQuery($user)
            ->withCount('jumuiyas')
            ->latest()
            ->get()
            ->map(function (Kanda $kanda) {
                $summary = $this->buildKandaSummary($kanda);

                $kanda->familias_count = $summary['familias_count'];
                $kanda->members_count = $summary['members_count'];
                $kanda->male_members_count = $summary['male_members_count'];
                $kanda->female_members_count = $summary['female_members_count'];
                $kanda->tithe_total = $summary['tithe_total'];
                $kanda->mavuno_total = $summary['mavuno_total'];
                $kanda->cash_total = $summary['cash_total'];
                $kanda->bank_total = $summary['bank_total'];
                $kanda->offering_total = $summary['offering_total'];
                $kanda->grand_total = $summary['grand_total'];

                return $kanda;
            });

        $stats = [
            'total_kandas' => $kandas->count(),
            'active_kandas' => $kandas->where('is_active', true)->count(),
            'total_jumuiyas' => $kandas->sum('jumuiyas_count'),
            'total_familias' => $kandas->sum('familias_count'),
            'total_members' => $kandas->sum('members_count'),
            'male_members' => $kandas->sum('male_members_count'),
            'female_members' => $kandas->sum('female_members_count'),
            'total_tithes' => (float) $kandas->sum('tithe_total'),
            'total_mavuno' => (float) $kandas->sum('mavuno_total'),
            'total_cash_contributions' => (float) $kandas->sum('cash_total'),
            'total_bank_contributions' => (float) $kandas->sum('bank_total'),
            'total_offerings' => (float) $kandas->sum('offering_total'),
            'grand_total' => (float) $kandas->sum('grand_total'),
        ];

        return [
            'pageTitle' => db_trans('kandas'),
            'hero' => $this->getHero($user, $stats),
            'stats' => $stats,
            'summaryCards' => $this->getSummaryCards($stats),
            'financeCards' => $this->getFinanceCards($stats),
            'quickLinks' => $this->getQuickLinks($user),
            'chartData' => [
                'labels' => $kandas->pluck('name')->values(),
                'members' => $kandas->pluck('members_count')->map(fn ($v) => (int) $v)->values(),
                'jumuiyas' => $kandas->pluck('jumuiyas_count')->map(fn ($v) => (int) $v)->values(),
                'familias' => $kandas->pluck('familias_count')->map(fn ($v) => (int) $v)->values(),
            ],
            'financeByKandaChart' => [
                'labels' => $kandas->pluck('name')->values(),
                'tithes' => $kandas->pluck('tithe_total')->map(fn ($v) => (float) $v)->values(),
                'offerings' => $kandas->pluck('offering_total')->map(fn ($v) => (float) $v)->values(),
                'cash' => $kandas->pluck('cash_total')->map(fn ($v) => (float) $v)->values(),
                'bank' => $kandas->pluck('bank_total')->map(fn ($v) => (float) $v)->values(),
            ],
            'monthlyFinanceChart' => $this->getMonthlyFinanceChartForVisibleKandas($kandas),
            'financeMixChart' => [
                'labels' => [
                    db_trans('tithes'),
                    db_trans('offerings'),
                    db_trans('cash_contributions'),
                    db_trans('bank_contributions'),
                ],
                'values' => [
                    (float) $stats['total_tithes'],
                    (float) $stats['total_offerings'],
                    (float) $stats['total_cash_contributions'],
                    (float) $stats['total_bank_contributions'],
                ],
            ],
            'kandas' => $kandas,
            'kandaBreakdown' => $this->buildKandaBreakdown($kandas),
            'liveFeed' => $this->getLiveFeedForVisibleKandas($kandas),
            'alerts' => $this->getAlertsForVisibleKandas($kandas),
        ];
    }

    public function store(array $data): Kanda
    {
        return Kanda::create([
            'name' => Str::upper(trim($data['name'])),
            'code' => Str::upper(trim($data['code'])),
            'slug' => Str::slug($data['name']),
            'comment' => $data['comment'] ?? null,
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);
    }

    public function update(Kanda $kanda, array $data): Kanda
    {
        $kanda->update([
            'name' => Str::upper(trim($data['name'])),
            'code' => Str::upper(trim($data['code'])),
            'slug' => Str::slug($data['name']),
            'comment' => $data['comment'] ?? null,
            'is_active' => (bool) ($data['is_active'] ?? true),
        ]);

        return $kanda->refresh();
    }

    public function delete(Kanda $kanda): bool
    {
        return (bool) $kanda->delete();
    }

    public function getShowData(Kanda $kanda, User $user): array
    {
        $this->scopeAccessGate->authorizeKanda($user, $kanda);

        $summary = $this->buildKandaSummary($kanda);
        $jumuiyas = $this->buildJumuiyaBreakdown($kanda);
        $monthlyChart = $this->getMonthlyFinanceChart($kanda);
        $recentMembers = $this->getRecentMembers($kanda);

        return [
            'pageTitle' => db_trans('kanda_details'),
            'kanda' => $kanda,
            'hero' => [
                'eyebrow' => db_trans('kanda_details'),
                'title' => $kanda->name,
                'subtitle' => db_trans('code') . ': ' . $kanda->code . ' · ' . ($kanda->is_active ? db_trans('active') : db_trans('inactive')),
                'scope_badge' => db_trans('kanda_scope'),
                'today' => now()->translatedFormat('l, d M Y'),
            ],
            'stats' => $summary,
            'summaryCards' => [
                [
                    'title' => db_trans('jumuiyas'),
                    'value' => number_format($summary['jumuiyas_count']),
                    'meta' => db_trans('communities_under_kanda'),
                    'icon' => 'fas fa-layer-group',
                    'tone' => 'primary',
                ],
                [
                    'title' => db_trans('familias'),
                    'value' => number_format($summary['familias_count']),
                    'meta' => db_trans('familias_under_pastoral_care'),
                    'icon' => 'fas fa-home',
                    'tone' => 'info',
                ],
                [
                    'title' => db_trans('members'),
                    'value' => number_format($summary['members_count']),
                    'meta' => db_trans('registered_members_in_scope'),
                    'icon' => 'fas fa-users',
                    'tone' => 'success',
                ],
                [
                    'title' => db_trans('grand_total'),
                    'value' => number_format($summary['grand_total'], 2),
                    'meta' => db_trans('all_major_income_streams_combined'),
                    'icon' => 'fas fa-chart-line',
                    'tone' => 'dark',
                ],
            ],
            'financeCards' => [
                [
                    'title' => db_trans('total_tithes'),
                    'value' => number_format($summary['tithe_total'], 2),
                    'meta' => db_trans('tithe_collections_in_scope'),
                    'icon' => 'fas fa-coins',
                    'tone' => 'success',
                ],
                [
                    'title' => db_trans('total_offerings'),
                    'value' => number_format($summary['offering_total'], 2),
                    'meta' => db_trans('offerings_recorded_in_scope'),
                    'icon' => 'fas fa-hand-holding-heart',
                    'tone' => 'primary',
                ],
                [
                    'title' => db_trans('total_cash_contributions'),
                    'value' => number_format($summary['cash_total'], 2),
                    'meta' => db_trans('cash_contributions_recorded'),
                    'icon' => 'fas fa-wallet',
                    'tone' => 'warning',
                ],
                [
                    'title' => db_trans('total_bank_contributions'),
                    'value' => number_format($summary['bank_total'], 2),
                    'meta' => db_trans('bank_contributions_recorded'),
                    'icon' => 'fas fa-university',
                    'tone' => 'info',
                ],
                [
                    'title' => db_trans('total_mavuno'),
                    'value' => number_format($summary['mavuno_total'], 2),
                    'meta' => db_trans('mavuno_contributions_in_scope'),
                    'icon' => 'fas fa-seedling',
                    'tone' => 'secondary',
                ],
                [
                    'title' => db_trans('male_members'),
                    'value' => number_format($summary['male_members_count']),
                    'meta' => db_trans('gender_distribution'),
                    'icon' => 'fas fa-male',
                    'tone' => 'dark',
                ],
                [
                    'title' => db_trans('female_members'),
                    'value' => number_format($summary['female_members_count']),
                    'meta' => db_trans('gender_distribution'),
                    'icon' => 'fas fa-female',
                    'tone' => 'warning',
                ],
            ],
            'jumuiyas' => $jumuiyas,
            'monthlyChart' => $monthlyChart,
            'recentMembers' => $recentMembers,
        ];
    }

    protected function getHero(User $user, array $stats): array
    {
        return [
            'eyebrow' => db_trans('kanda_analytics'),
            'title' => db_trans('kanda_dashboard_title'),
            'subtitle' => db_trans('kanda_dashboard_subtitle'),
            'scope_label' => $this->resolveScopeLabel($user),
            'pending_items' => $this->getPendingItemCountForUser($user),
            'today' => now()->translatedFormat('l, d M Y'),
            'grand_total' => number_format((float) $stats['grand_total'], 2),
        ];
    }

    protected function getSummaryCards(array $stats): array
    {
        return [
            [
                'title' => db_trans('total_kandas'),
                'value' => number_format($stats['total_kandas']),
                'meta' => db_trans('regional_units_in_scope'),
                'icon' => 'fas fa-map-marked-alt',
                'tone' => 'primary',
            ],
            [
                'title' => db_trans('total_jumuiyas'),
                'value' => number_format($stats['total_jumuiyas']),
                'meta' => db_trans('communities_under_kanda'),
                'icon' => 'fas fa-layer-group',
                'tone' => 'info',
            ],
            [
                'title' => db_trans('total_familias'),
                'value' => number_format($stats['total_familias']),
                'meta' => db_trans('familias_under_pastoral_care'),
                'icon' => 'fas fa-home',
                'tone' => 'secondary',
            ],
            [
                'title' => db_trans('total_members'),
                'value' => number_format($stats['total_members']),
                'meta' => db_trans('registered_members_in_scope'),
                'icon' => 'fas fa-users',
                'tone' => 'success',
            ],
            [
                'title' => db_trans('male_members'),
                'value' => number_format($stats['male_members']),
                'meta' => db_trans('gender_distribution'),
                'icon' => 'fas fa-male',
                'tone' => 'dark',
            ],
            [
                'title' => db_trans('female_members'),
                'value' => number_format($stats['female_members']),
                'meta' => db_trans('gender_distribution'),
                'icon' => 'fas fa-female',
                'tone' => 'warning',
            ],
        ];
    }

    protected function getFinanceCards(array $stats): array
    {
        return [
            [
                'title' => db_trans('total_tithes'),
                'value' => number_format((float) $stats['total_tithes'], 2),
                'meta' => db_trans('tithe_collections_in_scope'),
                'icon' => 'fas fa-coins',
                'tone' => 'success',
            ],
            [
                'title' => db_trans('total_offerings'),
                'value' => number_format((float) $stats['total_offerings'], 2),
                'meta' => db_trans('offerings_recorded_in_scope'),
                'icon' => 'fas fa-hand-holding-heart',
                'tone' => 'primary',
            ],
            [
                'title' => db_trans('total_cash_contributions'),
                'value' => number_format((float) $stats['total_cash_contributions'], 2),
                'meta' => db_trans('cash_contributions_recorded'),
                'icon' => 'fas fa-wallet',
                'tone' => 'warning',
            ],
            [
                'title' => db_trans('total_bank_contributions'),
                'value' => number_format((float) $stats['total_bank_contributions'], 2),
                'meta' => db_trans('bank_contributions_recorded'),
                'icon' => 'fas fa-university',
                'tone' => 'info',
            ],
            [
                'title' => db_trans('total_mavuno'),
                'value' => number_format((float) $stats['total_mavuno'], 2),
                'meta' => db_trans('mavuno_contributions_in_scope'),
                'icon' => 'fas fa-seedling',
                'tone' => 'secondary',
            ],
            [
                'title' => db_trans('grand_total'),
                'value' => number_format((float) $stats['grand_total'], 2),
                'meta' => db_trans('all_major_income_streams_combined'),
                'icon' => 'fas fa-chart-line',
                'tone' => 'dark',
            ],
        ];
    }

    protected function getQuickLinks(User $user): array
    {
        $links = [];

        if ($user->can('kandas.create') && Route::has('kandas.create')) {
            $links[] = [
                'label' => db_trans('create_kanda'),
                'route' => route('kandas.create'),
                'icon' => 'fas fa-plus-circle',
            ];
        }

        if ($user->can('kanda-reports.view') && Route::has('kanda-reports.index')) {
            $links[] = [
                'label' => db_trans('financial_reports'),
                'route' => route('kanda-reports.index'),
                'icon' => 'fas fa-chart-pie',
            ];
        }

        if ($user->can('members.view') && Route::has('members.index')) {
            $links[] = [
                'label' => db_trans('members'),
                'route' => route('members.index'),
                'icon' => 'fas fa-users',
            ];
        }

        if ($user->can('jumuiyas.view') && Route::has('jumuiyas.index')) {
            $links[] = [
                'label' => db_trans('jumuiyas'),
                'route' => route('jumuiyas.index'),
                'icon' => 'fas fa-sitemap',
            ];
        }

        if ($user->can('finance.contributions.cash.view') && Route::has('finance.contributions.cash.index')) {
            $links[] = [
                'label' => db_trans('cash_contributions'),
                'route' => route('finance.contributions.cash.index'),
                'icon' => 'fas fa-wallet',
            ];
        }

        if ($user->can('finance.contributions.bank.view') && Route::has('finance.contributions.bank.index')) {
            $links[] = [
                'label' => db_trans('bank_contributions'),
                'route' => route('finance.contributions.bank.index'),
                'icon' => 'fas fa-university',
            ];
        }

        return $links;
    }

    protected function buildKandaBreakdown(Collection $kandas): Collection
    {
        return $kandas->map(function (Kanda $kanda) {
            $jumuiyas = $this->buildJumuiyaBreakdown($kanda);

            return [
                'id' => $kanda->id,
                'name' => $kanda->name,
                'code' => $kanda->code,
                'is_active' => (bool) $kanda->is_active,
                'jumuiya_count' => $kanda->jumuiyas_count ?? 0,
                'familias_count' => $kanda->familias_count ?? 0,
                'members_count' => $kanda->members_count ?? 0,
                'male_members_count' => $kanda->male_members_count ?? 0,
                'female_members_count' => $kanda->female_members_count ?? 0,
                'tithe_total' => (float) ($kanda->tithe_total ?? 0),
                'offering_total' => (float) ($kanda->offering_total ?? 0),
                'cash_total' => (float) ($kanda->cash_total ?? 0),
                'bank_total' => (float) ($kanda->bank_total ?? 0),
                'mavuno_total' => (float) ($kanda->mavuno_total ?? 0),
                'grand_total' => (float) ($kanda->grand_total ?? 0),
                'details_url' => Route::has('kandas.show') ? route('kandas.show', $kanda) : '#',
                'report_url' => Route::has('kanda-reports.show') ? route('kanda-reports.show', $kanda) : '#',
                'jumuiyas' => $jumuiyas,
            ];
        });
    }

    protected function getLiveFeedForVisibleKandas(Collection $kandas): array
    {
        $kandaIds = $kandas->pluck('id');
        $jumuiyaIds = Jumuiya::whereIn('kanda_id', $kandaIds)->pluck('id');
        $familiaIds = Familia::whereIn('jumuiya_id', $jumuiyaIds)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $feed = collect();

        Member::query()
            ->whereIn('id', $memberIds)
            ->latest('created_at')
            ->limit(4)
            ->get()
            ->each(function (Member $member) use ($feed) {
                $feed->push([
                    'icon' => 'fas fa-user-plus',
                    'tone' => 'primary',
                    'title' => db_trans('new_member_registered'),
                    'text' => trim(collect([$member->first_name, $member->middle_name, $member->last_name])->filter()->implode(' ')),
                    'time' => optional($member->created_at)->diffForHumans(),
                    'sort_key' => optional($member->created_at)?->timestamp ?? 0,
                ]);
            });

        if (Schema::hasTable('tithes')) {
            Tithe::query()
                ->whereIn('jumuiya_id', $jumuiyaIds)
                ->latest('created_at')
                ->limit(4)
                ->get()
                ->each(function (Tithe $tithe) use ($feed) {
                    $feed->push([
                        'icon' => 'fas fa-coins',
                        'tone' => 'success',
                        'title' => db_trans('tithe_recorded'),
                        'text' => number_format((float) $tithe->amount, 2),
                        'time' => optional($tithe->created_at)->diffForHumans(),
                        'sort_key' => optional($tithe->created_at)?->timestamp ?? 0,
                    ]);
                });
        }

        if (Schema::hasTable('cash_contributions')) {
            CashContribution::query()
                ->whereIn('member_id', $memberIds)
                ->latest('created_at')
                ->limit(4)
                ->get()
                ->each(function (CashContribution $contribution) use ($feed) {
                    $feed->push([
                        'icon' => 'fas fa-wallet',
                        'tone' => 'warning',
                        'title' => db_trans('cash_contribution_recorded'),
                        'text' => number_format((float) $contribution->amount, 2),
                        'time' => optional($contribution->created_at)->diffForHumans(),
                        'sort_key' => optional($contribution->created_at)?->timestamp ?? 0,
                    ]);
                });
        }

        if (Schema::hasTable('bank_contributions')) {
            BankContribution::query()
                ->whereIn('member_id', $memberIds)
                ->latest('created_at')
                ->limit(4)
                ->get()
                ->each(function (BankContribution $contribution) use ($feed) {
                    $feed->push([
                        'icon' => 'fas fa-university',
                        'tone' => 'info',
                        'title' => db_trans('bank_contribution_recorded'),
                        'text' => number_format((float) $contribution->amount, 2),
                        'time' => optional($contribution->created_at)->diffForHumans(),
                        'sort_key' => optional($contribution->created_at)?->timestamp ?? 0,
                    ]);
                });
        }

        if (Schema::hasTable('offerings')) {
            Offering::query()
                ->where(function ($query) use ($jumuiyaIds, $kandaIds) {
                    $query->whereIn('jumuiya_id', $jumuiyaIds)
                        ->orWhereIn('kanda_id', $kandaIds);
                })
                ->latest('created_at')
                ->limit(4)
                ->get()
                ->each(function (Offering $offering) use ($feed) {
                    $feed->push([
                        'icon' => 'fas fa-hand-holding-heart',
                        'tone' => 'danger',
                        'title' => db_trans('offering_recorded'),
                        'text' => number_format((float) $offering->amount, 2),
                        'time' => optional($offering->created_at)->diffForHumans(),
                        'sort_key' => optional($offering->created_at)?->timestamp ?? 0,
                    ]);
                });
        }

        return $feed->sortByDesc('sort_key')->take(10)->values()->map(function ($item) {
            unset($item['sort_key']);

            return $item;
        })->all();
    }

    protected function getAlertsForVisibleKandas(Collection $kandas): array
    {
        $kandaIds = $kandas->pluck('id');
        $jumuiyaIds = Jumuiya::whereIn('kanda_id', $kandaIds)->pluck('id');
        $familiaIds = Familia::whereIn('jumuiya_id', $jumuiyaIds)->pluck('id');

        $membersWithoutPhone = Member::query()
            ->whereIn('familia_id', $familiaIds)
            ->where(function ($query) {
                $query->whereNull('phone')->orWhere('phone', '');
            })
            ->count();

        $inactiveJumuiyas = Jumuiya::query()
            ->whereIn('kanda_id', $kandaIds)
            ->where('is_active', false)
            ->count();

        $familiasWithoutMembers = Familia::query()
            ->whereIn('jumuiya_id', $jumuiyaIds)
            ->doesntHave('members')
            ->count();

        return [
            [
                'label' => db_trans('members_without_phone'),
                'value' => $membersWithoutPhone,
                'route' => Route::has('members.index') ? route('members.index') : '#',
            ],
            [
                'label' => db_trans('inactive_jumuiyas'),
                'value' => $inactiveJumuiyas,
                'route' => Route::has('jumuiyas.index') ? route('jumuiyas.index') : '#',
            ],
            [
                'label' => db_trans('familias_without_members'),
                'value' => $familiasWithoutMembers,
                'route' => Route::has('familias.index') ? route('familias.index') : '#',
            ],
        ];
    }

    protected function scopedKandasQuery(User $user): Builder
    {
        $scope = $this->scopeResolver->resolve($user);
        $query = Kanda::query();

        if ($scope->isInvalid()) {
            return $query->whereRaw('1 = 0');
        }

        if ($scope->isGlobal()) {
            return $query;
        }

        if ($scope->isKanda()) {
            return $query->whereKey($scope->kandaId);
        }

        if ($scope->isJumuiya()) {
            if ($scope->kandaId) {
                return $query->whereKey($scope->kandaId);
            }

            return $query->whereRaw('1 = 0');
        }

        return $query->whereRaw('1 = 0');
    }

    protected function buildKandaSummary(Kanda $kanda): array
    {
        $jumuiyaIds = Jumuiya::where('kanda_id', $kanda->id)->pluck('id');
        $familiaIds = Familia::whereIn('jumuiya_id', $jumuiyaIds)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $titheTotal = Schema::hasTable('tithes')
            ? (float) Tithe::whereIn('jumuiya_id', $jumuiyaIds)->sum('amount')
            : 0;

        $cashTotal = Schema::hasTable('cash_contributions')
            ? (float) CashContribution::whereIn('member_id', $memberIds)->sum('amount')
            : 0;

        $mavunoTotal = Schema::hasTable('cash_contributions')
            ? (float) CashContribution::whereIn('member_id', $memberIds)
                ->whereHas('contributionType', fn ($q) => $q->where('slug', 'mavuno'))
                ->sum('amount')
            : 0;

        $bankTotal = Schema::hasTable('bank_contributions')
            ? (float) BankContribution::whereIn('member_id', $memberIds)->sum('amount')
            : 0;

        $offeringTotal = Schema::hasTable('offerings')
            ? (float) Offering::where(function ($query) use ($jumuiyaIds, $kanda) {
                $query->whereIn('jumuiya_id', $jumuiyaIds)
                    ->orWhere('kanda_id', $kanda->id);
            })->sum('amount')
            : 0;

        return [
            'jumuiyas_count' => $jumuiyaIds->count(),
            'familias_count' => $familiaIds->count(),
            'members_count' => $memberIds->count(),
            'male_members_count' => Member::whereIn('id', $memberIds)->where('gender', 'Male')->count(),
            'female_members_count' => Member::whereIn('id', $memberIds)->where('gender', 'Female')->count(),
            'tithe_total' => $titheTotal,
            'mavuno_total' => $mavunoTotal,
            'cash_total' => $cashTotal,
            'bank_total' => $bankTotal,
            'offering_total' => $offeringTotal,
            'grand_total' => $titheTotal + $cashTotal + $bankTotal + $offeringTotal,
        ];
    }

    protected function getRecentMembers(Kanda $kanda): Collection
    {
        return Member::query()
            ->select('members.*')
            ->join('familias', 'familias.id', '=', 'members.familia_id')
            ->join('jumuiyas', 'jumuiyas.id', '=', 'familias.jumuiya_id')
            ->where('jumuiyas.kanda_id', $kanda->id)
            ->with('familia.jumuiya')
            ->latest('members.created_at')
            ->limit(8)
            ->get();
    }

    protected function buildJumuiyaBreakdown(Kanda $kanda): Collection
    {
        return Jumuiya::where('kanda_id', $kanda->id)
            ->latest()
            ->get()
            ->map(function (Jumuiya $jumuiya) {
                $familiaIds = Familia::where('jumuiya_id', $jumuiya->id)->pluck('id');
                $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

                $titheTotal = Schema::hasTable('tithes')
                    ? (float) Tithe::where('jumuiya_id', $jumuiya->id)->sum('amount')
                    : 0;

                $cashTotal = Schema::hasTable('cash_contributions')
                    ? (float) CashContribution::whereIn('member_id', $memberIds)->sum('amount')
                    : 0;

                $mavunoTotal = Schema::hasTable('cash_contributions')
                    ? (float) CashContribution::whereIn('member_id', $memberIds)
                        ->whereHas('contributionType', fn ($q) => $q->where('slug', 'mavuno'))
                        ->sum('amount')
                    : 0;

                $bankTotal = Schema::hasTable('bank_contributions')
                    ? (float) BankContribution::whereIn('member_id', $memberIds)->sum('amount')
                    : 0;

                $offeringTotal = Schema::hasTable('offerings')
                    ? (float) Offering::where('jumuiya_id', $jumuiya->id)->sum('amount')
                    : 0;

                return [
                    'id' => $jumuiya->id,
                    'name' => $jumuiya->name,
                    'code' => $jumuiya->code,
                    'familias_count' => $familiaIds->count(),
                    'members_count' => $memberIds->count(),
                    'tithe_total' => $titheTotal,
                    'offering_total' => $offeringTotal,
                    'cash_total' => $cashTotal,
                    'bank_total' => $bankTotal,
                    'mavuno_total' => $mavunoTotal,
                    'grand_total' => $titheTotal + $offeringTotal + $cashTotal + $bankTotal,
                    'details_url' => Route::has('jumuiyas.show') ? route('jumuiyas.show', $jumuiya) : '#',
                    'report_url' => Route::has('jumuiya-reports.show') ? route('jumuiya-reports.show', $jumuiya) : '#',
                ];
            });
    }

    protected function getMonthlyFinanceChart(Kanda $kanda): array
    {
        $jumuiyaIds = Jumuiya::where('kanda_id', $kanda->id)->pluck('id');
        $familiaIds = Familia::whereIn('jumuiya_id', $jumuiyaIds)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $labels = [];
        $tithes = [];
        $offerings = [];
        $cash = [];
        $bank = [];

        for ($month = 1; $month <= 12; $month++) {
            $labels[] = Carbon::create()->month($month)->format('M');

            $tithes[] = Schema::hasTable('tithes')
                ? (float) Tithe::whereIn('jumuiya_id', $jumuiyaIds)
                    ->whereYear('contribution_date', now()->year)
                    ->whereMonth('contribution_date', $month)
                    ->sum('amount')
                : 0;

            $offerings[] = Schema::hasTable('offerings')
                ? (float) Offering::where(function ($query) use ($jumuiyaIds, $kanda) {
                    $query->whereIn('jumuiya_id', $jumuiyaIds)
                        ->orWhere('kanda_id', $kanda->id);
                })
                    ->whereYear('collection_date', now()->year)
                    ->whereMonth('collection_date', $month)
                    ->sum('amount')
                : 0;

            $cash[] = Schema::hasTable('cash_contributions')
                ? (float) CashContribution::whereIn('member_id', $memberIds)
                    ->whereYear('contribution_date', now()->year)
                    ->whereMonth('contribution_date', $month)
                    ->sum('amount')
                : 0;

            $bank[] = Schema::hasTable('bank_contributions')
                ? (float) BankContribution::whereIn('member_id', $memberIds)
                    ->whereYear('contribution_date', now()->year)
                    ->whereMonth('contribution_date', $month)
                    ->sum('amount')
                : 0;
        }

        return [
            'labels' => $labels,
            'tithes' => $tithes,
            'offerings' => $offerings,
            'cash' => $cash,
            'bank' => $bank,
        ];
    }

    protected function getMonthlyFinanceChartForVisibleKandas(Collection $kandas): array
    {
        $kandaIds = $kandas->pluck('id');
        $jumuiyaIds = Jumuiya::whereIn('kanda_id', $kandaIds)->pluck('id');
        $familiaIds = Familia::whereIn('jumuiya_id', $jumuiyaIds)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $labels = [];
        $tithes = [];
        $offerings = [];
        $cash = [];
        $bank = [];

        for ($month = 1; $month <= 12; $month++) {
            $labels[] = Carbon::create()->month($month)->format('M');

            $tithes[] = Schema::hasTable('tithes')
                ? (float) Tithe::whereIn('jumuiya_id', $jumuiyaIds)
                    ->whereYear('contribution_date', now()->year)
                    ->whereMonth('contribution_date', $month)
                    ->sum('amount')
                : 0;

            $offerings[] = Schema::hasTable('offerings')
                ? (float) Offering::where(function ($query) use ($jumuiyaIds, $kandaIds) {
                    $query->whereIn('jumuiya_id', $jumuiyaIds)
                        ->orWhereIn('kanda_id', $kandaIds);
                })
                    ->whereYear('collection_date', now()->year)
                    ->whereMonth('collection_date', $month)
                    ->sum('amount')
                : 0;

            $cash[] = Schema::hasTable('cash_contributions')
                ? (float) CashContribution::whereIn('member_id', $memberIds)
                    ->whereYear('contribution_date', now()->year)
                    ->whereMonth('contribution_date', $month)
                    ->sum('amount')
                : 0;

            $bank[] = Schema::hasTable('bank_contributions')
                ? (float) BankContribution::whereIn('member_id', $memberIds)
                    ->whereYear('contribution_date', now()->year)
                    ->whereMonth('contribution_date', $month)
                    ->sum('amount')
                : 0;
        }

        return [
            'labels' => $labels,
            'tithes' => $tithes,
            'offerings' => $offerings,
            'cash' => $cash,
            'bank' => $bank,
        ];
    }

    protected function getPendingItemCountForUser(User $user): int
    {
        $kandas = $this->scopedKandasQuery($user)->pluck('id');
        $jumuiyaIds = Jumuiya::whereIn('kanda_id', $kandas)->pluck('id');
        $familiaIds = Familia::whereIn('jumuiya_id', $jumuiyaIds)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $count = 0;

        if (Schema::hasTable('tithes')) {
            $count += Tithe::whereIn('jumuiya_id', $jumuiyaIds)->where('status', Tithe::STATUS_PENDING)->count();
        }

        if (Schema::hasTable('cash_contributions')) {
            $count += CashContribution::whereIn('member_id', $memberIds)->where('status', CashContribution::STATUS_PENDING)->count();
        }

        if (Schema::hasTable('offerings')) {
            $count += Offering::where(function ($query) use ($jumuiyaIds, $kandas) {
                $query->whereIn('jumuiya_id', $jumuiyaIds)
                    ->orWhereIn('kanda_id', $kandas);
            })->where('status', Offering::STATUS_PENDING)->count();
        }

        return $count;
    }

    protected function resolveScopeLabel(User $user): string
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            return 'Invalid Scope';
        }

        if ($scope->isGlobal()) {
            return db_trans('parish_scope');
        }

        if ($scope->isKanda()) {
            $kanda = Kanda::find($scope->kandaId);

            return $kanda ? $kanda->name : db_trans('kanda_scope');
        }

        if ($scope->isJumuiya()) {
            $jumuiya = Jumuiya::find($scope->jumuiyaId);

            return $jumuiya ? $jumuiya->name : db_trans('jumuiya_scope');
        }

        return db_trans('parish_scope');
    }
}