<?php

namespace App\Services\Kanda;

use App\Models\BankContribution;
use App\Models\CashContribution;
use App\Models\Familia;
use App\Models\Jumuiya;
use App\Models\Kanda;
use App\Models\Member;
use App\Models\Offering;
use App\Models\Tithe;
use App\Models\User;
use App\Services\Access\ScopeAccessGate;
use App\Services\Access\UserScopeResolver;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Schema;

class KandaReportService
{
    public function __construct(
        protected UserScopeResolver $scopeResolver,
        protected ScopeAccessGate $scopeAccessGate,
    ) {
    }

    public function getIndexData(User $user, array $filters = []): array
    {
        $year = (int) ($filters['year'] ?? now()->year);
        $month = ! empty($filters['month']) ? (int) $filters['month'] : null;

        $kandas = $this->scopedKandasQuery($user)
            ->where('is_active', true)
            ->orderBy('name')
            ->get()
            ->map(fn (Kanda $kanda) => $this->buildKandaReportRow($kanda, $year, $month));

        $stats = [
            'total_kandas' => $kandas->count(),
            'total_jumuiyas' => $kandas->sum('jumuiyas_count'),
            'total_familias' => $kandas->sum('familias_count'),
            'total_members' => $kandas->sum('members_count'),
            'total_tithes' => (float) $kandas->sum('tithe_total'),
            'total_cash' => (float) $kandas->sum('cash_total'),
            'total_bank' => (float) $kandas->sum('bank_total'),
            'total_offerings' => (float) $kandas->sum('offering_total'),
            'total_mavuno' => (float) $kandas->sum('mavuno_total'),
            'grand_total' => (float) $kandas->sum('grand_total'),
        ];

        return [
            'pageTitle' => db_trans('kanda_financial_reports'),
            'hero' => [
                'eyebrow' => db_trans('kanda_financial_reports'),
                'title' => db_trans('kanda_report_command_centre'),
                'subtitle' => db_trans('kanda_report_index_subtitle'),
                'scope_label' => $this->resolveScopeLabel($user),
                'period' => $this->formatPeriodLabel($year, $month),
                'today' => now()->translatedFormat('l, d M Y'),
                'grand_total' => number_format($stats['grand_total'], 2),
            ],
            'selectedYear' => $year,
            'selectedMonth' => $month,
            'availableYears' => range(now()->year, now()->year - 5),
            'reports' => $kandas,
            'stats' => $stats,
            'summaryCards' => [
                [
                    'title' => db_trans('total_kandas'),
                    'value' => number_format($stats['total_kandas']),
                    'meta' => db_trans('regional_units_in_scope'),
                    'icon' => 'fas fa-map-marked-alt',
                    'tone' => 'primary',
                ],
                [
                    'title' => db_trans('total_jumuiyas'),
                    'value' => number_format($stats['total_jumuiyas']),
                    'meta' => db_trans('communities_under_kanda'),
                    'icon' => 'fas fa-layer-group',
                    'tone' => 'info',
                ],
                [
                    'title' => db_trans('total_familias'),
                    'value' => number_format($stats['total_familias']),
                    'meta' => db_trans('familias_under_pastoral_care'),
                    'icon' => 'fas fa-home',
                    'tone' => 'secondary',
                ],
                [
                    'title' => db_trans('total_members'),
                    'value' => number_format($stats['total_members']),
                    'meta' => db_trans('registered_members_in_scope'),
                    'icon' => 'fas fa-users',
                    'tone' => 'success',
                ],
            ],
            'financeCards' => [
                [
                    'title' => db_trans('total_tithes'),
                    'value' => number_format($stats['total_tithes'], 2),
                    'meta' => db_trans('tithe_collections_in_scope'),
                    'icon' => 'fas fa-coins',
                    'tone' => 'success',
                ],
                [
                    'title' => db_trans('total_offerings'),
                    'value' => number_format($stats['total_offerings'], 2),
                    'meta' => db_trans('offerings_recorded_in_scope'),
                    'icon' => 'fas fa-hand-holding-heart',
                    'tone' => 'primary',
                ],
                [
                    'title' => db_trans('total_cash_contributions'),
                    'value' => number_format($stats['total_cash'], 2),
                    'meta' => db_trans('cash_contributions_recorded'),
                    'icon' => 'fas fa-wallet',
                    'tone' => 'warning',
                ],
                [
                    'title' => db_trans('total_bank_contributions'),
                    'value' => number_format($stats['total_bank'], 2),
                    'meta' => db_trans('bank_contributions_recorded'),
                    'icon' => 'fas fa-university',
                    'tone' => 'info',
                ],
                [
                    'title' => db_trans('total_mavuno'),
                    'value' => number_format($stats['total_mavuno'], 2),
                    'meta' => db_trans('mavuno_contributions_in_scope'),
                    'icon' => 'fas fa-seedling',
                    'tone' => 'secondary',
                ],
                [
                    'title' => db_trans('grand_total'),
                    'value' => number_format($stats['grand_total'], 2),
                    'meta' => db_trans('all_major_income_streams_combined'),
                    'icon' => 'fas fa-chart-line',
                    'tone' => 'dark',
                ],
            ],
            'chartData' => [
                'labels' => $kandas->pluck('name')->values(),
                'tithes' => $kandas->pluck('tithe_total')->map(fn ($v) => (float) $v)->values(),
                'cash' => $kandas->pluck('cash_total')->map(fn ($v) => (float) $v)->values(),
                'bank' => $kandas->pluck('bank_total')->map(fn ($v) => (float) $v)->values(),
                'offerings' => $kandas->pluck('offering_total')->map(fn ($v) => (float) $v)->values(),
                'grand_total' => $kandas->pluck('grand_total')->map(fn ($v) => (float) $v)->values(),
            ],
            'compositionChart' => [
                'labels' => [
                    db_trans('tithes'),
                    db_trans('offerings'),
                    db_trans('cash_contributions'),
                    db_trans('bank_contributions'),
                ],
                'values' => [
                    (float) $stats['total_tithes'],
                    (float) $stats['total_offerings'],
                    (float) $stats['total_cash'],
                    (float) $stats['total_bank'],
                ],
            ],
            'quickLinks' => $this->getQuickLinks($user),
            'liveFeed' => $this->buildIndexLiveFeed($kandas, $year, $month),
        ];
    }

    public function getShowData(Kanda $kanda, User $user, array $filters = []): array
    {
        $this->scopeAccessGate->authorizeKanda($user, $kanda);

        $year = (int) ($filters['year'] ?? now()->year);

        $reportRow = $this->buildKandaReportRow($kanda, $year, null);
        $jumuiyas = $this->buildJumuiyaReportRows($kanda, $year);
        $summary = $this->buildKandaSummary($kanda, $year);
        $monthlyTrends = $this->buildMonthlyTrends($kanda, $year);

        return [
            'pageTitle' => db_trans('kanda_financial_report'),
            'kanda' => $kanda,
            'hero' => [
                'eyebrow' => db_trans('kanda_financial_report'),
                'title' => $kanda->name,
                'subtitle' => db_trans('kanda_report_show_subtitle'),
                'scope_label' => $this->resolveScopeLabel($user),
                'period' => (string) $year,
                'today' => now()->translatedFormat('l, d M Y'),
            ],
            'selectedYear' => $year,
            'availableYears' => range(now()->year, now()->year - 5),
            'stats' => $summary,
            'summaryCards' => [
                [
                    'title' => db_trans('jumuiyas'),
                    'value' => number_format($summary['jumuiyas_count']),
                    'meta' => db_trans('communities_under_kanda'),
                    'icon' => 'fas fa-layer-group',
                    'tone' => 'primary',
                ],
                [
                    'title' => db_trans('familias'),
                    'value' => number_format($summary['familias_count']),
                    'meta' => db_trans('familias_under_pastoral_care'),
                    'icon' => 'fas fa-home',
                    'tone' => 'info',
                ],
                [
                    'title' => db_trans('members'),
                    'value' => number_format($summary['members_count']),
                    'meta' => db_trans('registered_members_in_scope'),
                    'icon' => 'fas fa-users',
                    'tone' => 'success',
                ],
                [
                    'title' => db_trans('grand_total'),
                    'value' => number_format($summary['grand_total'], 2),
                    'meta' => db_trans('all_major_income_streams_combined'),
                    'icon' => 'fas fa-chart-line',
                    'tone' => 'dark',
                ],
            ],
            'financeCards' => [
                [
                    'title' => db_trans('total_tithes'),
                    'value' => number_format($summary['tithe_total'], 2),
                    'meta' => db_trans('tithe_collections_in_scope'),
                    'icon' => 'fas fa-coins',
                    'tone' => 'success',
                ],
                [
                    'title' => db_trans('total_offerings'),
                    'value' => number_format($summary['offering_total'], 2),
                    'meta' => db_trans('offerings_recorded_in_scope'),
                    'icon' => 'fas fa-hand-holding-heart',
                    'tone' => 'primary',
                ],
                [
                    'title' => db_trans('total_cash_contributions'),
                    'value' => number_format($summary['cash_total'], 2),
                    'meta' => db_trans('cash_contributions_recorded'),
                    'icon' => 'fas fa-wallet',
                    'tone' => 'warning',
                ],
                [
                    'title' => db_trans('total_bank_contributions'),
                    'value' => number_format($summary['bank_total'], 2),
                    'meta' => db_trans('bank_contributions_recorded'),
                    'icon' => 'fas fa-university',
                    'tone' => 'info',
                ],
                [
                    'title' => db_trans('total_mavuno'),
                    'value' => number_format($summary['mavuno_total'], 2),
                    'meta' => db_trans('mavuno_contributions_in_scope'),
                    'icon' => 'fas fa-seedling',
                    'tone' => 'secondary',
                ],
            ],
            'jumuiyas' => $jumuiyas,
            'monthlyTrends' => $monthlyTrends,
            'compositionChart' => [
                'labels' => [
                    db_trans('tithes'),
                    db_trans('offerings'),
                    db_trans('cash_contributions'),
                    db_trans('bank_contributions'),
                ],
                'values' => [
                    (float) $summary['tithe_total'],
                    (float) $summary['offering_total'],
                    (float) $summary['cash_total'],
                    (float) $summary['bank_total'],
                ],
            ],
            'liveFeed' => $this->buildShowLiveFeed($kanda, $year),
            'recentTopline' => $reportRow,
        ];
    }

    protected function scopedKandasQuery(User $user): Builder
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = Kanda::query();

        if ($scope->isInvalid()) {
            return $query->whereRaw('1 = 0');
        }

        if ($scope->isGlobal()) {
            return $query;
        }

        if ($scope->isKanda()) {
            return $query->whereKey($scope->kandaId);
        }

        if ($scope->isJumuiya()) {
            if ($scope->kandaId) {
                return $query->whereKey($scope->kandaId);
            }

            return $query->whereRaw('1 = 0');
        }

        return $query->whereRaw('1 = 0');
    }

    protected function buildKandaReportRow(Kanda $kanda, int $year, ?int $month = null): Kanda
    {
        $jumuiyaIds = Jumuiya::where('kanda_id', $kanda->id)->pluck('id');
        $familiaIds = Familia::whereIn('jumuiya_id', $jumuiyaIds)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $titheQuery = Tithe::whereIn('jumuiya_id', $jumuiyaIds)->whereYear('contribution_date', $year);
        $cashQuery = CashContribution::whereIn('member_id', $memberIds)->whereYear('contribution_date', $year);
        $mavunoQuery = CashContribution::whereIn('member_id', $memberIds)
            ->whereHas('contributionType', fn ($q) => $q->where('slug', 'mavuno'))
            ->whereYear('contribution_date', $year);

        $bankQuery = Schema::hasTable('bank_contributions')
            ? BankContribution::query()
                ->where(function ($query) use ($jumuiyaIds, $kanda) {
                    $query->whereIn('jumuiya_id', $jumuiyaIds)
                        ->orWhere('kanda_id', $kanda->id);
                })
                ->whereYear('contribution_date', $year)
            : null;

        $offeringQuery = Schema::hasTable('offerings')
            ? Offering::query()
                ->where(function ($query) use ($jumuiyaIds, $kanda) {
                    $query->whereIn('jumuiya_id', $jumuiyaIds)
                        ->orWhere('kanda_id', $kanda->id);
                })
                ->whereYear('collection_date', $year)
            : null;

        if ($month) {
            $titheQuery->whereMonth('contribution_date', $month);
            $cashQuery->whereMonth('contribution_date', $month);
            $mavunoQuery->whereMonth('contribution_date', $month);

            if ($bankQuery) {
                $bankQuery->whereMonth('contribution_date', $month);
            }

            if ($offeringQuery) {
                $offeringQuery->whereMonth('collection_date', $month);
            }
        }

        $tithes = (float) $titheQuery->sum('amount');
        $cash = (float) $cashQuery->sum('amount');
        $mavuno = (float) $mavunoQuery->sum('amount');
        $bank = $bankQuery ? (float) $bankQuery->sum('amount') : 0;
        $offerings = $offeringQuery ? (float) $offeringQuery->sum('amount') : 0;

        $kanda->jumuiyas_count = $jumuiyaIds->count();
        $kanda->familias_count = $familiaIds->count();
        $kanda->members_count = $memberIds->count();
        $kanda->tithe_total = $tithes;
        $kanda->cash_total = $cash;
        $kanda->mavuno_total = $mavuno;
        $kanda->bank_total = $bank;
        $kanda->offering_total = $offerings;
        $kanda->grand_total = $tithes + $cash + $bank + $offerings;

        return $kanda;
    }

    protected function buildKandaSummary(Kanda $kanda, int $year): array
    {
        $row = $this->buildKandaReportRow($kanda, $year);

        return [
            'jumuiyas_count' => $row->jumuiyas_count,
            'familias_count' => $row->familias_count,
            'members_count' => $row->members_count,
            'tithe_total' => $row->tithe_total,
            'cash_total' => $row->cash_total,
            'mavuno_total' => $row->mavuno_total,
            'bank_total' => $row->bank_total,
            'offering_total' => $row->offering_total,
            'grand_total' => $row->grand_total,
        ];
    }

    protected function buildJumuiyaReportRows(Kanda $kanda, int $year): Collection
    {
        return Jumuiya::where('kanda_id', $kanda->id)
            ->orderBy('name')
            ->get()
            ->map(function (Jumuiya $jumuiya) use ($year) {
                $familiaIds = Familia::where('jumuiya_id', $jumuiya->id)->pluck('id');
                $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

                $tithes = (float) Tithe::where('jumuiya_id', $jumuiya->id)
                    ->whereYear('contribution_date', $year)
                    ->sum('amount');

                $cash = (float) CashContribution::whereIn('member_id', $memberIds)
                    ->whereYear('contribution_date', $year)
                    ->sum('amount');

                $mavuno = (float) CashContribution::whereIn('member_id', $memberIds)
                    ->whereHas('contributionType', fn ($q) => $q->where('slug', 'mavuno'))
                    ->whereYear('contribution_date', $year)
                    ->sum('amount');

                $bank = Schema::hasTable('bank_contributions')
                    ? (float) BankContribution::where('jumuiya_id', $jumuiya->id)
                        ->whereYear('contribution_date', $year)
                        ->sum('amount')
                    : 0;

                $offerings = Schema::hasTable('offerings')
                    ? (float) Offering::where('jumuiya_id', $jumuiya->id)
                        ->whereYear('collection_date', $year)
                        ->sum('amount')
                    : 0;

                return [
                    'id' => $jumuiya->id,
                    'name' => $jumuiya->name,
                    'code' => $jumuiya->code,
                    'familias_count' => $familiaIds->count(),
                    'members_count' => $memberIds->count(),
                    'tithe_total' => $tithes,
                    'cash_total' => $cash,
                    'mavuno_total' => $mavuno,
                    'bank_total' => $bank,
                    'offering_total' => $offerings,
                    'grand_total' => $tithes + $cash + $bank + $offerings,
                ];
            });
    }

    protected function buildMonthlyTrends(Kanda $kanda, int $year): array
    {
        $jumuiyaIds = Jumuiya::where('kanda_id', $kanda->id)->pluck('id');
        $familiaIds = Familia::whereIn('jumuiya_id', $jumuiyaIds)->pluck('id');
        $memberIds = Member::whereIn('familia_id', $familiaIds)->pluck('id');

        $labels = [];
        $tithes = [];
        $cash = [];
        $bank = [];
        $offerings = [];

        for ($month = 1; $month <= 12; $month++) {
            $labels[] = Carbon::create()->month($month)->format('M');

            $tithes[] = (float) Tithe::whereIn('jumuiya_id', $jumuiyaIds)
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount');

            $cash[] = (float) CashContribution::whereIn('member_id', $memberIds)
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount');

            $bank[] = Schema::hasTable('bank_contributions')
                ? (float) BankContribution::where(function ($query) use ($jumuiyaIds, $kanda) {
                    $query->whereIn('jumuiya_id', $jumuiyaIds)
                        ->orWhere('kanda_id', $kanda->id);
                })
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount')
                : 0;

            $offerings[] = Schema::hasTable('offerings')
                ? (float) Offering::where(function ($query) use ($jumuiyaIds, $kanda) {
                    $query->whereIn('jumuiya_id', $jumuiyaIds)
                        ->orWhere('kanda_id', $kanda->id);
                })
                ->whereYear('collection_date', $year)
                ->whereMonth('collection_date', $month)
                ->sum('amount')
                : 0;
        }

        return [
            'labels' => $labels,
            'tithes' => $tithes,
            'cash' => $cash,
            'bank' => $bank,
            'offerings' => $offerings,
        ];
    }

    protected function getQuickLinks(User $user): array
    {
        $links = [];

        if ($user->can('kanda-reports.view') && Route::has('kanda-reports.index')) {
            $links[] = ['label' => db_trans('report_overview'), 'route' => route('kanda-reports.index'), 'icon' => 'fas fa-chart-column'];
        }

        if ($user->can('kandas.view') && Route::has('kandas.index')) {
            $links[] = ['label' => db_trans('kandas'), 'route' => route('kandas.index'), 'icon' => 'fas fa-map-marked-alt'];
        }

        if ($user->can('finance.contributions.cash.view') && Route::has('finance.contributions.cash.index')) {
            $links[] = ['label' => db_trans('cash_contributions'), 'route' => route('finance.contributions.cash.index'), 'icon' => 'fas fa-wallet'];
        }

        if ($user->can('finance.contributions.bank.view') && Route::has('finance.contributions.bank.index')) {
            $links[] = ['label' => db_trans('bank_contributions'), 'route' => route('finance.contributions.bank.index'), 'icon' => 'fas fa-university'];
        }

        return $links;
    }

    protected function buildIndexLiveFeed(Collection $kandas, int $year, ?int $month): array
    {
        $feed = collect();

        foreach ($kandas->take(6) as $kanda) {
            $feed->push([
                'icon' => 'fas fa-map-marked-alt',
                'tone' => 'primary',
                'title' => db_trans('kanda_report_generated'),
                'text' => $kanda->name . ' · ' . number_format((float) $kanda->grand_total, 2),
                'time' => $this->formatPeriodLabel($year, $month),
            ]);
        }

        return $feed->all();
    }

    protected function buildShowLiveFeed(Kanda $kanda, int $year): array
    {
        $row = $this->buildKandaReportRow($kanda, $year);

        return [
            [
                'icon' => 'fas fa-coins',
                'tone' => 'success',
                'title' => db_trans('tithe_position'),
                'text' => number_format((float) $row->tithe_total, 2),
                'time' => (string) $year,
            ],
            [
                'icon' => 'fas fa-wallet',
                'tone' => 'warning',
                'title' => db_trans('cash_position'),
                'text' => number_format((float) $row->cash_total, 2),
                'time' => (string) $year,
            ],
            [
                'icon' => 'fas fa-university',
                'tone' => 'info',
                'title' => db_trans('bank_position'),
                'text' => number_format((float) $row->bank_total, 2),
                'time' => (string) $year,
            ],
            [
                'icon' => 'fas fa-hand-holding-heart',
                'tone' => 'danger',
                'title' => db_trans('offering_position'),
                'text' => number_format((float) $row->offering_total, 2),
                'time' => (string) $year,
            ],
        ];
    }

    protected function resolveScopeLabel(User $user): string
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            return 'Invalid Scope';
        }

        if ($scope->isGlobal()) {
            return db_trans('parish_scope');
        }

        if ($scope->isKanda()) {
            $kanda = Kanda::find($scope->kandaId);

            return $kanda ? $kanda->name : db_trans('kanda_scope');
        }

        if ($scope->isJumuiya()) {
            $jumuiya = Jumuiya::find($scope->jumuiyaId);

            return $jumuiya ? $jumuiya->name : db_trans('jumuiya_scope');
        }

        return db_trans('parish_scope');
    }

    protected function formatPeriodLabel(int $year, ?int $month): string
    {
        if ($month) {
            return Carbon::createFromDate($year, $month, 1)->translatedFormat('F Y');
        }

        return (string) $year;
    }
}