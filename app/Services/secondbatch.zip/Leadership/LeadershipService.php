<?php

namespace App\Services\Leadership;

use App\Models\LeadershipAssignment;
use App\Models\LeadershipPosition;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class LeadershipService
{
    public function createPosition(array $data): LeadershipPosition
    {
        return LeadershipPosition::create($this->normalizePositionData($data));
    }

    public function updatePosition(LeadershipPosition $position, array $data): LeadershipPosition
    {
        $position->update($this->normalizePositionData($data));
        return $position->refresh();
    }

    public function createAssignment(array $data, int $appointedBy): LeadershipAssignment
    {
        return DB::transaction(function () use ($data, $appointedBy) {
            $payload = $this->normalizeAssignmentData($data);
            $payload['appointed_by'] = $appointedBy;
            $assignment = LeadershipAssignment::create($payload);
            $this->syncMappedRole($assignment);
            return $assignment;
        });
    }

    public function updateAssignment(LeadershipAssignment $assignment, array $data): LeadershipAssignment
    {
        return DB::transaction(function () use ($assignment, $data) {
            $oldUser = $assignment->user;
            $oldRole = $assignment->position?->auto_role_name;

            $assignment->update($this->normalizeAssignmentData($data));
            $assignment->refresh()->load(['user', 'position']);

            if ($oldUser && $oldRole && $oldUser->id !== $assignment->user_id && $oldUser->hasRole($oldRole)) {
                $oldUser->removeRole($oldRole);
            }

            $this->syncMappedRole($assignment);
            return $assignment;
        });
    }

    public function deleteAssignment(LeadershipAssignment $assignment): void
    {
        DB::transaction(function () use ($assignment) {
            $user = $assignment->user;
            $role = $assignment->position?->auto_role_name;
            if ($user && $role && $user->hasRole($role)) {
                $user->removeRole($role);
            }
            $assignment->delete();
        });
    }

    public function syncMappedRole(LeadershipAssignment $assignment): void
    {
        $assignment->loadMissing(['position', 'user']);
        if (! $assignment->user || ! $assignment->position?->auto_role_name) {
            return;
        }

        if ($assignment->status !== 'active') {
            $assignment->user->removeRole($assignment->position->auto_role_name);
            return;
        }

        $assignment->user->assignRole($assignment->position->auto_role_name);
    }

    protected function normalizePositionData(array $data): array
    {
        $name = trim((string) $data['name']);
        return [
            'name' => $name,
            'slug' => Arr::get($data, 'slug') ?: Str::slug($name),
            'level_type' => $data['level_type'],
            'committee_type' => $data['committee_type'],
            'auto_role_name' => Arr::get($data, 'auto_role_name') ?: null,
            'display_order' => (int) Arr::get($data, 'display_order', 0),
            'is_system' => (bool) Arr::get($data, 'is_system', false),
            'is_active' => (bool) Arr::get($data, 'is_active', true),
            'description' => Arr::get($data, 'description'),
        ];
    }

    protected function normalizeAssignmentData(array $data): array
    {
        return [
            'member_id' => $data['member_id'],
            'user_id' => Arr::get($data, 'user_id'),
            'leadership_position_id' => $data['leadership_position_id'],
            'kanda_id' => Arr::get($data, 'kanda_id'),
            'jumuiya_id' => Arr::get($data, 'jumuiya_id'),
            'apostolic_group_id' => Arr::get($data, 'apostolic_group_id'),
            'scope_type' => $data['scope_type'],
            'scope_label' => Arr::get($data, 'scope_label'),
            'started_at' => $data['started_at'],
            'ended_at' => Arr::get($data, 'ended_at'),
            'status' => $data['status'],
            'notes' => Arr::get($data, 'notes'),
        ];
    }
}
