<?php
namespace App\Services\Operations;
use App\Models\ServiceCategory;
use Illuminate\Support\Str;
class ServiceCategoryService
{
    public function create(array $data): ServiceCategory
    {
        return ServiceCategory::create(['name' => $data['name'],'slug' => Str::slug($data['name']),'description' => $data['description'] ?? null,'is_active' => (bool) ($data['is_active'] ?? true)]);
    }
    public function update(ServiceCategory $category, array $data): ServiceCategory
    {
        $category->update(['name' => $data['name'],'slug' => Str::slug($data['name']),'description' => $data['description'] ?? null,'is_active' => (bool) ($data['is_active'] ?? true)]);
        return $category->refresh();
    }
}
