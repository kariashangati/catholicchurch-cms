<?php
namespace App\Services\Operations;
use App\Models\ChurchAsset;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
class ChurchAssetService
{
    public function create(array $data): ChurchAsset
    {
        return ChurchAsset::create($this->payload($data));
    }
    public function update(ChurchAsset $asset, array $data): ChurchAsset
    {
        $asset->update($this->payload($data, $asset));
        return $asset->refresh();
    }
    protected function payload(array $data, ?ChurchAsset $asset = null): array
    {
        $documentPath = $asset?->document_path;
        if (($data['document'] ?? null) instanceof UploadedFile) {
            if ($documentPath) { Storage::disk('public')->delete($documentPath); }
            $documentPath = $data['document']->store('church-assets', 'public');
        }
        return ['asset_category_id' => $data['asset_category_id'],'name' => $data['name'],'asset_code' => $data['asset_code'] ?? null,'registration_number' => $data['registration_number'] ?? null,'acquisition_cost' => $data['acquisition_cost'] ?? null,'current_value' => $data['current_value'] ?? null,'acquisition_date' => $data['acquisition_date'] ?? null,'condition_status' => $data['condition_status'],'location' => $data['location'] ?? null,'document_path' => $documentPath,'notes' => $data['notes'] ?? null,'is_active' => (bool) ($data['is_active'] ?? true)];
    }
}
