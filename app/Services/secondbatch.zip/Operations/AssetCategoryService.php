<?php
namespace App\Services\Operations;
use App\Models\AssetCategory;
use Illuminate\Support\Str;
class AssetCategoryService
{
    public function create(array $data): AssetCategory
    {
        return AssetCategory::create(['name' => $data['name'],'slug' => Str::slug($data['name']),'description' => $data['description'] ?? null,'is_active' => (bool) ($data['is_active'] ?? true)]);
    }
    public function update(AssetCategory $category, array $data): AssetCategory
    {
        $category->update(['name' => $data['name'],'slug' => Str::slug($data['name']),'description' => $data['description'] ?? null,'is_active' => (bool) ($data['is_active'] ?? true)]);
        return $category->refresh();
    }
}
