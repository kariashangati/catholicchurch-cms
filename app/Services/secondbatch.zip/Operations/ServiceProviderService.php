<?php
namespace App\Services\Operations;
use App\Models\ServiceProvider;
use Illuminate\Validation\ValidationException;
class ServiceProviderService
{
    public function create(array $data): ServiceProvider
    {
        $this->ensureUniqueCombination($data);
        return ServiceProvider::create($this->payload($data));
    }
    public function update(ServiceProvider $provider, array $data): ServiceProvider
    {
        $this->ensureUniqueCombination($data, $provider->id);
        $provider->update($this->payload($data));
        return $provider->refresh();
    }
    protected function payload(array $data): array
    {
        return ['service_category_id' => $data['service_category_id'],'member_id' => $data['member_id'] ?? null,'name' => $data['name'],'phone' => $data['phone'],'email' => $data['email'] ?? null,'address' => $data['address'],'notes' => $data['notes'] ?? null,'status' => $data['status'],'is_internal' => (bool) ($data['is_internal'] ?? false),'is_active' => (bool) ($data['is_active'] ?? true)];
    }
    protected function ensureUniqueCombination(array $data, ?int $ignoreId = null): void
    {
        $query = ServiceProvider::query()->where('service_category_id', $data['service_category_id'])->whereRaw('LOWER(name) = ?', [mb_strtolower($data['name'])]);
        if ($ignoreId) { $query->whereKeyNot($ignoreId); }
        if ($query->exists()) {
            throw ValidationException::withMessages(['name' => db_trans('service_provider_category_name_taken')]);
        }
    }
}
