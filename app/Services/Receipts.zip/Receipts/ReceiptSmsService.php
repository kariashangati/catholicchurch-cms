<?php

namespace App\Services\Receipts;

use App\Models\ReceiptIssue;
use Illuminate\Support\Str;

class ReceiptSmsService
{
    public function send(ReceiptIssue $receipt, string $phone, ?string $customMessage = null): void
    {
        $message = $customMessage ?: $this->buildMessage($receipt);

        // Integrate your Beem Africa SMS service here.
        // Example:
        // app(BeemSmsService::class)->send($phone, $message);

        // Placeholder to keep phase structure ready.
        if (blank($phone)) {
            throw new \InvalidArgumentException('Phone number is required.');
        }
    }

    public function buildMessage(ReceiptIssue $receipt): string
    {
        $link = route('receipt.access', ['token' => $receipt->access_token]);

        return trim(sprintf(
            '%s %s. %s: %s',
            db_trans('receipts.sms.ready_prefix'),
            $receipt->receipt_no,
            db_trans('receipts.sms.access_link'),
            Str::limit($link, 250, '')
        ));
    }
}
