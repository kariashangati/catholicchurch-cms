<?php

namespace App\Services\Receipts;

use App\Models\ReceiptAccessLog;
use App\Models\ReceiptIssue;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class ReceiptAccessService
{
    public function resolveAccessContext(string $token, Request $request): array
    {
        $receipt = $this->findValidReceiptByToken($token);

        $this->logAccess($receipt, 'opened', $request);

        $receipt->forceFill([
            'first_opened_at' => $receipt->first_opened_at ?? now(),
            'last_opened_at' => now(),
        ])->save();

        return [
            'receipt' => $receipt,
            'access_meta' => [
                'opened_at' => now(),
                'ip_address' => $request->ip(),
            ],
        ];
    }

    public function resolveDownloadContext(string $token, Request $request): array
    {
        $receipt = $this->findValidReceiptByToken($token);

        $this->logAccess($receipt, 'downloaded', $request);

        $receipt->forceFill([
            'first_downloaded_at' => $receipt->first_downloaded_at ?? now(),
            'last_downloaded_at' => now(),
            'download_count' => (int) ($receipt->download_count ?? 0) + 1,
        ])->save();

        return ['receipt' => $receipt];
    }

    protected function findValidReceiptByToken(string $token): ReceiptIssue
    {
        $receipt = ReceiptIssue::query()
            ->where('access_token', $token)
            ->first();

        if (!$receipt) {
            throw ValidationException::withMessages([
                'token' => db_trans('receipts.messages.invalid_access_link'),
            ]);
        }

        if ($receipt->access_expires_at && now()->greaterThan($receipt->access_expires_at)) {
            throw ValidationException::withMessages([
                'token' => db_trans('receipts.messages.access_link_expired'),
            ]);
        }

        return $receipt;
    }

    protected function logAccess(ReceiptIssue $receipt, string $event, Request $request): void
    {
        if (!class_exists(ReceiptAccessLog::class)) {
            return;
        }

        ReceiptAccessLog::query()->create([
            'receipt_issue_id' => $receipt->getKey(),
            'event' => $event,
            'ip_address' => $request->ip(),
            'user_agent' => (string) $request->userAgent(),
            'accessed_at' => now(),
        ]);
    }
}
