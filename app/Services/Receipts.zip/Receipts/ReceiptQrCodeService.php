<?php

namespace App\Services\Receipts;

use App\Models\ReceiptIssue;

class ReceiptQrCodeService
{
    public function verificationUrl(ReceiptIssue $receipt): string
    {
        $token = $receipt->verification_token
            ?? $receipt->verification_code
            ?? $receipt->access_token
            ?? $receipt->receipt_no;

        return route('receipt.verify', ['token' => $token]);
    }

    public function svg(ReceiptIssue $receipt): string
    {
        $url = e($this->verificationUrl($receipt));

        // Placeholder SVG for phase structure. Replace with a real QR generator package later.
        return <<<SVG
<svg xmlns="http://www.w3.org/2000/svg" width="140" height="140" viewBox="0 0 140 140" role="img" aria-label="Receipt verification QR">
    <rect width="140" height="140" fill="#ffffff"/>
    <rect x="8" y="8" width="124" height="124" fill="#f8fafc" stroke="#111827" stroke-width="2"/>
    <rect x="18" y="18" width="24" height="24" fill="#111827"/>
    <rect x="98" y="18" width="24" height="24" fill="#111827"/>
    <rect x="18" y="98" width="24" height="24" fill="#111827"/>
    <rect x="56" y="20" width="10" height="10" fill="#111827"/>
    <rect x="70" y="20" width="10" height="10" fill="#111827"/>
    <rect x="56" y="34" width="10" height="10" fill="#111827"/>
    <rect x="70" y="34" width="10" height="10" fill="#111827"/>
    <rect x="52" y="56" width="36" height="10" fill="#111827"/>
    <rect x="52" y="72" width="20" height="10" fill="#111827"/>
    <rect x="78" y="72" width="10" height="10" fill="#111827"/>
    <rect x="52" y="88" width="10" height="10" fill="#111827"/>
    <rect x="68" y="88" width="20" height="10" fill="#111827"/>
    <text x="70" y="132" text-anchor="middle" font-size="7" fill="#334155">{$url}</text>
</svg>
SVG;
    }
}
