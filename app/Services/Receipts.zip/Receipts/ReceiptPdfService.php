<?php

namespace App\Services\Receipts;

use App\Models\ReceiptActionLog;
use App\Models\ReceiptIssue;
use Barryvdh\DomPDF\Facade\Pdf;
use Symfony\Component\HttpFoundation\Response;

class ReceiptPdfService
{
    public function __construct(
        protected ReceiptViewBuilder $receiptViewBuilder,
    ) {
    }

    public function downloadIssuedReceipt(ReceiptIssue $receipt): Response
    {
        $viewData = $this->receiptViewBuilder->buildPdfViewData($receipt);
        $view = $this->resolveTemplate($receipt);

        $pdf = Pdf::loadView($view, $viewData);

        $receipt->forceFill([
            'printed_at' => $receipt->printed_at ?? now(),
            'last_printed_at' => now(),
            'print_count' => (int) $receipt->print_count + 1,
        ])->save();

        ReceiptActionLog::query()->create([
            'receipt_issue_id' => $receipt->id,
            'action' => 'pdf_downloaded_internal',
            'description' => db_trans('receipts.logs.pdf_downloaded_internal'),
            'performed_by' => auth()->id(),
            'meta' => [
                'print_count' => $receipt->print_count,
            ],
        ]);

        return $pdf->download($receipt->receipt_no . '.pdf');
    }

    protected function resolveTemplate(ReceiptIssue $receipt): string
    {
        return match ($receipt->receipt_layout) {
            'jumuiya_summary' => 'admin.finance.receipts.pdf.jumuiya_summary',
            'kanda_summary' => 'admin.finance.receipts.pdf.kanda_summary',
            default => 'admin.finance.receipts.pdf.individual',
        };
    }
}
