<?php

namespace App\Services\Receipts;

use App\Models\ReceiptIssue;
use Carbon\CarbonInterface;
use Illuminate\Support\Str;

class ReceiptNumberService
{
    public function generate(string $receiptType, ?CarbonInterface $date = null): string
    {
        return $this->buildNumber($receiptType, $date);
    }

    public function previewNumber(string $receiptType, ?CarbonInterface $date = null): string
    {
        return $this->buildNumber($receiptType, $date);
    }

    public function next(string $receiptType, ?CarbonInterface $date = null): string
    {
        return $this->buildNumber($receiptType, $date);
    }

    public function verificationCode(): string
    {
        return Str::upper(Str::random(10));
    }

    public function accessToken(): string
    {
        return Str::random(64);
    }

    protected function buildNumber(string $receiptType, ?CarbonInterface $date = null): string
    {
        $date ??= now();

        $prefix = 'RCT';
        $typeSegment = Str::upper(Str::limit(str_replace('_', '-', $receiptType), 8, ''));
        $year = $date->format('Y');

        $sequence = ReceiptIssue::query()
            ->whereYear('issued_at', $year)
            ->where('receipt_type', $receiptType)
            ->count() + 1;

        return sprintf('%s-%s-%s-%06d', $prefix, $typeSegment, $year, $sequence);
    }
}