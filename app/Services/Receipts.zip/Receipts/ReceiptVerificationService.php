<?php

namespace App\Services\Receipts;

use App\Models\ReceiptIssue;
use App\Models\ReceiptVerificationLog;

class ReceiptVerificationService
{
    public function verifyByToken(string $token, array $context = []): array
    {
        $receipt = ReceiptIssue::query()
            ->where('verification_token', $token)
            ->orWhere('access_token', $token)
            ->first();

        return $this->buildVerificationResult($receipt, $context, 'token');
    }

    public function verifyByReference(?string $receiptNo = null, ?string $verificationCode = null, array $context = []): array
    {
        $query = ReceiptIssue::query();

        if (filled($receiptNo)) {
            $query->where('receipt_no', $receiptNo);
        }

        if (filled($verificationCode)) {
            $query->where('verification_code', $verificationCode);
        }

        $receipt = $query->first();

        return $this->buildVerificationResult($receipt, $context, 'manual');
    }

    protected function buildVerificationResult(?ReceiptIssue $receipt, array $context = [], string $channel = 'manual'): array
    {
        if (!$receipt) {
            $this->log(null, 'not_found', $channel, $context);

            return [
                'valid' => false,
                'status' => 'not_found',
                'message' => db_trans('receipts.verification.not_found'),
                'receipt' => null,
            ];
        }

        $status = $this->mapReceiptStatus($receipt);
        $valid = in_array($status, ['valid', 'reissued'], true);

        $this->log($receipt, $status, $channel, $context);

        return [
            'valid' => $valid,
            'status' => $status,
            'message' => db_trans('receipts.verification.status_' . $status),
            'receipt' => $receipt,
        ];
    }

    protected function mapReceiptStatus(ReceiptIssue $receipt): string
    {
        $status = (string) ($receipt->status ?? 'issued');

        if (in_array($status, ['void', 'voided', 'cancelled'], true)) {
            return 'voided';
        }

        if ((int) ($receipt->reissue_count ?? 0) > 0 || !empty($receipt->reissued_at)) {
            return 'reissued';
        }

        return 'valid';
    }

    protected function log(?ReceiptIssue $receipt, string $result, string $channel, array $context = []): void
    {
        if (!class_exists(ReceiptVerificationLog::class)) {
            return;
        }

        ReceiptVerificationLog::query()->create([
            'receipt_issue_id' => $receipt?->getKey(),
            'result' => $result,
            'channel' => $channel,
            'ip_address' => $context['ip_address'] ?? null,
            'user_agent' => $context['user_agent'] ?? null,
            'verified_at' => now(),
        ]);
    }
}
