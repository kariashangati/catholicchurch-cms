<?php

namespace App\Services\Receipts;

use App\Models\ReceiptExceptionLog;
use App\Models\ReceiptIssue;
use App\Support\Receipts\ReceiptStatuses;
use Illuminate\Contracts\Auth\Authenticatable;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Collection;

class ReceiptQueryService
{
    public function dashboardSummary(?Authenticatable $user = null): array
    {
        $base = $this->scopedQuery($user);

        return [
            'issued_today' => (clone $base)->whereDate('issued_at', today())->count(),
            'issued_this_month' => (clone $base)->whereBetween('issued_at', [now()->startOfMonth(), now()->endOfMonth()])->count(),
            'pending_count' => (clone $base)->where('status', ReceiptStatuses::PENDING_ISSUE)->count(),
            'downloaded_count' => (clone $base)->whereNotNull('first_downloaded_at')->count(),
        ];
    }

    public function recentReceipts(?Authenticatable $user = null, int $limit = 10): Collection
    {
        return $this->scopedQuery($user)
            ->latest('issued_at')
            ->limit($limit)
            ->get();
    }

    public function pendingSummary(?Authenticatable $user = null): array
    {
        return [
            'pending_issue' => $this->scopedQuery($user)->where('status', ReceiptStatuses::PENDING_ISSUE)->count(),
            'exceptions' => $this->scopedQuery($user)->where('status', ReceiptStatuses::EXCEPTION)->count(),
        ];
    }

public function issueFormOptions(?Authenticatable $user = null): array
{
    return [
        'source_types' => [
            'tithe' => db_trans('receipts.types.tithe'),
            'cash_contribution' => db_trans('receipts.types.cash_contribution'),
            'bank_contribution' => db_trans('receipts.types.bank_contribution'),
            'offering' => db_trans('receipts.types.offering'),
            'project_contribution' => db_trans('receipts.types.project_contribution'),
            'group_summary' => db_trans('receipts.types.group_summary'),
        ],

        'members' => \App\Models\Member::query()
            ->orderBy('first_name')
            ->get()
            ->mapWithKeys(fn ($member) => [$member->id => $member->full_name])
            ->all(),

        'familias' => \App\Models\Familia::query()
            ->orderBy('name')
            ->pluck('name', 'id')
            ->all(),

        'jumuiyas' => \App\Models\Jumuiya::query()
            ->orderBy('name')
            ->pluck('name', 'id')
            ->all(),

        'kandas' => \App\Models\Kanda::query()
            ->orderBy('name')
            ->pluck('name', 'id')
            ->all(),

        'contribution_types' => \App\Models\ContributionType::query()
            ->orderBy('name')
            ->pluck('name', 'id')
            ->all(),
    ];
}

    public function history(array $filters, ?Authenticatable $user = null): LengthAwarePaginator
    {
        return $this->applyHistoryFilters($this->scopedQuery($user), $filters)
            ->latest('issued_at')
            ->paginate($filters['per_page'] ?? 20)
            ->withQueryString();
    }

    public function timeline(ReceiptIssue $receipt): array
    {
        return [
            'issued_at' => $receipt->issued_at,
            'printed_at' => $receipt->printed_at,
            'sms_sent_at' => $receipt->sms_sent_at,
            'first_opened_at' => $receipt->first_opened_at,
            'first_downloaded_at' => $receipt->first_downloaded_at,
        ];
    }

    public function pending(array $filters, ?Authenticatable $user = null): LengthAwarePaginator
    {
        return $this->scopedQuery($user)
            ->where('status', ReceiptStatuses::PENDING_ISSUE)
            ->latest('created_at')
            ->paginate($filters['per_page'] ?? 20)
            ->withQueryString();
    }

    public function pendingCounts(array $filters, ?Authenticatable $user = null): array
    {
        $base = $this->scopedQuery($user)->where('status', ReceiptStatuses::PENDING_ISSUE);

        return [
            'all' => (clone $base)->count(),
            'tithes' => (clone $base)->where('receipt_type', 'tithe')->count(),
            'contributions' => (clone $base)->whereIn('receipt_type', ['cash_contribution', 'bank_contribution', 'project_contribution'])->count(),
        ];
    }

    public function exceptions(?Authenticatable $user = null, int $perPage = 20): LengthAwarePaginator
    {
        return ReceiptExceptionLog::query()
            ->with(['receiptIssue'])
            ->latest('happened_at')
            ->latest('id')
            ->paginate($perPage);
    }

    protected function scopedQuery(?Authenticatable $user = null): Builder
    {
        return ReceiptIssue::query()->with(['member', 'jumuiya', 'kanda', 'issuedBy']);
    }

    protected function applyHistoryFilters(Builder $query, array $filters): Builder
    {
        return $query
            ->when($filters['receipt_no'] ?? null, fn (Builder $q, $value) => $q->where('receipt_no', 'like', "%{$value}%"))
            ->when($filters['status'] ?? null, fn (Builder $q, $value) => $q->where('status', $value))
            ->when($filters['receipt_type'] ?? null, fn (Builder $q, $value) => $q->where('receipt_type', $value))
            ->when($filters['member_id'] ?? null, fn (Builder $q, $value) => $q->where('member_id', $value))
            ->when($filters['date_from'] ?? null, fn (Builder $q, $value) => $q->whereDate('issued_at', '>=', $value))
            ->when($filters['date_to'] ?? null, fn (Builder $q, $value) => $q->whereDate('issued_at', '<=', $value));
    }
}