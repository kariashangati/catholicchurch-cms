<?php

namespace App\Services\Finance;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Foundation\Auth\User;

class ContributionAccessService
{
    public function applyMemberScope(Builder $query, User $user): Builder
    {
        if ($user->can('finance.contributions.view-all')) {
            return $query;
        }

        $memberId = data_get($user, 'member_id')
            ?? data_get($user, 'mwanajumuiya_id')
            ?? data_get($user, 'member.id');

        $jumuiyaId = data_get($user, 'jumuiya_id')
            ?? data_get($user, 'member.familia.jumuiya_id');

        $kandaId = data_get($user, 'kanda_id')
            ?? data_get($user, 'member.familia.jumuiya.kanda_id');

        if ($user->can('finance.contributions.view-kanda') && $kandaId) {
            $query->where('kanda_id', $kandaId);
            return $query;
        }

        if ($user->can('finance.contributions.view-jumuiya') && $jumuiyaId) {
            $query->where('jumuiya_id', $jumuiyaId);
            return $query;
        }

        if ($memberId) {
            $query->where('member_id', $memberId);
        }

        return $query;
    }
}
