<?php

namespace App\Services\Finance;

use App\Models\BankContribution;
use App\Models\CashContribution;
use App\Models\ContributionType;
use App\Models\Jumuiya;
use App\Models\Kanda;
use App\Models\Member;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Pagination\LengthAwarePaginator;

class ContributionComplianceService
{
    public function __construct(protected ReportScopeService $scope)
    {
    }

    public function getPageData(User $user, array $filters): array
    {
        $year = (int) ($filters['year'] ?? now()->year);
        $month = !empty($filters['month']) ? (int) $filters['month'] : null;
        $status = $filters['payment_status'] ?? 'all';
        $source = $filters['source'] ?? 'all';

        $types = ContributionType::query()->where('is_active', true)->orderBy('name')->get();
        $kandas = Kanda::query()->orderBy('name')->get();
        $jumuiyas = Jumuiya::query()->orderBy('name')->get();

        $members = $this->scope->scopedMembers($user)
            ->where('is_active', true)
            ->when(!empty($filters['kanda_id']), fn ($q) => $q->whereHas('familia.jumuiya', fn ($b) => $b->where('kanda_id', $filters['kanda_id'])))
            ->when(!empty($filters['jumuiya_id']), fn ($q) => $q->whereHas('familia', fn ($b) => $b->where('jumuiya_id', $filters['jumuiya_id'])))
            ->when(!empty($filters['search']), function ($q) use ($filters) {
                $search = trim((string) $filters['search']);
                $q->where(function ($builder) use ($search) {
                    $builder->where('first_name', 'like', "%{$search}%")
                        ->orWhere('middle_name', 'like', "%{$search}%")
                        ->orWhere('last_name', 'like', "%{$search}%")
                        ->orWhere('member_code', 'like', "%{$search}%")
                        ->orWhere('bahasha', 'like', "%{$search}%");
                });
            })
            ->orderBy('first_name')
            ->get();

        $memberIds = $members->pluck('id');
        $typeId = $filters['contribution_type_id'] ?? null;

        $cash = CashContribution::query()
            ->whereIn('member_id', $memberIds)
            ->when($typeId, fn ($q) => $q->where('contribution_type_id', $typeId))
            ->whereYear('contribution_date', $year)
            ->when($month, fn ($q) => $q->whereMonth('contribution_date', $month))
            ->selectRaw('member_id, SUM(amount) total_amount, MAX(contribution_date) last_date')
            ->groupBy('member_id')
            ->get()->keyBy('member_id');

        $bank = BankContribution::query()
            ->whereIn('member_id', $memberIds)
            ->when($typeId, fn ($q) => $q->where('contribution_type_id', $typeId))
            ->whereYear('contribution_date', $year)
            ->when($month, fn ($q) => $q->whereMonth('contribution_date', $month))
            ->selectRaw('member_id, SUM(amount) total_amount, MAX(contribution_date) last_date')
            ->groupBy('member_id')
            ->get()->keyBy('member_id');

        $selectedType = $typeId ? $types->firstWhere('id', (int) $typeId) : null;
        $expected = (float) ($selectedType?->plan?->target_amount ?? 0);
        $installments = max(1, (int) ($selectedType?->plan?->installments_count ?? 1));

        $rows = $members->map(function (Member $member) use ($cash, $bank, $expected, $installments, $month) {
            $cashAmount = (float) data_get($cash, $member->id . '.total_amount', 0);
            $bankAmount = (float) data_get($bank, $member->id . '.total_amount', 0);
            $paid = $cashAmount + $bankAmount;
            $expectedAmount = $expected > 0 ? ($month ? round($expected / $installments, 2) : $expected) : 0;

            $paymentStatus = 'unpaid';
            if ($paid > 0 && $expectedAmount > 0 && $paid < $expectedAmount) {
                $paymentStatus = 'partial';
            } elseif ($paid > 0) {
                $paymentStatus = 'paid';
            }

            $paymentSource = 'all';
            if ($cashAmount > 0 && $bankAmount > 0) {
                $paymentSource = 'mixed';
            } elseif ($cashAmount > 0) {
                $paymentSource = 'cash';
            } elseif ($bankAmount > 0) {
                $paymentSource = 'bank';
            }

            $lastPaidAt = collect([data_get($cash, $member->id . '.last_date'), data_get($bank, $member->id . '.last_date')])
                ->filter()->map(fn ($date) => Carbon::parse($date))->sortDesc()->first();

            return [
                'member' => $member,
                'expected_amount' => $expectedAmount,
                'paid_amount' => $paid,
                'status' => $paymentStatus,
                'source' => $paymentSource,
                'last_paid_at' => $lastPaidAt,
            ];
        });

        if ($status !== 'all') {
            $rows = $rows->where('status', $status)->values();
        }
        if ($source !== 'all') {
            $rows = $rows->where('source', $source)->values();
        }

        $page = request()->integer('page', 1);
        $perPage = 50;
        $paginated = new LengthAwarePaginator($rows->forPage($page, $perPage)->values(), $rows->count(), $perPage, $page, [
            'path' => request()->url(),
            'query' => request()->query(),
        ]);

        return [
            'filters' => [
                'year' => $year,
                'month' => $month,
                'contribution_type_id' => $typeId,
                'kanda_id' => $filters['kanda_id'] ?? null,
                'jumuiya_id' => $filters['jumuiya_id'] ?? null,
                'payment_status' => $status,
                'source' => $source,
                'search' => $filters['search'] ?? null,
            ],
            'types' => $types,
            'kandas' => $kandas,
            'jumuiyas' => $jumuiyas,
            'selectedType' => $selectedType,
            'rows' => $paginated,
            'stats' => [
                'members_total' => $rows->count(),
                'paid_members' => $rows->where('status', 'paid')->count(),
                'partial_members' => $rows->where('status', 'partial')->count(),
                'unpaid_members' => $rows->where('status', 'unpaid')->count(),
                'paid_total' => (float) $rows->sum('paid_amount'),
            ],
        ];
    }
}
