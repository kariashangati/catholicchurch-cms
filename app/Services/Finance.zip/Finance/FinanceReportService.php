<?php

namespace App\Services\Finance;

use App\Models\BankContribution;
use App\Models\BudgetExpenseEstimate;
use App\Models\BudgetIncomeEstimate;
use App\Models\CashContribution;
use App\Models\Offering;
use App\Models\Tithe;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Support\Collection;

class FinanceReportService
{
    public function __construct(protected ReportScopeService $scope)
    {
    }

    public function getFinancialSummary(User $user, int $year): array
    {
        $income = $this->incomeBreakdown($user, $year);
        $expense = $this->expenseBreakdown($year);

        return [
            'year' => $year,
            'income' => $income,
            'expense' => $expense,
            'totals' => [
                'income' => $income->sum('amount'),
                'expense' => $expense->sum('amount'),
                'balance' => $income->sum('amount') - $expense->sum('amount'),
            ],
            'budget' => [
                'income_budget' => (float) BudgetIncomeEstimate::query()->where('budget_year', $year)->sum('amount'),
                'expense_budget' => (float) BudgetExpenseEstimate::query()->where('budget_year', $year)->sum('amount'),
            ],
            'monthly' => collect(range(1, 12))->map(function (int $month) use ($user, $year) {
                return [
                    'month' => Carbon::create()->month($month)->format('M'),
                    'income' => $this->incomeForMonth($user, $year, $month),
                    'expense' => round((float) BudgetExpenseEstimate::query()->where('budget_year', $year)->sum('amount') / 12, 2),
                ];
            })->map(function (array $row) {
                $row['balance'] = round($row['income'] - $row['expense'], 2);
                return $row;
            }),
        ];
    }

    public function incomeBreakdown(User $user, int $year): Collection
    {
        $tithe = Tithe::query()->whereYear('contribution_date', $year);
        $this->scope->applyTitheScope($tithe, $user);

        $offering = Offering::query()->whereYear('collection_date', $year);
        $this->scope->applyOfferingScope($offering, $user);

        $cash = CashContribution::query()->whereYear('contribution_date', $year);
        $bank = BankContribution::query()->whereYear('contribution_date', $year);
        $this->scope->applyMemberScope($cash, $user);
        $this->scope->applyMemberScope($bank, $user);

        return collect([
            ['label' => db_trans('tithes'), 'amount' => (float) $tithe->sum('amount'), 'route' => route('finance.tithes.index')],
            ['label' => db_trans('offerings'), 'amount' => (float) $offering->sum('amount'), 'route' => route('finance.offerings.index')],
            ['label' => db_trans('cash_contributions'), 'amount' => (float) $cash->sum('amount'), 'route' => route('finance.contributions.cash.index')],
            ['label' => db_trans('bank_contributions'), 'amount' => (float) $bank->sum('amount'), 'route' => route('finance.contributions.bank.index')],
        ]);
    }

    public function expenseBreakdown(int $year): Collection
    {
        $rows = BudgetExpenseEstimate::query()
            ->where('budget_year', $year)
            ->selectRaw('category_group, SUM(amount) amount')
            ->groupBy('category_group')
            ->get();

        return $rows->isNotEmpty() ? $rows->map(fn ($row) => [
            'label' => $row->category_group === 'development' ? db_trans('development') : db_trans('ordinary'),
            'amount' => (float) $row->amount,
            'route' => route('finance.budgets.expense.index', ['year' => $year]),
        ]) : collect([
            ['label' => db_trans('ordinary'), 'amount' => 0, 'route' => route('finance.budgets.expense.index', ['year' => $year])],
            ['label' => db_trans('development'), 'amount' => 0, 'route' => route('finance.budgets.expense.index', ['year' => $year])],
        ]);
    }

    protected function incomeForMonth(User $user, int $year, int $month): float
    {
        $tithe = Tithe::query()->whereYear('contribution_date', $year)->whereMonth('contribution_date', $month);
        $this->scope->applyTitheScope($tithe, $user);

        $offering = Offering::query()->whereYear('collection_date', $year)->whereMonth('collection_date', $month);
        $this->scope->applyOfferingScope($offering, $user);

        $cash = CashContribution::query()->whereYear('contribution_date', $year)->whereMonth('contribution_date', $month);
        $bank = BankContribution::query()->whereYear('contribution_date', $year)->whereMonth('contribution_date', $month);
        $this->scope->applyMemberScope($cash, $user);
        $this->scope->applyMemberScope($bank, $user);

        return (float) $tithe->sum('amount') + (float) $offering->sum('amount') + (float) $cash->sum('amount') + (float) $bank->sum('amount');
    }
}
