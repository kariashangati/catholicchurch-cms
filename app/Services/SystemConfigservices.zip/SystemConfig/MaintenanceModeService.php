<?php

namespace App\Services\SystemConfig;

use Illuminate\Support\Facades\Artisan;
use Illuminate\Support\Facades\App;

class MaintenanceModeService
{
    public function __construct(
        protected SiteSettingsService $siteSettingsService
    ) {
    }

    public function isGloballyEnabled(): bool
    {
        return App::isDownForMaintenance()
            || (bool) $this->siteSettingsService->get('maintenance.global.enabled', false);
    }

    public function globalSettings(): array
    {
        return [
            'enabled' => (bool) $this->siteSettingsService->get('maintenance.global.enabled', false),
            'title' => $this->siteSettingsService->get('maintenance.global.title', 'Maintenance Mode'),
            'message' => $this->siteSettingsService->get('maintenance.global.message', 'The system is currently under maintenance.'),
        ];
    }

    public function enableGlobal(string $title, string $message, bool $useLaravelDown = false): void
    {
        $this->siteSettingsService->set('maintenance.global.enabled', true, 'boolean', 'maintenance');
        $this->siteSettingsService->set('maintenance.global.title', $title, 'string', 'maintenance');
        $this->siteSettingsService->set('maintenance.global.message', $message, 'string', 'maintenance');

        if ($useLaravelDown && ! App::isDownForMaintenance()) {
            Artisan::call('down');
        }
    }

    public function disableGlobal(bool $useLaravelUp = false): void
    {
        $this->siteSettingsService->set('maintenance.global.enabled', false, 'boolean', 'maintenance');

        if ($useLaravelUp && App::isDownForMaintenance()) {
            Artisan::call('up');
        }
    }

    public function setRouteMaintenance(string $routeName, bool $enabled, ?string $title = null, ?string $message = null): void
    {
        $base = "maintenance.routes.{$routeName}";

        $this->siteSettingsService->set("{$base}.enabled", $enabled, 'boolean', 'maintenance');
        $this->siteSettingsService->set("{$base}.title", $title, 'string', 'maintenance');
        $this->siteSettingsService->set("{$base}.message", $message, 'string', 'maintenance');
    }

    public function routeSettings(string $routeName): array
    {
        $base = "maintenance.routes.{$routeName}";

        return [
            'enabled' => (bool) $this->siteSettingsService->get("{$base}.enabled", false),
            'title' => $this->siteSettingsService->get("{$base}.title", 'Maintenance Mode'),
            'message' => $this->siteSettingsService->get("{$base}.message", 'This page is under maintenance.'),
        ];
    }

    public function isRouteBlocked(?string $routeName): bool
    {
        if (blank($routeName)) {
            return false;
        }

        return (bool) $this->siteSettingsService->get("maintenance.routes.{$routeName}.enabled", false);
    }
}