<?php

namespace App\Services\Reports;

use App\Models\BankContribution;
use App\Models\BudgetEstimateExpense;
use App\Models\BudgetEstimateIncome;
use App\Models\CashContribution;
use App\Models\Offering;
use App\Models\ProjectTransaction;
use App\Models\Tithe;
use App\Models\User;
use Illuminate\Support\Collection;

class BudgetEstimateService
{
    public function dashboardData(int $year): array
    {
        $incomeBudgets = BudgetEstimateIncome::query()->where('budget_year', $year)->orderBy('category_name')->get();
        $expenseBudgets = BudgetEstimateExpense::query()->where('budget_year', $year)->orderBy('category_name')->get();

        $incomeRows = $incomeBudgets->map(function (BudgetEstimateIncome $item) use ($year) {
            $actual = $this->actualIncomeForCategory($item->category_code, $year);
            return [
                'id' => $item->id,
                'category_code' => $item->category_code,
                'category_name' => $item->category_name,
                'group_name' => $item->group_name,
                'budget_amount' => (float) $item->amount,
                'actual_amount' => $actual,
                'variance' => $actual - (float) $item->amount,
                'notes' => $item->notes,
            ];
        });

        $expenseRows = $expenseBudgets->map(function (BudgetEstimateExpense $item) use ($year) {
            $actual = $this->actualExpenseForCategory($item->category_code, $year);
            return [
                'id' => $item->id,
                'category_code' => $item->category_code,
                'category_name' => $item->category_name,
                'group_name' => $item->group_name,
                'budget_amount' => (float) $item->amount,
                'actual_amount' => $actual,
                'variance' => $actual - (float) $item->amount,
                'notes' => $item->notes,
            ];
        });

        return [
            'pageTitle' => db_trans('budget_vs_actual'),
            'year' => $year,
            'incomeRows' => $incomeRows,
            'expenseRows' => $expenseRows,
            'incomeBudgetTotal' => $incomeRows->sum('budget_amount'),
            'incomeActualTotal' => $incomeRows->sum('actual_amount'),
            'expenseBudgetTotal' => $expenseRows->sum('budget_amount'),
            'expenseActualTotal' => $expenseRows->sum('actual_amount'),
            'availableYears' => collect(range(now()->year + 1, now()->year - 5))->sortDesc()->values(),
        ];
    }

    public function createIncome(array $data, User $user): BudgetEstimateIncome
    {
        $data['created_by'] = $user->id;
        $data['updated_by'] = $user->id;
        $data['is_active'] = (bool) ($data['is_active'] ?? true);
        return BudgetEstimateIncome::create($data);
    }

    public function updateIncome(BudgetEstimateIncome $budgetEstimateIncome, array $data, User $user): BudgetEstimateIncome
    {
        $data['updated_by'] = $user->id;
        $budgetEstimateIncome->update($data);
        return $budgetEstimateIncome->refresh();
    }

    public function createExpense(array $data, User $user): BudgetEstimateExpense
    {
        $data['created_by'] = $user->id;
        $data['updated_by'] = $user->id;
        $data['is_active'] = (bool) ($data['is_active'] ?? true);
        return BudgetEstimateExpense::create($data);
    }

    public function updateExpense(BudgetEstimateExpense $budgetEstimateExpense, array $data, User $user): BudgetEstimateExpense
    {
        $data['updated_by'] = $user->id;
        $budgetEstimateExpense->update($data);
        return $budgetEstimateExpense->refresh();
    }

    protected function actualIncomeForCategory(?string $code, int $year): float
    {
        return match ($code) {
            'offerings' => (float) Offering::query()->whereYear('collection_date', $year)->where('status', Offering::STATUS_APPROVED)->sum('amount'),
            'tithes' => (float) Tithe::query()->whereYear('contribution_date', $year)->where('status', Tithe::STATUS_APPROVED)->sum('amount'),
            'cash_contributions' => (float) CashContribution::query()->whereYear('contribution_date', $year)->where('status', CashContribution::STATUS_APPROVED)->sum('amount'),
            'bank_contributions' => (float) BankContribution::query()->whereYear('contribution_date', $year)->where('status', BankContribution::STATUS_VERIFIED)->sum('amount'),
            'project_income' => (float) ProjectTransaction::query()->whereYear('transaction_date', $year)->where('transaction_type', ProjectTransaction::TYPE_INCOME)->where('status', ProjectTransaction::STATUS_APPROVED)->sum('amount'),
            default => 0.0,
        };
    }

    protected function actualExpenseForCategory(?string $code, int $year): float
    {
        return match ($code) {
            'project_expenses' => (float) ProjectTransaction::query()->whereYear('transaction_date', $year)->where('transaction_type', ProjectTransaction::TYPE_EXPENSE)->where('status', ProjectTransaction::STATUS_APPROVED)->sum('amount'),
            default => 0.0,
        };
    }
}
