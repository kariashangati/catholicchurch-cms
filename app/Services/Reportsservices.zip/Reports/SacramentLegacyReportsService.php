<?php

namespace App\Services\Reports;

use App\Models\Familia;
use App\Models\Jumuiya;
use App\Models\Kanda;
use App\Models\Member;
use App\Models\User;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class SacramentLegacyReportsService
{
    public function filtersData(): array
    {
        return [
            'kandas' => Kanda::query()->orderBy('name')->get(['id', 'name']),
            'jumuiyas' => Jumuiya::query()->orderBy('name')->get(['id', 'name', 'kanda_id']),
            'familias' => Familia::query()->orderBy('name')->get(['id', 'name', 'jumuiya_id', 'phone']),
            'memberFilters' => [
                'all', 'baptized', 'not_baptized', 'married', 'not_married', 'confirmed', 'not_confirmed',
                'communion', 'not_communion', 'eucharist', 'not_eucharist', 'male', 'female',
            ],
        ];
    }

    public function indexData(): array
    {
        return [
            'pageTitle' => db_trans('sacrament_reports'),
            'filterData' => $this->filtersData(),
        ];
    }

    public function generate(User $user, array $filters): array
    {
        $query = Member::query()->with(['familia.jumuiya.kanda']);
        $this->applyScope($query, $filters);
        $this->applyMemberFilter($query, $filters['member_filter'] ?? 'all');

        $members = $query->orderBy('first_name')->orderBy('last_name')->get();
        $scopeLevel = $filters['scope_level'];

        if ($scopeLevel === 'familia' && ! empty($filters['scope_id'])) {
            $familia = Familia::with('jumuiya.kanda')->findOrFail((int) $filters['scope_id']);

            return [
                'view' => 'admin.reports.sacraments.family-census',
                'data' => [
                    'pageTitle' => db_trans('family_sacrament_census'),
                    'filters' => $filters,
                    'familia' => $familia,
                    'parents' => $members->whereIn('family_role', ['Baba', 'Mama', 'Male Head', 'Female Head', 'Parent'])->values(),
                    'members' => $members,
                    'summary' => $this->summaryFromMembers($members),
                ],
            ];
        }

        return [
            'view' => 'admin.reports.sacraments.scope-summary',
            'data' => [
                'pageTitle' => db_trans('sacrament_scope_summary'),
                'filters' => $filters,
                'rows' => $this->groupedSummary($members, $scopeLevel),
                'summary' => $this->summaryFromMembers($members),
                'members' => $members,
            ],
        ];
    }

    protected function applyScope(Builder $query, array $filters): void
    {
        $scopeLevel = $filters['scope_level'] ?? 'parish';
        $scopeId = $filters['scope_id'] ?? null;

        if (! $scopeId || $scopeLevel === 'parish') {
            return;
        }

        if ($scopeLevel === 'familia') {
            $query->where('familia_id', (int) $scopeId);
        }

        if ($scopeLevel === 'jumuiya') {
            $query->whereHas('familia', fn (Builder $familiaQuery) => $familiaQuery->where('jumuiya_id', (int) $scopeId));
        }

        if ($scopeLevel === 'kanda') {
            $query->whereHas('familia.jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', (int) $scopeId));
        }
    }

    protected function applyMemberFilter(Builder $query, string $filter): void
    {
        match ($filter) {
            'baptized' => $query->where('is_baptized', true),
            'not_baptized' => $query->where('is_baptized', false),
            'married' => $query->where('is_married', true),
            'not_married' => $query->where('is_married', false),
            'confirmed' => $query->where('has_confirmation', true),
            'not_confirmed' => $query->where('has_confirmation', false),
            'communion' => $query->where('has_communion', true),
            'not_communion' => $query->where('has_communion', false),
            'eucharist' => $query->where('receives_eucharist', true),
            'not_eucharist' => $query->where('receives_eucharist', false),
            'male' => $query->whereRaw("LOWER(gender) = ?", ['male']),
            'female' => $query->whereRaw("LOWER(gender) = ?", ['female']),
            default => null,
        };
    }

    protected function summaryFromMembers(Collection $members): array
    {
        return [
            'members_total' => $members->count(),
            'baptized' => $members->where('is_baptized', true)->count(),
            'communion' => $members->where('has_communion', true)->count(),
            'confirmation' => $members->where('has_confirmation', true)->count(),
            'married' => $members->where('is_married', true)->count(),
            'receives_eucharist' => $members->where('receives_eucharist', true)->count(),
            'male' => $members->filter(fn ($member) => strtolower((string) $member->gender) === 'male')->count(),
            'female' => $members->filter(fn ($member) => strtolower((string) $member->gender) === 'female')->count(),
        ];
    }

    protected function groupedSummary(Collection $members, string $scopeLevel): Collection
    {
        return $members->groupBy(function (Member $member) use ($scopeLevel) {
            return match ($scopeLevel) {
                'kanda' => $member->familia?->jumuiya?->kanda?->name ?? 'Unknown',
                'jumuiya' => $member->familia?->jumuiya?->name ?? 'Unknown',
                'familia' => $member->familia?->name ?? 'Unknown',
                default => 'Parish',
            };
        })->map(function (Collection $group, string $name) {
            return [
                'name' => $name,
                'members_total' => $group->count(),
                'baptized' => $group->where('is_baptized', true)->count(),
                'communion' => $group->where('has_communion', true)->count(),
                'confirmation' => $group->where('has_confirmation', true)->count(),
                'married' => $group->where('is_married', true)->count(),
                'receives_eucharist' => $group->where('receives_eucharist', true)->count(),
                'male' => $group->filter(fn ($member) => strtolower((string) $member->gender) === 'male')->count(),
                'female' => $group->filter(fn ($member) => strtolower((string) $member->gender) === 'female')->count(),
            ];
        })->values();
    }
}
