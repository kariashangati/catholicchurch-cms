<?php

namespace App\Services\Reports;

use App\Models\BankContribution;
use App\Models\CashContribution;
use App\Models\ContributionType;
use App\Models\Jumuiya;
use App\Models\Kanda;
use App\Models\Member;
use App\Models\Offering;
use App\Models\ProjectTransaction;
use App\Models\Tithe;
use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class FinanceReportsService
{
    public function filtersData(): array
    {
        return [
            'kandas' => Kanda::query()->orderBy('name')->get(['id', 'name']),
            'jumuiyas' => Jumuiya::query()->orderBy('name')->get(['id', 'name', 'kanda_id']),
            'members' => Member::query()->orderBy('first_name')->orderBy('last_name')->get(['id', 'first_name', 'middle_name', 'last_name']),
            'contributionTypes' => ContributionType::query()->where('is_active', true)->orderBy('name')->get(['id', 'name']),
            'statuses' => [
                BankContribution::STATUS_PENDING,
                BankContribution::STATUS_VERIFIED,
                BankContribution::STATUS_REJECTED,
                CashContribution::STATUS_PENDING,
                CashContribution::STATUS_APPROVED,
                CashContribution::STATUS_REJECTED,
            ],
        ];
    }

    public function summary(User $user, array $filters = []): array
    {
        [$startDate, $endDate] = $this->resolveDateRange($filters);

        $offerings = $this->scopedOfferings($user, $filters, $startDate, $endDate);
        $tithes = $this->scopedTithes($user, $filters, $startDate, $endDate);
        $cash = $this->scopedCashContributions($user, $filters, $startDate, $endDate);
        $bank = $this->scopedBankContributions($user, $filters, $startDate, $endDate);
        $projectIncome = $this->scopedProjectTransactions($filters, $startDate, $endDate)
            ->where('transaction_type', ProjectTransaction::TYPE_INCOME)
            ->where('status', ProjectTransaction::STATUS_APPROVED);
        $projectExpenses = $this->scopedProjectTransactions($filters, $startDate, $endDate)
            ->where('transaction_type', ProjectTransaction::TYPE_EXPENSE)
            ->where('status', ProjectTransaction::STATUS_APPROVED);

        $incomeItems = collect([
            ['label' => db_trans('offerings'), 'amount' => (float) (clone $offerings)->sum('amount')],
            ['label' => db_trans('tithes'), 'amount' => (float) (clone $tithes)->sum('amount')],
            ['label' => db_trans('cash_contributions'), 'amount' => (float) (clone $cash)->where('status', CashContribution::STATUS_APPROVED)->sum('amount')],
            ['label' => db_trans('bank_contributions'), 'amount' => (float) (clone $bank)->where('status', BankContribution::STATUS_VERIFIED)->sum('amount')],
            ['label' => db_trans('project_income'), 'amount' => (float) (clone $projectIncome)->sum('amount')],
        ]);

        $expenseItems = collect([
            ['label' => db_trans('project_expenses'), 'amount' => (float) (clone $projectExpenses)->sum('amount')],
        ]);

        $incomeTotal = $incomeItems->sum('amount');
        $expenseTotal = $expenseItems->sum('amount');

        return [
            'pageTitle' => db_trans('finance_reports'),
            'filters' => $filters,
            'filterData' => $this->filtersData(),
            'startDate' => $startDate,
            'endDate' => $endDate,
            'stats' => [
                'income_total' => $incomeTotal,
                'expense_total' => $expenseTotal,
                'balance' => $incomeTotal - $expenseTotal,
                'cash_total' => (float) (clone $cash)->where('status', CashContribution::STATUS_APPROVED)->sum('amount'),
                'bank_total' => (float) (clone $bank)->where('status', BankContribution::STATUS_VERIFIED)->sum('amount'),
                'approved_tithes' => (float) (clone $tithes)->where('status', Tithe::STATUS_APPROVED)->sum('amount'),
                'offerings_total' => (float) (clone $offerings)->where('status', Offering::STATUS_APPROVED)->sum('amount'),
            ],
            'incomeItems' => $incomeItems,
            'expenseItems' => $expenseItems,
            'monthlyTrend' => $this->monthlyTrend($user, $filters, $startDate, $endDate),
            'contributionTypeBreakdown' => $this->contributionTypeBreakdown($user, $filters, $startDate, $endDate),
        ];
    }

    public function compliance(User $user, array $filters = []): array
    {
        $year = (int) ($filters['year'] ?? now()->year);
        $month = (int) ($filters['month'] ?? now()->month);

        $memberQuery = Member::query()
            ->with(['familia.jumuiya.kanda'])
            ->where('is_active', true);

        $this->applyHierarchyFiltersToMembers($memberQuery, $filters);

        if (! empty($filters['member_id'])) {
            $memberQuery->where('members.id', (int) $filters['member_id']);
        }

        $members = $memberQuery->get();

        $typeId = ! empty($filters['contribution_type_id']) ? (int) $filters['contribution_type_id'] : null;
        $plannedAmount = $typeId
            ? (float) optional(ContributionType::with('plan')->find($typeId)?->plan)->amount
            : 0.0;

        $rows = $members->map(function (Member $member) use ($year, $month, $typeId, $plannedAmount) {
            $cashAmount = CashContribution::query()
                ->where('member_id', $member->id)
                ->where('status', CashContribution::STATUS_APPROVED)
                ->when($typeId, fn (Builder $query) => $query->where('contribution_type_id', $typeId))
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount');

            $bankAmount = BankContribution::query()
                ->where('member_id', $member->id)
                ->where('status', BankContribution::STATUS_VERIFIED)
                ->when($typeId, fn (Builder $query) => $query->where('contribution_type_id', $typeId))
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount');

            $paid = (float) $cashAmount + (float) $bankAmount;
            $expected = $plannedAmount;
            $balance = max($expected - $paid, 0);

            $status = 'unpaid';
            if ($paid > 0 && $expected <= 0) {
                $status = 'paid';
            } elseif ($paid > 0 && $expected > 0 && $paid < $expected) {
                $status = 'partial';
            } elseif ($expected > 0 && $paid >= $expected) {
                $status = 'paid';
            }

            return [
                'member_id' => $member->id,
                'member_name' => $member->full_name,
                'familia_name' => $member->familia?->name,
                'jumuiya_name' => $member->familia?->jumuiya?->name,
                'kanda_name' => $member->familia?->jumuiya?->kanda?->name,
                'expected_amount' => $expected,
                'cash_paid' => (float) $cashAmount,
                'bank_paid' => (float) $bankAmount,
                'paid_amount' => $paid,
                'balance' => $balance,
                'status' => $status,
            ];
        })->values();

        if (! empty($filters['payment_channel']) && $filters['payment_channel'] !== 'all') {
            $rows = $rows->filter(function (array $row) use ($filters) {
                return $filters['payment_channel'] === 'cash'
                    ? $row['cash_paid'] > 0
                    : $row['bank_paid'] > 0;
            })->values();
        }

        if (! empty($filters['status'])) {
            $rows = $rows->where('status', $filters['status'])->values();
        }

        return [
            'pageTitle' => db_trans('monthly_contribution_compliance'),
            'filters' => $filters,
            'filterData' => $this->filtersData(),
            'rows' => $rows,
            'stats' => [
                'members' => $rows->count(),
                'paid' => $rows->where('status', 'paid')->count(),
                'partial' => $rows->where('status', 'partial')->count(),
                'unpaid' => $rows->where('status', 'unpaid')->count(),
                'expected_total' => $rows->sum('expected_amount'),
                'paid_total' => $rows->sum('paid_amount'),
                'balance_total' => $rows->sum('balance'),
            ],
        ];
    }

    public function exportComplianceCsv(array $rows): string
    {
        $handle = fopen('php://temp', 'r+');
        fputcsv($handle, ['Member', 'Familia', 'Jumuiya', 'Kanda', 'Expected', 'Cash Paid', 'Bank Paid', 'Total Paid', 'Balance', 'Status']);

        foreach ($rows as $row) {
            fputcsv($handle, [
                $row['member_name'],
                $row['familia_name'],
                $row['jumuiya_name'],
                $row['kanda_name'],
                $row['expected_amount'],
                $row['cash_paid'],
                $row['bank_paid'],
                $row['paid_amount'],
                $row['balance'],
                $row['status'],
            ]);
        }

        rewind($handle);
        return stream_get_contents($handle);
    }

    protected function monthlyTrend(User $user, array $filters, Carbon $startDate, Carbon $endDate): array
    {
        $months = collect(range(1, 12))->map(fn (int $month) => Carbon::createFromDate((int) ($filters['year'] ?? now()->year), $month, 1));

        $amounts = $months->map(function (Carbon $monthDate) use ($user, $filters) {
            $cash = $this->scopedCashContributions($user, $filters, $monthDate->copy()->startOfMonth(), $monthDate->copy()->endOfMonth())
                ->where('status', CashContribution::STATUS_APPROVED)
                ->sum('amount');
            $bank = $this->scopedBankContributions($user, $filters, $monthDate->copy()->startOfMonth(), $monthDate->copy()->endOfMonth())
                ->where('status', BankContribution::STATUS_VERIFIED)
                ->sum('amount');
            return (float) $cash + (float) $bank;
        });

        return [
            'labels' => $months->map(fn (Carbon $month) => $month->format('M'))->values(),
            'amounts' => $amounts->values(),
        ];
    }

    protected function contributionTypeBreakdown(User $user, array $filters, Carbon $startDate, Carbon $endDate): array
    {
        $types = ContributionType::query()->where('is_active', true)->orderBy('name')->get();

        $rows = $types->map(function (ContributionType $type) use ($user, $filters, $startDate, $endDate) {
            $cash = $this->scopedCashContributions($user, $filters, $startDate, $endDate)
                ->where('contribution_type_id', $type->id)
                ->where('status', CashContribution::STATUS_APPROVED)
                ->sum('amount');
            $bank = $this->scopedBankContributions($user, $filters, $startDate, $endDate)
                ->where('contribution_type_id', $type->id)
                ->where('status', BankContribution::STATUS_VERIFIED)
                ->sum('amount');

            return [
                'name' => $type->name,
                'cash_total' => (float) $cash,
                'bank_total' => (float) $bank,
                'total' => (float) $cash + (float) $bank,
            ];
        })->filter(fn (array $row) => $row['total'] > 0)->values();

        return [
            'labels' => $rows->pluck('name')->values(),
            'amounts' => $rows->pluck('total')->values(),
            'rows' => $rows,
        ];
    }

    protected function resolveDateRange(array $filters): array
    {
        if (! empty($filters['start_date']) && ! empty($filters['end_date'])) {
            return [Carbon::parse($filters['start_date'])->startOfDay(), Carbon::parse($filters['end_date'])->endOfDay()];
        }

        $year = (int) ($filters['year'] ?? now()->year);
        if (! empty($filters['month'])) {
            $date = Carbon::createFromDate($year, (int) $filters['month'], 1);
            return [$date->copy()->startOfMonth(), $date->copy()->endOfMonth()];
        }

        return [Carbon::createFromDate($year, 1, 1)->startOfYear(), Carbon::createFromDate($year, 12, 31)->endOfYear()];
    }

    protected function scopedOfferings(User $user, array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        $query = Offering::query()->whereBetween('collection_date', [$startDate, $endDate]);
        $this->applyHierarchyFiltersToOfferings($query, $filters);
        return $query;
    }

    protected function scopedTithes(User $user, array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        $query = Tithe::query()->whereBetween('contribution_date', [$startDate, $endDate]);
        if (! empty($filters['jumuiya_id'])) {
            $query->where('jumuiya_id', (int) $filters['jumuiya_id']);
        }
        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }
        if (! empty($filters['status']) && in_array($filters['status'], Tithe::availableStatuses(), true)) {
            $query->where('status', $filters['status']);
        }
        return $query;
    }

    protected function scopedCashContributions(User $user, array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        $query = CashContribution::query()->whereBetween('contribution_date', [$startDate, $endDate]);
        $this->applyHierarchyFiltersToContributionQuery($query, $filters);
        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }
        if (! empty($filters['contribution_type_id'])) {
            $query->where('contribution_type_id', (int) $filters['contribution_type_id']);
        }
        return $query;
    }

    protected function scopedBankContributions(User $user, array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        $query = BankContribution::query()->whereBetween('contribution_date', [$startDate, $endDate]);
        $this->applyHierarchyFiltersToContributionQuery($query, $filters);
        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }
        if (! empty($filters['contribution_type_id'])) {
            $query->where('contribution_type_id', (int) $filters['contribution_type_id']);
        }
        if (! empty($filters['status']) && in_array($filters['status'], [BankContribution::STATUS_PENDING, BankContribution::STATUS_VERIFIED, BankContribution::STATUS_REJECTED], true)) {
            $query->where('status', $filters['status']);
        }
        return $query;
    }

    protected function scopedProjectTransactions(array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        return ProjectTransaction::query()->whereBetween('transaction_date', [$startDate, $endDate]);
    }

    protected function applyHierarchyFiltersToMembers(Builder $query, array $filters): void
    {
        if (! empty($filters['familia_id'])) {
            $query->where('familia_id', (int) $filters['familia_id']);
        }

        if (! empty($filters['jumuiya_id'])) {
            $query->whereHas('familia', fn (Builder $familiaQuery) => $familiaQuery->where('jumuiya_id', (int) $filters['jumuiya_id']));
        }

        if (! empty($filters['kanda_id'])) {
            $query->whereHas('familia.jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', (int) $filters['kanda_id']));
        }
    }

    protected function applyHierarchyFiltersToContributionQuery(Builder $query, array $filters): void
    {
        if (! empty($filters['familia_id'])) {
            $query->where('familia_id', (int) $filters['familia_id']);
        }
        if (! empty($filters['jumuiya_id'])) {
            $query->where('jumuiya_id', (int) $filters['jumuiya_id']);
        }
        if (! empty($filters['kanda_id'])) {
            $query->where('kanda_id', (int) $filters['kanda_id']);
        }
    }

    protected function applyHierarchyFiltersToOfferings(Builder $query, array $filters): void
    {
        if (! empty($filters['jumuiya_id'])) {
            $query->where('jumuiya_id', (int) $filters['jumuiya_id']);
        }
        if (! empty($filters['kanda_id'])) {
            $query->where('kanda_id', (int) $filters['kanda_id']);
        }
        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }
    }
}
