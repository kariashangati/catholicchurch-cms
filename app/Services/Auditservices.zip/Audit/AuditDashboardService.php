<?php

namespace App\Services\Audit;

use App\Models\AuditLog;
use App\Models\LoginHistory;
use App\Models\User;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class AuditDashboardService
{
    public function getDataFor(User $user): array
    {
        abort_unless($user->can('audit.view'), 403);

        return [
            'page' => [
                'title' => db_trans('audit_access_center'),
                'subtitle' => db_trans('track_administrator_actions_login_events_and_operational_security_signals'),
                'updated_at' => now(),
            ],
            'kpis' => $this->getKpis(),
            'activityTrendChart' => $this->getActivityTrendChart(),
            'loginTrendChart' => $this->getLoginTrendChart(),
            'moduleBreakdownChart' => $this->getModuleBreakdownChart(),
            'eventBreakdownChart' => $this->getEventBreakdownChart(),
            'riskBreakdownChart' => $this->getRiskBreakdownChart(),
            'browserUsageChart' => $this->getBrowserUsageChart(),
            'liveFeed' => $this->getLiveFeed(),
            'topActors' => $this->getTopActors(),
            'riskHighlights' => $this->getRiskHighlights(),
        ];
    }

    protected function getKpis(): array
    {
        return [
            [
                'title' => db_trans('activities_today'),
                'value' => AuditLog::query()->whereDate('created_at', today())->count(),
                'icon' => 'fas fa-wave-square',
                'tone' => 'primary',
            ],
            [
                'title' => db_trans('unique_actors_today'),
                'value' => AuditLog::query()
                    ->whereDate('created_at', today())
                    ->whereNotNull('user_id')
                    ->distinct('user_id')
                    ->count('user_id'),
                'icon' => 'fas fa-user-shield',
                'tone' => 'info',
            ],
            [
                'title' => db_trans('logins_24h'),
                'value' => LoginHistory::query()
                    ->where('status', 'success')
                    ->where('created_at', '>=', now()->subDay())
                    ->count(),
                'icon' => 'fas fa-sign-in-alt',
                'tone' => 'success',
            ],
            [
                'title' => db_trans('failed_logins_24h'),
                'value' => LoginHistory::query()
                    ->whereIn('status', ['failed', 'locked_out'])
                    ->where('created_at', '>=', now()->subDay())
                    ->count(),
                'icon' => 'fas fa-exclamation-triangle',
                'tone' => 'danger',
            ],
            [
                'title' => db_trans('suspicious_logins_7d'),
                'value' => LoginHistory::query()
                    ->where('is_suspicious', true)
                    ->where('created_at', '>=', now()->subDays(7))
                    ->count(),
                'icon' => 'fas fa-user-secret',
                'tone' => 'warning',
            ],
            [
                'title' => db_trans('active_ips_7d'),
                'value' => LoginHistory::query()
                    ->where('created_at', '>=', now()->subDays(7))
                    ->whereNotNull('ip_address')
                    ->distinct('ip_address')
                    ->count('ip_address'),
                'icon' => 'fas fa-network-wired',
                'tone' => 'secondary',
            ],
        ];
    }

    protected function getActivityTrendChart(): array
    {
        $days = collect(range(13, 0))->map(function (int $offset) {
            $date = today()->subDays($offset);

            return [
                'date' => $date->toDateString(),
                'label' => $date->format('d M'),
            ];
        });

        $counts = AuditLog::query()
            ->selectRaw('DATE(created_at) as date, COUNT(*) as total')
            ->where('created_at', '>=', now()->subDays(14))
            ->groupBy(DB::raw('DATE(created_at)'))
            ->pluck('total', 'date');

        return [
            'labels' => $days->pluck('label')->all(),
            'values' => $days->map(fn (array $day) => (int) ($counts[$day['date']] ?? 0))->all(),
        ];
    }

    protected function getLoginTrendChart(): array
    {
        $days = collect(range(13, 0))->map(function (int $offset) {
            $date = today()->subDays($offset);

            return [
                'date' => $date->toDateString(),
                'label' => $date->format('d M'),
            ];
        });

        $success = LoginHistory::query()
            ->selectRaw('DATE(created_at) as date, COUNT(*) as total')
            ->where('status', 'success')
            ->where('created_at', '>=', now()->subDays(14))
            ->groupBy(DB::raw('DATE(created_at)'))
            ->pluck('total', 'date');

        $failed = LoginHistory::query()
            ->selectRaw('DATE(created_at) as date, COUNT(*) as total')
            ->whereIn('status', ['failed', 'locked_out'])
            ->where('created_at', '>=', now()->subDays(14))
            ->groupBy(DB::raw('DATE(created_at)'))
            ->pluck('total', 'date');

        return [
            'labels' => $days->pluck('label')->all(),
            'success' => $days->map(fn (array $day) => (int) ($success[$day['date']] ?? 0))->all(),
            'failed' => $days->map(fn (array $day) => (int) ($failed[$day['date']] ?? 0))->all(),
        ];
    }

    protected function getModuleBreakdownChart(): array
    {
        $rows = AuditLog::query()
            ->selectRaw('COALESCE(module, "system") as label, COUNT(*) as total')
            ->groupBy('label')
            ->orderByDesc('total')
            ->limit(8)
            ->get();

        return [
            'labels' => $rows->pluck('label')->map(fn ($label) => ucfirst((string) $label))->all(),
            'values' => $rows->pluck('total')->map(fn ($total) => (int) $total)->all(),
        ];
    }

    protected function getEventBreakdownChart(): array
    {
        $rows = AuditLog::query()
            ->selectRaw('event as label, COUNT(*) as total')
            ->groupBy('label')
            ->orderByDesc('total')
            ->limit(8)
            ->get();

        return [
            'labels' => $rows->pluck('label')->map(fn ($label) => ucfirst(str_replace('_', ' ', (string) $label)))->all(),
            'values' => $rows->pluck('total')->map(fn ($total) => (int) $total)->all(),
        ];
    }

    protected function getRiskBreakdownChart(): array
    {
        $rows = LoginHistory::query()
            ->selectRaw('risk_level as label, COUNT(*) as total')
            ->groupBy('label')
            ->orderByDesc('total')
            ->get();

        return [
            'labels' => $rows->pluck('label')->map(fn ($label) => ucfirst((string) $label))->all(),
            'values' => $rows->pluck('total')->map(fn ($total) => (int) $total)->all(),
        ];
    }

    protected function getBrowserUsageChart(): array
    {
        $rows = LoginHistory::query()
            ->selectRaw('COALESCE(browser, "Unknown") as label, COUNT(*) as total')
            ->groupBy('label')
            ->orderByDesc('total')
            ->limit(6)
            ->get();

        return [
            'labels' => $rows->pluck('label')->all(),
            'values' => $rows->pluck('total')->map(fn ($total) => (int) $total)->all(),
        ];
    }

    protected function getLiveFeed(): array
    {
        return AuditLog::query()
            ->with('user')
            ->latest()
            ->take(12)
            ->get()
            ->map(function (AuditLog $log) {
                return [
                    'icon' => $this->resolveFeedIcon($log->event),
                    'tone' => $this->resolveFeedTone($log->risk_level),
                    'title' => $log->description ?: $log->display_action,
                    'actor' => $log->actor_name,
                    'meta' => trim(collect([
                        $log->module ? ucfirst($log->module) : null,
                        $log->ip_address,
                    ])->filter()->implode(' • ')),
                    'time' => optional($log->created_at)->diffForHumans(),
                ];
            })
            ->all();
    }

    protected function getTopActors(): array
    {
        return AuditLog::query()
            ->selectRaw('user_id, COUNT(*) as total')
            ->with('user:id,name,email')
            ->whereNotNull('user_id')
            ->where('created_at', '>=', now()->subDays(7))
            ->groupBy('user_id')
            ->orderByDesc('total')
            ->limit(5)
            ->get()
            ->map(function (AuditLog $row) {
                return [
                    'name' => $row->user?->name ?: 'Unknown',
                    'email' => $row->user?->email,
                    'total' => (int) $row->total,
                ];
            })
            ->all();
    }

    protected function getRiskHighlights(): array
    {
        $lastSuccessful = LoginHistory::query()
            ->where('status', 'success')
            ->latest('logged_in_at')
            ->first();

        $lastFailed = LoginHistory::query()
            ->whereIn('status', ['failed', 'locked_out'])
            ->latest('created_at')
            ->first();

        $topIp = LoginHistory::query()
            ->selectRaw('ip_address, COUNT(*) as total')
            ->whereNotNull('ip_address')
            ->groupBy('ip_address')
            ->orderByDesc('total')
            ->first();

        $topModule = AuditLog::query()
            ->selectRaw('COALESCE(module, "system") as module_name, COUNT(*) as total')
            ->groupBy('module_name')
            ->orderByDesc('total')
            ->first();

        return [
            [
                'label' => db_trans('last_successful_login'),
                'value' => $lastSuccessful?->display_user ?: 'N/A',
                'meta' => $lastSuccessful?->logged_in_at?->diffForHumans() ?: '-',
            ],
            [
                'label' => db_trans('last_failed_login'),
                'value' => $lastFailed?->display_email ?: 'N/A',
                'meta' => $lastFailed?->created_at?->diffForHumans() ?: '-',
            ],
            [
                'label' => db_trans('top_login_ip'),
                'value' => $topIp?->ip_address ?: 'N/A',
                'meta' => $topIp ? ((int) $topIp->total . ' ' . db_trans('attempts')) : '-',
            ],
            [
                'label' => db_trans('most_active_module'),
                'value' => $topModule ? ucfirst((string) $topModule->module_name) : 'N/A',
                'meta' => $topModule ? ((int) $topModule->total . ' ' . db_trans('events')) : '-',
            ],
        ];
    }

    protected function resolveFeedIcon(string $event): string
    {
        return match ($event) {
            'login' => 'fas fa-sign-in-alt',
            'logout' => 'fas fa-sign-out-alt',
            'failed_login', 'locked_out' => 'fas fa-exclamation-triangle',
            'created' => 'fas fa-plus-circle',
            'updated' => 'fas fa-edit',
            'deleted' => 'fas fa-trash',
            default => 'fas fa-shield-alt',
        };
    }

    protected function resolveFeedTone(string $riskLevel): string
    {
        return match ($riskLevel) {
            'critical' => 'danger',
            'high' => 'warning',
            'medium' => 'info',
            default => 'primary',
        };
    }
}