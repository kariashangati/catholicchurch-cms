<?php

namespace App\Services\Reports;

use App\Models\Familia;
use App\Models\Jumuiya;
use App\Models\Kanda;
use App\Models\Member;
use App\Models\User;
use App\Services\Access\UserScopeResolver;
use App\Support\AdminScope;
use Illuminate\Auth\Access\AuthorizationException;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class SacramentLegacyReportsService
{
    public function __construct(
        protected UserScopeResolver $scopeResolver,
    ) {
    }

    public function filtersData(User $user): array
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            return [
                'kandas' => collect(),
                'jumuiyas' => collect(),
                'familias' => collect(),
                'memberFilters' => $this->memberFilters(),
                'allowedScopeLevels' => [],
            ];
        }

        $kandas = Kanda::query()
            ->orderBy('name')
            ->when($scope->isKanda(), fn ($query) => $query->whereKey($scope->kandaId))
            ->when($scope->isJumuiya(), fn ($query) => $query->whereKey($scope->kandaId))
            ->get(['id', 'name']);

        $jumuiyas = Jumuiya::query()
            ->orderBy('name')
            ->when($scope->isKanda(), fn ($query) => $query->where('kanda_id', $scope->kandaId))
            ->when($scope->isJumuiya(), fn ($query) => $query->whereKey($scope->jumuiyaId))
            ->get(['id', 'name', 'kanda_id']);

        $familias = Familia::query()
            ->orderBy('name')
            ->when($scope->isKanda(), function ($query) use ($scope) {
                $query->whereHas('jumuiya', fn ($jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', $scope->kandaId));
            })
            ->when($scope->isJumuiya(), fn ($query) => $query->where('jumuiya_id', $scope->jumuiyaId))
            ->get(['id', 'name', 'jumuiya_id', 'phone']);

        return [
            'kandas' => $kandas,
            'jumuiyas' => $jumuiyas,
            'familias' => $familias,
            'memberFilters' => $this->memberFilters(),
            'allowedScopeLevels' => $this->allowedScopeLevels($scope->type),
        ];
    }

    public function indexData(User $user): array
    {
        return [
            'pageTitle' => db_trans('sacrament_reports'),
            'filterData' => $this->filtersData($user),
        ];
    }

    public function generate(User $user, array $filters): array
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            throw new AuthorizationException($scope->reason ?? 'This account has an invalid scope.');
        }

        $normalized = $this->normalizeRequestedScope($user, $filters);

        $query = Member::query()->with(['familia.jumuiya.kanda']);

        $this->applyResolvedScope($query, $scope);
        $this->applyRequestedScope($query, $normalized);
        $this->applyMemberFilter($query, $normalized['member_filter']);

        $members = $query->orderBy('first_name')->orderBy('last_name')->get();
        $scopeLevel = $normalized['scope_level'];

        if ($scopeLevel === 'familia' && ! empty($normalized['scope_id'])) {
            $familia = Familia::with('jumuiya.kanda')->findOrFail((int) $normalized['scope_id']);
            $this->ensureUserCanAccessFamilia($user, $familia);

            return [
                'view' => 'admin.reports.sacraments.family-census',
                'data' => [
                    'pageTitle' => db_trans('family_sacrament_census'),
                    'filters' => $normalized,
                    'familia' => $familia,
                    'parents' => $members->whereIn('family_role', ['Baba', 'Mama', 'Male Head', 'Female Head', 'Parent'])->values(),
                    'members' => $members,
                    'summary' => $this->summaryFromMembers($members),
                ],
            ];
        }

        return [
            'view' => 'admin.reports.sacraments.scope-summary',
            'data' => [
                'pageTitle' => db_trans('sacrament_scope_summary'),
                'filters' => $normalized,
                'rows' => $this->groupedSummary($members, $scopeLevel),
                'summary' => $this->summaryFromMembers($members),
                'members' => $members,
            ],
        ];
    }

    protected function applyResolvedScope(Builder $query, object $scope): void
    {
        if ($scope->isGlobal()) {
            return;
        }

        if ($scope->isKanda()) {
            $query->whereHas('familia.jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', (int) $scope->kandaId));
            return;
        }

        if ($scope->isJumuiya()) {
            $query->whereHas('familia', fn (Builder $familiaQuery) => $familiaQuery->where('jumuiya_id', (int) $scope->jumuiyaId));
        }
    }

    protected function applyRequestedScope(Builder $query, array $filters): void
    {
        $scopeLevel = $filters['scope_level'];
        $scopeId = $filters['scope_id'];

        if (! $scopeId || $scopeLevel === 'parish') {
            return;
        }

        if ($scopeLevel === 'familia') {
            $query->where('familia_id', (int) $scopeId);
            return;
        }

        if ($scopeLevel === 'jumuiya') {
            $query->whereHas('familia', fn (Builder $familiaQuery) => $familiaQuery->where('jumuiya_id', (int) $scopeId));
            return;
        }

        if ($scopeLevel === 'kanda') {
            $query->whereHas('familia.jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', (int) $scopeId));
        }
    }

    protected function normalizeRequestedScope(User $user, array $filters): array
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            throw new AuthorizationException($scope->reason ?? 'This account has an invalid scope.');
        }

        $requestedLevel = (string) ($filters['scope_level'] ?? 'parish');
        $requestedId = ! empty($filters['scope_id']) ? (int) $filters['scope_id'] : null;
        $memberFilter = (string) ($filters['member_filter'] ?? 'all');

        if (! in_array($requestedLevel, ['parish', 'kanda', 'jumuiya', 'familia'], true)) {
            $requestedLevel = 'parish';
        }

        if (! in_array($memberFilter, $this->memberFilters(), true)) {
            $memberFilter = 'all';
        }

        if ($scope->isGlobal()) {
            $this->validateRequestedHierarchy($requestedLevel, $requestedId);

            return [
                'scope_level' => $requestedLevel,
                'scope_id' => $requestedId,
                'member_filter' => $memberFilter,
            ];
        }

        if ($scope->isKanda()) {
            if ($requestedLevel === 'parish') {
                return [
                    'scope_level' => 'kanda',
                    'scope_id' => (int) $scope->kandaId,
                    'member_filter' => $memberFilter,
                ];
            }

            if ($requestedLevel === 'kanda') {
                if ($requestedId && (int) $requestedId !== (int) $scope->kandaId) {
                    throw new AuthorizationException('You cannot access another kanda report scope.');
                }

                return [
                    'scope_level' => 'kanda',
                    'scope_id' => (int) $scope->kandaId,
                    'member_filter' => $memberFilter,
                ];
            }

            if ($requestedLevel === 'jumuiya' && $requestedId) {
                $jumuiya = Jumuiya::query()->findOrFail($requestedId);

                if ((int) $jumuiya->kanda_id !== (int) $scope->kandaId) {
                    throw new AuthorizationException('You cannot access another jumuiya report scope.');
                }
            }

            if ($requestedLevel === 'familia' && $requestedId) {
                $familia = Familia::query()->with('jumuiya')->findOrFail($requestedId);

                if ((int) $familia->jumuiya?->kanda_id !== (int) $scope->kandaId) {
                    throw new AuthorizationException('You cannot access another familia report scope.');
                }
            }

            return [
                'scope_level' => $requestedLevel,
                'scope_id' => $requestedId,
                'member_filter' => $memberFilter,
            ];
        }

        if ($scope->isJumuiya()) {
            if ($requestedLevel === 'parish' || $requestedLevel === 'kanda') {
                return [
                    'scope_level' => 'jumuiya',
                    'scope_id' => (int) $scope->jumuiyaId,
                    'member_filter' => $memberFilter,
                ];
            }

            if ($requestedLevel === 'jumuiya') {
                if ($requestedId && (int) $requestedId !== (int) $scope->jumuiyaId) {
                    throw new AuthorizationException('You cannot access another jumuiya report scope.');
                }

                return [
                    'scope_level' => 'jumuiya',
                    'scope_id' => (int) $scope->jumuiyaId,
                    'member_filter' => $memberFilter,
                ];
            }

            if ($requestedLevel === 'familia' && $requestedId) {
                $familia = Familia::query()->findOrFail($requestedId);

                if ((int) $familia->jumuiya_id !== (int) $scope->jumuiyaId) {
                    throw new AuthorizationException('You cannot access another familia report scope.');
                }
            }

            return [
                'scope_level' => $requestedLevel,
                'scope_id' => $requestedId,
                'member_filter' => $memberFilter,
            ];
        }

        return [
            'scope_level' => 'parish',
            'scope_id' => null,
            'member_filter' => $memberFilter,
        ];
    }

    protected function applyMemberFilter(Builder $query, string $filter): void
    {
        match ($filter) {
            'baptized' => $query->where('is_baptized', true),
            'not_baptized' => $query->where('is_baptized', false),
            'married' => $query->where('is_married', true),
            'not_married' => $query->where('is_married', false),
            'confirmed' => $query->where('has_confirmation', true),
            'not_confirmed' => $query->where('has_confirmation', false),
            'communion' => $query->where('has_communion', true),
            'not_communion' => $query->where('has_communion', false),
            'eucharist' => $query->where('receives_eucharist', true),
            'not_eucharist' => $query->where('receives_eucharist', false),
            'male' => $query->whereRaw('LOWER(gender) = ?', ['male']),
            'female' => $query->whereRaw('LOWER(gender) = ?', ['female']),
            default => null,
        };
    }

    protected function summaryFromMembers(Collection $members): array
    {
        return [
            'members_total' => $members->count(),
            'baptized' => $members->where('is_baptized', true)->count(),
            'communion' => $members->where('has_communion', true)->count(),
            'confirmation' => $members->where('has_confirmation', true)->count(),
            'married' => $members->where('is_married', true)->count(),
            'receives_eucharist' => $members->where('receives_eucharist', true)->count(),
            'male' => $members->filter(fn ($member) => strtolower((string) $member->gender) === 'male')->count(),
            'female' => $members->filter(fn ($member) => strtolower((string) $member->gender) === 'female')->count(),
        ];
    }

    protected function groupedSummary(Collection $members, string $scopeLevel): Collection
    {
        return $members->groupBy(function (Member $member) use ($scopeLevel) {
            return match ($scopeLevel) {
                'kanda' => $member->familia?->jumuiya?->kanda?->name ?? 'Unknown',
                'jumuiya' => $member->familia?->jumuiya?->name ?? 'Unknown',
                'familia' => $member->familia?->name ?? 'Unknown',
                default => 'Parish',
            };
        })->map(function (Collection $group, string $name) {
            return [
                'name' => $name,
                'members_total' => $group->count(),
                'baptized' => $group->where('is_baptized', true)->count(),
                'communion' => $group->where('has_communion', true)->count(),
                'confirmation' => $group->where('has_confirmation', true)->count(),
                'married' => $group->where('is_married', true)->count(),
                'receives_eucharist' => $group->where('receives_eucharist', true)->count(),
                'male' => $group->filter(fn ($member) => strtolower((string) $member->gender) === 'male')->count(),
                'female' => $group->filter(fn ($member) => strtolower((string) $member->gender) === 'female')->count(),
            ];
        })->values();
    }

    protected function allowedScopeLevels(string $scopeType): array
    {
        return match ($scopeType) {
            AdminScope::TYPE_GLOBAL => ['parish', 'kanda', 'jumuiya', 'familia'],
            AdminScope::TYPE_KANDA => ['kanda', 'jumuiya', 'familia'],
            AdminScope::TYPE_JUMUIYA => ['jumuiya', 'familia'],
            default => [],
        };
    }

    protected function ensureUserCanAccessFamilia(User $user, Familia $familia): void
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            throw new AuthorizationException($scope->reason ?? 'This account has an invalid scope.');
        }

        if ($scope->isGlobal()) {
            return;
        }

        $familia->loadMissing('jumuiya');

        if ($scope->isKanda() && (int) $familia->jumuiya?->kanda_id === (int) $scope->kandaId) {
            return;
        }

        if ($scope->isJumuiya() && (int) $familia->jumuiya_id === (int) $scope->jumuiyaId) {
            return;
        }

        throw new AuthorizationException('You are not allowed to access this familia report.');
    }

    protected function validateRequestedHierarchy(string $scopeLevel, ?int $scopeId): void
    {
        if (! $scopeId || $scopeLevel === 'parish') {
            return;
        }

        if ($scopeLevel === 'kanda') {
            Kanda::query()->findOrFail($scopeId);
            return;
        }

        if ($scopeLevel === 'jumuiya') {
            Jumuiya::query()->findOrFail($scopeId);
            return;
        }

        if ($scopeLevel === 'familia') {
            Familia::query()->findOrFail($scopeId);
        }
    }

    protected function memberFilters(): array
    {
        return [
            'all',
            'baptized',
            'not_baptized',
            'married',
            'not_married',
            'confirmed',
            'not_confirmed',
            'communion',
            'not_communion',
            'eucharist',
            'not_eucharist',
            'male',
            'female',
        ];
    }
}