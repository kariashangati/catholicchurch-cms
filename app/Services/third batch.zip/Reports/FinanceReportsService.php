<?php

namespace App\Services\Reports;

use App\Models\BankContribution;
use App\Models\CashContribution;
use App\Models\ContributionType;
use App\Models\Familia;
use App\Models\Jumuiya;
use App\Models\Kanda;
use App\Models\Member;
use App\Models\Offering;
use App\Models\ProjectTransaction;
use App\Models\Tithe;
use App\Models\User;
use App\Services\Access\ScopeAccessGate;
use App\Services\Access\UserScopeResolver;
use Illuminate\Auth\Access\AuthorizationException;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class FinanceReportsService
{
    public function __construct(
        protected UserScopeResolver $scopeResolver,
        protected ScopeAccessGate $scopeAccessGate,
    ) {
    }

    public function filtersData(?User $user = null): array
    {
        $kandas = Kanda::query()->orderBy('name');
        $jumuiyas = Jumuiya::query()->orderBy('name');
        $familias = Familia::query()->orderBy('name');
        $members = Member::query()->orderBy('first_name')->orderBy('last_name');

        if ($user) {
            $scope = $this->scopeResolver->resolve($user);

            if ($scope->isInvalid()) {
                return [
                    'kandas' => collect(),
                    'jumuiyas' => collect(),
                    'familias' => collect(),
                    'members' => collect(),
                    'contributionTypes' => ContributionType::query()
                        ->where('is_active', true)
                        ->orderBy('name')
                        ->get(['id', 'name']),
                    'statuses' => [
                        BankContribution::STATUS_PENDING,
                        BankContribution::STATUS_VERIFIED,
                        BankContribution::STATUS_REJECTED,
                        CashContribution::STATUS_PENDING,
                        CashContribution::STATUS_APPROVED,
                        CashContribution::STATUS_REJECTED,
                    ],
                ];
            }

            if ($scope->isKanda()) {
                $kandas->whereKey($scope->kandaId);
                $jumuiyas->where('kanda_id', $scope->kandaId);
                $familias->whereHas('jumuiya', fn (Builder $query) => $query->where('kanda_id', $scope->kandaId));
                $members->whereHas('familia.jumuiya', fn (Builder $query) => $query->where('kanda_id', $scope->kandaId));
            }

            if ($scope->isJumuiya()) {
                $kandas->whereKey($scope->kandaId);
                $jumuiyas->whereKey($scope->jumuiyaId);
                $familias->where('jumuiya_id', $scope->jumuiyaId);
                $members->whereHas('familia', fn (Builder $query) => $query->where('jumuiya_id', $scope->jumuiyaId));
            }
        }

        return [
            'kandas' => $kandas->get(['id', 'name']),
            'jumuiyas' => $jumuiyas->get(['id', 'name', 'kanda_id']),
            'familias' => $familias->get(['id', 'name', 'jumuiya_id', 'phone']),
            'members' => $members->get(['id', 'first_name', 'middle_name', 'last_name']),
            'contributionTypes' => ContributionType::query()
                ->where('is_active', true)
                ->orderBy('name')
                ->get(['id', 'name']),
            'statuses' => [
                BankContribution::STATUS_PENDING,
                BankContribution::STATUS_VERIFIED,
                BankContribution::STATUS_REJECTED,
                CashContribution::STATUS_PENDING,
                CashContribution::STATUS_APPROVED,
                CashContribution::STATUS_REJECTED,
            ],
        ];
    }

    public function summary(User $user, array $filters = []): array
    {
        $filters = $this->normalizeHierarchyFilters($user, $filters);
        [$startDate, $endDate] = $this->resolveDateRange($filters);

        $offerings = $this->scopedOfferings($user, $filters, $startDate, $endDate);
        $tithes = $this->scopedTithes($user, $filters, $startDate, $endDate);
        $cash = $this->scopedCashContributions($user, $filters, $startDate, $endDate);
        $bank = $this->scopedBankContributions($user, $filters, $startDate, $endDate);
        $projectIncome = $this->scopedProjectTransactions($filters, $startDate, $endDate)
            ->where('transaction_type', ProjectTransaction::TYPE_INCOME)
            ->where('status', ProjectTransaction::STATUS_APPROVED);
        $projectExpenses = $this->scopedProjectTransactions($filters, $startDate, $endDate)
            ->where('transaction_type', ProjectTransaction::TYPE_EXPENSE)
            ->where('status', ProjectTransaction::STATUS_APPROVED);

        $incomeItems = collect([
            ['label' => db_trans('offerings'), 'amount' => (float) (clone $offerings)->sum('amount')],
            ['label' => db_trans('tithes'), 'amount' => (float) (clone $tithes)->sum('amount')],
            ['label' => db_trans('cash_contributions'), 'amount' => (float) (clone $cash)->where('status', CashContribution::STATUS_APPROVED)->sum('amount')],
            ['label' => db_trans('bank_contributions'), 'amount' => (float) (clone $bank)->where('status', BankContribution::STATUS_VERIFIED)->sum('amount')],
            ['label' => db_trans('project_income'), 'amount' => (float) (clone $projectIncome)->sum('amount')],
        ]);

        $expenseItems = collect([
            ['label' => db_trans('project_expenses'), 'amount' => (float) (clone $projectExpenses)->sum('amount')],
        ]);

        $incomeTotal = (float) $incomeItems->sum('amount');
        $expenseTotal = (float) $expenseItems->sum('amount');

        return [
            'pageTitle' => db_trans('finance_reports'),
            'filters' => $filters,
            'filterData' => $this->filtersData($user),
            'startDate' => $startDate,
            'endDate' => $endDate,
            'stats' => [
                'income_total' => $incomeTotal,
                'expense_total' => $expenseTotal,
                'balance' => $incomeTotal - $expenseTotal,
                'cash_total' => (float) (clone $cash)->where('status', CashContribution::STATUS_APPROVED)->sum('amount'),
                'bank_total' => (float) (clone $bank)->where('status', BankContribution::STATUS_VERIFIED)->sum('amount'),
                'approved_tithes' => (float) (clone $tithes)->where('status', Tithe::STATUS_APPROVED)->sum('amount'),
                'offerings_total' => (float) (clone $offerings)->where('status', Offering::STATUS_APPROVED)->sum('amount'),
            ],
            'incomeItems' => $incomeItems,
            'expenseItems' => $expenseItems,
            'monthlyTrend' => $this->monthlyTrend($user, $filters, $startDate, $endDate),
            'contributionTypeBreakdown' => $this->contributionTypeBreakdown($user, $filters, $startDate, $endDate),
        ];
    }

    public function compliance(User $user, array $filters = []): array
    {
        $filters = $this->normalizeHierarchyFilters($user, $filters);

        $year = (int) ($filters['year'] ?? now()->year);
        $month = (int) ($filters['month'] ?? now()->month);

        $memberQuery = Member::query()
            ->with(['familia.jumuiya.kanda'])
            ->where('is_active', true);

        $this->applyResolverScopeToMembers($memberQuery, $user);
        $this->applyHierarchyFiltersToMembers($memberQuery, $filters);

        if (! empty($filters['member_id'])) {
            $memberQuery->where('members.id', (int) $filters['member_id']);
        }

        $members = $memberQuery->get();

        $typeId = ! empty($filters['contribution_type_id']) ? (int) $filters['contribution_type_id'] : null;
        $plannedAmount = $typeId
            ? (float) optional(ContributionType::with('plan')->find($typeId)?->plan)->amount
            : 0.0;

        $rows = $members->map(function (Member $member) use ($year, $month, $typeId, $plannedAmount) {
            $cashAmount = CashContribution::query()
                ->where('member_id', $member->id)
                ->where('status', CashContribution::STATUS_APPROVED)
                ->when($typeId, fn (Builder $query) => $query->where('contribution_type_id', $typeId))
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount');

            $bankAmount = BankContribution::query()
                ->where('member_id', $member->id)
                ->where('status', BankContribution::STATUS_VERIFIED)
                ->when($typeId, fn (Builder $query) => $query->where('contribution_type_id', $typeId))
                ->whereYear('contribution_date', $year)
                ->whereMonth('contribution_date', $month)
                ->sum('amount');

            $paid = (float) $cashAmount + (float) $bankAmount;
            $expected = $plannedAmount;
            $balance = max($expected - $paid, 0);

            $status = 'unpaid';
            if ($paid > 0 && $expected <= 0) {
                $status = 'paid';
            } elseif ($paid > 0 && $expected > 0 && $paid < $expected) {
                $status = 'partial';
            } elseif ($expected > 0 && $paid >= $expected) {
                $status = 'paid';
            }

            return [
                'member_id' => $member->id,
                'member_name' => $member->full_name,
                'familia_name' => $member->familia?->name,
                'jumuiya_name' => $member->familia?->jumuiya?->name,
                'kanda_name' => $member->familia?->jumuiya?->kanda?->name,
                'expected_amount' => $expected,
                'cash_paid' => (float) $cashAmount,
                'bank_paid' => (float) $bankAmount,
                'paid_amount' => $paid,
                'balance' => $balance,
                'status' => $status,
            ];
        })->values();

        if (! empty($filters['payment_channel']) && $filters['payment_channel'] !== 'all') {
            $rows = $rows->filter(function (array $row) use ($filters) {
                return $filters['payment_channel'] === 'cash'
                    ? $row['cash_paid'] > 0
                    : $row['bank_paid'] > 0;
            })->values();
        }

        if (! empty($filters['status'])) {
            $rows = $rows->where('status', $filters['status'])->values();
        }

        return [
            'pageTitle' => db_trans('monthly_contribution_compliance'),
            'filters' => $filters,
            'filterData' => $this->filtersData($user),
            'rows' => $rows,
            'stats' => [
                'members' => $rows->count(),
                'paid' => $rows->where('status', 'paid')->count(),
                'partial' => $rows->where('status', 'partial')->count(),
                'unpaid' => $rows->where('status', 'unpaid')->count(),
                'expected_total' => $rows->sum('expected_amount'),
                'paid_total' => $rows->sum('paid_amount'),
                'balance_total' => $rows->sum('balance'),
            ],
        ];
    }

    public function exportComplianceCsv(array $rows): string
    {
        $handle = fopen('php://temp', 'r+');
        fputcsv($handle, ['Member', 'Familia', 'Jumuiya', 'Kanda', 'Expected', 'Cash Paid', 'Bank Paid', 'Total Paid', 'Balance', 'Status']);

        foreach ($rows as $row) {
            fputcsv($handle, [
                $row['member_name'],
                $row['familia_name'],
                $row['jumuiya_name'],
                $row['kanda_name'],
                $row['expected_amount'],
                $row['cash_paid'],
                $row['bank_paid'],
                $row['paid_amount'],
                $row['balance'],
                $row['status'],
            ]);
        }

        rewind($handle);

        return stream_get_contents($handle);
    }

    protected function monthlyTrend(User $user, array $filters, Carbon $startDate, Carbon $endDate): array
    {
        $months = collect(range(1, 12))->map(
            fn (int $month) => Carbon::createFromDate((int) ($filters['year'] ?? now()->year), $month, 1)
        );

        $amounts = $months->map(function (Carbon $monthDate) use ($user, $filters) {
            $cash = $this->scopedCashContributions(
                $user,
                $filters,
                $monthDate->copy()->startOfMonth(),
                $monthDate->copy()->endOfMonth()
            )->where('status', CashContribution::STATUS_APPROVED)->sum('amount');

            $bank = $this->scopedBankContributions(
                $user,
                $filters,
                $monthDate->copy()->startOfMonth(),
                $monthDate->copy()->endOfMonth()
            )->where('status', BankContribution::STATUS_VERIFIED)->sum('amount');

            return (float) $cash + (float) $bank;
        });

        return [
            'labels' => $months->map(fn (Carbon $month) => $month->format('M'))->values(),
            'amounts' => $amounts->values(),
        ];
    }

    protected function contributionTypeBreakdown(User $user, array $filters, Carbon $startDate, Carbon $endDate): array
    {
        $types = ContributionType::query()->where('is_active', true)->orderBy('name')->get();

        $rows = $types->map(function (ContributionType $type) use ($user, $filters, $startDate, $endDate) {
            $cash = $this->scopedCashContributions($user, $filters, $startDate, $endDate)
                ->where('contribution_type_id', $type->id)
                ->where('status', CashContribution::STATUS_APPROVED)
                ->sum('amount');

            $bank = $this->scopedBankContributions($user, $filters, $startDate, $endDate)
                ->where('contribution_type_id', $type->id)
                ->where('status', BankContribution::STATUS_VERIFIED)
                ->sum('amount');

            return [
                'name' => $type->name,
                'cash_total' => (float) $cash,
                'bank_total' => (float) $bank,
                'total' => (float) $cash + (float) $bank,
            ];
        })->filter(fn (array $row) => $row['total'] > 0)->values();

        return [
            'labels' => $rows->pluck('name')->values(),
            'amounts' => $rows->pluck('total')->values(),
            'rows' => $rows,
        ];
    }

    protected function resolveDateRange(array $filters): array
    {
        if (! empty($filters['start_date']) && ! empty($filters['end_date'])) {
            return [
                Carbon::parse($filters['start_date'])->startOfDay(),
                Carbon::parse($filters['end_date'])->endOfDay(),
            ];
        }

        $year = (int) ($filters['year'] ?? now()->year);

        if (! empty($filters['month'])) {
            $date = Carbon::createFromDate($year, (int) $filters['month'], 1);

            return [$date->copy()->startOfMonth(), $date->copy()->endOfMonth()];
        }

        return [
            Carbon::createFromDate($year, 1, 1)->startOfYear(),
            Carbon::createFromDate($year, 12, 31)->endOfYear(),
        ];
    }

    protected function scopedOfferings(User $user, array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        $query = Offering::query()->whereBetween('collection_date', [$startDate, $endDate]);

        $this->applyResolverScopeToOfferings($query, $user);
        $this->applyHierarchyFiltersToOfferings($query, $filters);

        return $query;
    }

    protected function scopedTithes(User $user, array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        $query = Tithe::query()->whereBetween('contribution_date', [$startDate, $endDate]);

        $this->applyResolverScopeToTithes($query, $user);

        if (! empty($filters['jumuiya_id'])) {
            $query->where('jumuiya_id', (int) $filters['jumuiya_id']);
        }

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        if (! empty($filters['status']) && in_array($filters['status'], Tithe::availableStatuses(), true)) {
            $query->where('status', $filters['status']);
        }

        return $query;
    }

    protected function scopedCashContributions(User $user, array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        $query = CashContribution::query()->whereBetween('contribution_date', [$startDate, $endDate]);

        $this->applyResolverScopeToContributionQuery($query, $user);
        $this->applyHierarchyFiltersToContributionQuery($query, $filters);

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        if (! empty($filters['contribution_type_id'])) {
            $query->where('contribution_type_id', (int) $filters['contribution_type_id']);
        }

        if (! empty($filters['status']) && in_array($filters['status'], [
            CashContribution::STATUS_PENDING,
            CashContribution::STATUS_APPROVED,
            CashContribution::STATUS_REJECTED,
        ], true)) {
            $query->where('status', $filters['status']);
        }

        return $query;
    }

    protected function scopedBankContributions(User $user, array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        $query = BankContribution::query()->whereBetween('contribution_date', [$startDate, $endDate]);

        $this->applyResolverScopeToContributionQuery($query, $user);
        $this->applyHierarchyFiltersToContributionQuery($query, $filters);

        if (! empty($filters['member_id'])) {
            $query->where('member_id', (int) $filters['member_id']);
        }

        if (! empty($filters['contribution_type_id'])) {
            $query->where('contribution_type_id', (int) $filters['contribution_type_id']);
        }

        if (! empty($filters['status']) && in_array($filters['status'], [
            BankContribution::STATUS_PENDING,
            BankContribution::STATUS_VERIFIED,
            BankContribution::STATUS_REJECTED,
        ], true)) {
            $query->where('status', $filters['status']);
        }

        return $query;
    }

    protected function scopedProjectTransactions(array $filters, Carbon $startDate, Carbon $endDate): Builder
    {
        return ProjectTransaction::query()->whereBetween('transaction_date', [$startDate, $endDate]);
    }

    protected function applyHierarchyFiltersToMembers(Builder $query, array $filters): void
    {
        if (! empty($filters['familia_id'])) {
            $query->where('familia_id', (int) $filters['familia_id']);
        }

        if (! empty($filters['jumuiya_id'])) {
            $query->whereHas('familia', fn (Builder $familiaQuery) => $familiaQuery->where('jumuiya_id', (int) $filters['jumuiya_id']));
        }

        if (! empty($filters['kanda_id'])) {
            $query->whereHas('familia.jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', (int) $filters['kanda_id']));
        }
    }

    protected function applyHierarchyFiltersToContributionQuery(Builder $query, array $filters): void
    {
        if (! empty($filters['familia_id'])) {
            $query->where('familia_id', (int) $filters['familia_id']);
        }

        if (! empty($filters['jumuiya_id'])) {
            $query->where('jumuiya_id', (int) $filters['jumuiya_id']);
        }

        if (! empty($filters['kanda_id'])) {
            $query->where('kanda_id', (int) $filters['kanda_id']);
        }
    }

    protected function applyHierarchyFiltersToOfferings(Builder $query, array $filters): void
    {
        if (! empty($filters['jumuiya_id'])) {
            $query->where('jumuiya_id', (int) $filters['jumuiya_id']);
        }

        if (! empty($filters['kanda_id'])) {
            $query->where('kanda_id', (int) $filters['kanda_id']);
        }

        if (! empty($filters['status'])) {
            $query->where('status', $filters['status']);
        }
    }

    protected function applyResolverScopeToMembers(Builder $query, User $user): void
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            $query->whereRaw('1 = 0');
            return;
        }

        if ($scope->isGlobal()) {
            return;
        }

        if ($scope->isKanda()) {
            $query->whereHas('familia.jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', $scope->kandaId));
            return;
        }

        if ($scope->isJumuiya()) {
            $query->whereHas('familia', fn (Builder $familiaQuery) => $familiaQuery->where('jumuiya_id', $scope->jumuiyaId));
        }
    }

    protected function applyResolverScopeToContributionQuery(Builder $query, User $user): void
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            $query->whereRaw('1 = 0');
            return;
        }

        if ($scope->isGlobal()) {
            return;
        }

        if ($scope->isKanda()) {
            $query->where('kanda_id', $scope->kandaId);
            return;
        }

        if ($scope->isJumuiya()) {
            $query->where('jumuiya_id', $scope->jumuiyaId);
        }
    }

    protected function applyResolverScopeToOfferings(Builder $query, User $user): void
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            $query->whereRaw('1 = 0');
            return;
        }

        if ($scope->isGlobal()) {
            return;
        }

        if ($scope->isKanda()) {
            $query->where(function (Builder $builder) use ($scope) {
                $builder->where('kanda_id', $scope->kandaId)
                    ->orWhereHas('jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', $scope->kandaId));
            });
            return;
        }

        if ($scope->isJumuiya()) {
            $query->where('jumuiya_id', $scope->jumuiyaId);
        }
    }

    protected function applyResolverScopeToTithes(Builder $query, User $user): void
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            $query->whereRaw('1 = 0');
            return;
        }

        if ($scope->isGlobal()) {
            return;
        }

        if ($scope->isKanda()) {
            $query->whereHas('jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', $scope->kandaId));
            return;
        }

        if ($scope->isJumuiya()) {
            $query->where('jumuiya_id', $scope->jumuiyaId);
        }
    }

    protected function normalizeHierarchyFilters(User $user, array $filters): array
    {
        $scope = $this->scopeResolver->resolve($user);

        if ($scope->isInvalid()) {
            throw new AuthorizationException($scope->reason ?? 'This account has an invalid scope.');
        }

        $filters['kanda_id'] = ! empty($filters['kanda_id']) ? (int) $filters['kanda_id'] : null;
        $filters['jumuiya_id'] = ! empty($filters['jumuiya_id']) ? (int) $filters['jumuiya_id'] : null;
        $filters['familia_id'] = ! empty($filters['familia_id']) ? (int) $filters['familia_id'] : null;
        $filters['member_id'] = ! empty($filters['member_id']) ? (int) $filters['member_id'] : null;

        if ($scope->isGlobal()) {
            $this->validateRequestedHierarchy($user, $filters);
            return $filters;
        }

        if ($scope->isKanda()) {
            if ($filters['kanda_id'] && (int) $filters['kanda_id'] !== (int) $scope->kandaId) {
                throw new AuthorizationException('You cannot access another kanda financial scope.');
            }

            $filters['kanda_id'] = (int) $scope->kandaId;

            if ($filters['jumuiya_id']) {
                $jumuiya = Jumuiya::query()->findOrFail($filters['jumuiya_id']);
                $this->scopeAccessGate->authorizeJumuiya($user, $jumuiya);
            }

            if ($filters['familia_id']) {
                $familia = Familia::query()->with('jumuiya')->findOrFail($filters['familia_id']);
                $this->scopeAccessGate->authorizeFamilia($user, $familia);
            }

            if ($filters['member_id']) {
                $member = Member::query()->with('familia.jumuiya')->findOrFail($filters['member_id']);
                $this->scopeAccessGate->authorizeMember($user, $member);
            }

            return $filters;
        }

        if ($scope->isJumuiya()) {
            if ($filters['kanda_id'] && (int) $filters['kanda_id'] !== (int) $scope->kandaId) {
                throw new AuthorizationException('You cannot access another kanda financial scope.');
            }

            if ($filters['jumuiya_id'] && (int) $filters['jumuiya_id'] !== (int) $scope->jumuiyaId) {
                throw new AuthorizationException('You cannot access another jumuiya financial scope.');
            }

            $filters['kanda_id'] = (int) $scope->kandaId;
            $filters['jumuiya_id'] = (int) $scope->jumuiyaId;

            if ($filters['familia_id']) {
                $familia = Familia::query()->findOrFail($filters['familia_id']);
                $this->scopeAccessGate->authorizeFamilia($user, $familia);
            }

            if ($filters['member_id']) {
                $member = Member::query()->with('familia')->findOrFail($filters['member_id']);
                $this->scopeAccessGate->authorizeMember($user, $member);
            }

            return $filters;
        }

        return $filters;
    }

    protected function validateRequestedHierarchy(User $user, array $filters): void
    {
        if ($filters['jumuiya_id'] && $filters['kanda_id']) {
            $jumuiya = Jumuiya::query()->findOrFail($filters['jumuiya_id']);

            if ((int) $jumuiya->kanda_id !== (int) $filters['kanda_id']) {
                throw new AuthorizationException('Selected jumuiya does not belong to the selected kanda.');
            }

            $this->scopeAccessGate->authorizeJumuiya($user, $jumuiya);
        }

        if ($filters['familia_id']) {
            $familia = Familia::query()->with('jumuiya')->findOrFail($filters['familia_id']);

            if ($filters['jumuiya_id'] && (int) $familia->jumuiya_id !== (int) $filters['jumuiya_id']) {
                throw new AuthorizationException('Selected familia does not belong to the selected jumuiya.');
            }

            $this->scopeAccessGate->authorizeFamilia($user, $familia);
        }

        if ($filters['member_id']) {
            $member = Member::query()->with('familia.jumuiya')->findOrFail($filters['member_id']);

            if ($filters['familia_id'] && (int) $member->familia_id !== (int) $filters['familia_id']) {
                throw new AuthorizationException('Selected member does not belong to the selected familia.');
            }

            if ($filters['jumuiya_id'] && (int) $member->familia?->jumuiya_id !== (int) $filters['jumuiya_id']) {
                throw new AuthorizationException('Selected member does not belong to the selected jumuiya.');
            }

            if ($filters['kanda_id'] && (int) $member->familia?->jumuiya?->kanda_id !== (int) $filters['kanda_id']) {
                throw new AuthorizationException('Selected member does not belong to the selected kanda.');
            }

            $this->scopeAccessGate->authorizeMember($user, $member);
        }
    }
}