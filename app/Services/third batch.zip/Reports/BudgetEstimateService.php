<?php

namespace App\Services\Reports;

use App\Models\BankContribution;
use App\Models\BudgetEstimateExpense;
use App\Models\BudgetEstimateIncome;
use App\Models\CashContribution;
use App\Models\Offering;
use App\Models\ProjectTransaction;
use App\Models\Tithe;
use App\Models\User;
use App\Services\Access\UserScopeResolver;
use Illuminate\Database\Eloquent\Builder;

class BudgetEstimateService
{
    public function __construct(
        protected UserScopeResolver $scopeResolver,
    ) {
    }

    public function dashboardData(User $user, int $year): array
    {
        $incomeBudgets = BudgetEstimateIncome::query()
            ->where('budget_year', $year)
            ->orderBy('category_name')
            ->get();

        $expenseBudgets = BudgetEstimateExpense::query()
            ->where('budget_year', $year)
            ->orderBy('category_name')
            ->get();

        $incomeRows = $incomeBudgets->map(function (BudgetEstimateIncome $item) use ($user, $year) {
            $actual = $this->actualIncomeForCategory($user, $item->category_code, $year);

            return [
                'id' => $item->id,
                'category_code' => $item->category_code,
                'category_name' => $item->category_name,
                'group_name' => $item->group_name,
                'budget_amount' => (float) $item->amount,
                'actual_amount' => $actual,
                'variance' => $actual - (float) $item->amount,
                'notes' => $item->notes,
            ];
        });

        $expenseRows = $expenseBudgets->map(function (BudgetEstimateExpense $item) use ($user, $year) {
            $actual = $this->actualExpenseForCategory($user, $item->category_code, $year);

            return [
                'id' => $item->id,
                'category_code' => $item->category_code,
                'category_name' => $item->category_name,
                'group_name' => $item->group_name,
                'budget_amount' => (float) $item->amount,
                'actual_amount' => $actual,
                'variance' => $actual - (float) $item->amount,
                'notes' => $item->notes,
            ];
        });

        return [
            'pageTitle' => db_trans('budget_vs_actual'),
            'year' => $year,
            'incomeRows' => $incomeRows,
            'expenseRows' => $expenseRows,
            'incomeBudgetTotal' => $incomeRows->sum('budget_amount'),
            'incomeActualTotal' => $incomeRows->sum('actual_amount'),
            'expenseBudgetTotal' => $expenseRows->sum('budget_amount'),
            'expenseActualTotal' => $expenseRows->sum('actual_amount'),
            'availableYears' => collect(range(now()->year + 1, now()->year - 5))->sortDesc()->values(),
        ];
    }

    public function createIncome(array $data, User $user): BudgetEstimateIncome
    {
        $data['created_by'] = $user->id;
        $data['updated_by'] = $user->id;
        $data['is_active'] = (bool) ($data['is_active'] ?? true);

        return BudgetEstimateIncome::create($data);
    }

    public function updateIncome(BudgetEstimateIncome $budgetEstimateIncome, array $data, User $user): BudgetEstimateIncome
    {
        $data['updated_by'] = $user->id;
        $budgetEstimateIncome->update($data);

        return $budgetEstimateIncome->refresh();
    }

    public function createExpense(array $data, User $user): BudgetEstimateExpense
    {
        $data['created_by'] = $user->id;
        $data['updated_by'] = $user->id;
        $data['is_active'] = (bool) ($data['is_active'] ?? true);

        return BudgetEstimateExpense::create($data);
    }

    public function updateExpense(BudgetEstimateExpense $budgetEstimateExpense, array $data, User $user): BudgetEstimateExpense
    {
        $data['updated_by'] = $user->id;
        $budgetEstimateExpense->update($data);

        return $budgetEstimateExpense->refresh();
    }

    protected function actualIncomeForCategory(User $user, ?string $code, int $year): float
    {
        return match ($code) {
            'offerings' => (float) $this->scopedOfferingsQuery($user)
                ->whereYear('collection_date', $year)
                ->where('status', Offering::STATUS_APPROVED)
                ->sum('amount'),

            'tithes' => (float) $this->scopedTithesQuery($user)
                ->whereYear('contribution_date', $year)
                ->where('status', Tithe::STATUS_APPROVED)
                ->sum('amount'),

            'cash_contributions' => (float) $this->scopedCashContributionsQuery($user)
                ->whereYear('contribution_date', $year)
                ->where('status', CashContribution::STATUS_APPROVED)
                ->sum('amount'),

            'bank_contributions' => (float) $this->scopedBankContributionsQuery($user)
                ->whereYear('contribution_date', $year)
                ->where('status', BankContribution::STATUS_VERIFIED)
                ->sum('amount'),

            'project_income' => (float) $this->scopedProjectTransactionsQuery()
                ->whereYear('transaction_date', $year)
                ->where('transaction_type', ProjectTransaction::TYPE_INCOME)
                ->where('status', ProjectTransaction::STATUS_APPROVED)
                ->sum('amount'),

            default => 0.0,
        };
    }

    protected function actualExpenseForCategory(User $user, ?string $code, int $year): float
    {
        return match ($code) {
            'project_expenses' => (float) $this->scopedProjectTransactionsQuery()
                ->whereYear('transaction_date', $year)
                ->where('transaction_type', ProjectTransaction::TYPE_EXPENSE)
                ->where('status', ProjectTransaction::STATUS_APPROVED)
                ->sum('amount'),

            default => 0.0,
        };
    }

    protected function scopedOfferingsQuery(User $user): Builder
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = Offering::query();

        if ($scope->isInvalid()) {
            return $query->whereRaw('1 = 0');
        }

        if ($scope->isGlobal()) {
            return $query;
        }

        if ($scope->isKanda()) {
            return $query->where(function (Builder $builder) use ($scope) {
                $builder->where('kanda_id', $scope->kandaId)
                    ->orWhereHas('jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', $scope->kandaId));
            });
        }

        if ($scope->isJumuiya()) {
            return $query->where('jumuiya_id', $scope->jumuiyaId);
        }

        return $query->whereRaw('1 = 0');
    }

    protected function scopedTithesQuery(User $user): Builder
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = Tithe::query();

        if ($scope->isInvalid()) {
            return $query->whereRaw('1 = 0');
        }

        if ($scope->isGlobal()) {
            return $query;
        }

        if ($scope->isKanda()) {
            return $query->whereHas('jumuiya', fn (Builder $jumuiyaQuery) => $jumuiyaQuery->where('kanda_id', $scope->kandaId));
        }

        if ($scope->isJumuiya()) {
            return $query->where('jumuiya_id', $scope->jumuiyaId);
        }

        return $query->whereRaw('1 = 0');
    }

    protected function scopedCashContributionsQuery(User $user): Builder
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = CashContribution::query();

        if ($scope->isInvalid()) {
            return $query->whereRaw('1 = 0');
        }

        if ($scope->isGlobal()) {
            return $query;
        }

        if ($scope->isKanda()) {
            return $query->where('kanda_id', $scope->kandaId);
        }

        if ($scope->isJumuiya()) {
            return $query->where('jumuiya_id', $scope->jumuiyaId);
        }

        return $query->whereRaw('1 = 0');
    }

    protected function scopedBankContributionsQuery(User $user): Builder
    {
        $scope = $this->scopeResolver->resolve($user);

        $query = BankContribution::query();

        if ($scope->isInvalid()) {
            return $query->whereRaw('1 = 0');
        }

        if ($scope->isGlobal()) {
            return $query;
        }

        if ($scope->isKanda()) {
            return $query->where('kanda_id', $scope->kandaId);
        }

        if ($scope->isJumuiya()) {
            return $query->where('jumuiya_id', $scope->jumuiyaId);
        }

        return $query->whereRaw('1 = 0');
    }

    protected function scopedProjectTransactionsQuery(): Builder
    {
        return ProjectTransaction::query();
    }
}